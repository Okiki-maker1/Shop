# OBAHTECH Gadgets — mobile shopping readiness audit

Audit scope: the supplied Next.js project archive, its app routes, server actions,
PostgreSQL migrations, configuration and public assets. This is a code review,
not a live production penetration test or a live payment/delivery certification.

## Present in the supplied code

- Mobile-responsive storefront with bottom navigation.
- Product catalogue, categories, product details, search, filtering and sorting.
- Cart, wishlist and product comparison.
- Customer registration/login, password reset, email-verification flow and address book.
- Nigerian state/LGA delivery address validation.
- Checkout, delivery methods/fees, promo codes and stock reservation.
- Flutterwave server-side payment initialization/verification and webhook handling.
- Customer order history, tracking, notifications, support tickets, return requests and warranty claims.
- Admin console for products, categories, stock, orders, customers, delivery fees, promotions, banners,
  notifications, returns, warranties, support tickets and reporting.
- PostgreSQL schema and Netlify Next.js configuration.

## Added in this revision

- Web app manifest for Android home-screen installation, with app name, standalone display mode,
  theme colours and correctly sized app icons.

## Important gaps before calling this a Jumia-style marketplace

1. **Third-party seller centre is not implemented.** The current role model is customer, state admin and
   super admin. There is no seller onboarding/verification, seller storefront, seller product ownership,
   seller order queue, seller commissions, settlements or payout statements. The current project is a
   single-operator online shop, not yet a multi-vendor marketplace.
2. **Courier integration is not implemented.** Delivery fees and order statuses exist, but there is no
   confirmed live carrier API integration, rider dispatch, shipping-label generation, pickup scan or
   carrier-sourced tracking events. Delivery operations must be configured and fulfilled by the operator.
3. **Persistent cloud product-image storage needs production setup.** The current upload helper uses local
   disk outside Netlify and data-URI storage on Netlify. Configure durable object storage before accepting
   many product photos; serverless local files are not durable and data URIs increase database size.
4. **Live payment credentials and end-to-end live verification are still required.** The code includes
   Flutterwave integration and sandbox flow, but the owner must configure keys/webhook hash and perform
   controlled live tests before taking real payments.
5. **Email/SMS delivery depends on external provider credentials.** Without them, messages are queued/logged;
   a queue worker or scheduled processor and provider configuration are required for dependable delivery.
6. **Native Android/iOS apps are not included.** This remains a mobile-first website that can be installed
   from a supported browser using the web app manifest; it is not a Play Store app.
7. **Customer-to-seller live chat, seller ratings/performance, seller disputes and seller payouts** are not
   part of the current single-store codebase.
8. **Production hardening remains.** Configure rate limiting with a shared store (rather than per-instance
   memory), backups/restore tests, monitoring/error alerts, privacy/returns policy review, domain/HTTPS,
   and load/security testing before public launch.

## Owner setup required

- Set `DATABASE_URL` to the Supabase PostgreSQL pooler connection string.
- Set `NEXT_PUBLIC_APP_URL` to the real deployed HTTPS domain.
- Configure Flutterwave public/secret keys and webhook hash only in server-side environment variables.
- Configure email/SMS provider credentials if those notifications are required.
- Replace demo catalogue items and generated SVG artwork with real product photos, accurate prices,
  stock counts, warranty terms and delivery rates.
- Test account creation, checkout, payment verification, order updates, returns and admin access on
  a real Android phone before sharing the website publicly.

## Important note

A feature is not considered production-ready merely because a page or database table exists. External
services, credentials, business policies, real inventory, operational processes and end-to-end tests are
also required. Do not advertise delivery, warranty, payment or seller-protection promises until they are
actually configured and can be fulfilled.
