import { getDb } from './db';

/** Everything the dependent state/LGA dropdowns need, cached per request. */
export async function locationOptions() {
  const db = getDb();
  return {
    states: await db.prepare('SELECT id, name FROM states ORDER BY name').all() as { id: number; name: string }[],
    lgas: await db.prepare('SELECT id, state_id, name FROM lgas ORDER BY name').all() as { id: number; state_id: number; name: string }[],
  };
}
