/**
 * ─────────────────────────────────────────────────────────────────────────────
 * OBAHTECH Gadgets — data access layer (Supabase PostgreSQL)
 *
 * The application talks to Postgres through `pg` (node-postgres). To keep the
 * hundreds of existing, tested queries readable, this module exposes a small
 * statement façade with the same shape the codebase already used:
 *
 *     const row  = await db.prepare('SELECT * FROM products WHERE id = ?').get(id);
 *     const rows = await db.prepare('SELECT * FROM orders WHERE state_id = ?').all(stateId);
 *     const res  = await db.prepare('INSERT INTO carts (user_id) VALUES (?)').run(userId);
 *     res.lastInsertRowid  // id of the inserted row
 *     res.changes          // rows affected
 *
 * What it does for you:
 *   • converts `?` placeholders to Postgres `$1..$n` (skipping quoted text),
 *   • translates the handful of SQLite idioms the queries used to Postgres
 *     (`datetime('now')`, `IFNULL`, `INSERT OR IGNORE`, case-insensitive LIKE,
 *     `date(x)`/`substr(<timestamp>)` helpers),
 *   • appends `RETURNING *` to INSERT/UPDATE/DELETE so `lastInsertRowid` and
 *     `changes` keep working,
 *   • normalises parameters — form values arrive as strings, and Postgres will
 *     not compare `integer = text`, so numeric strings are coerced,
 *   • formats timestamptz / numeric / date values on the way out so the UI
 *     keeps receiving the same 'YYYY-MM-DD HH:MM:SS' strings and numbers.
 *
 * Everything is async: Postgres is a network database and Next.js server
 * components / server actions / route handlers are all async already.
 * ─────────────────────────────────────────────────────────────────────────────
 */
import { Pool, types, type PoolClient, type PoolConfig } from 'pg';
import { AsyncLocalStorage } from 'node:async_hooks';

// ─── Type parsers: keep the JS-facing shapes the app already expects ────────
const fmtTimestamp = (value: string) => {
  // node-postgres hands us the raw text: '2026-10-30 19:32:39.123456+00'
  const iso = value.includes('T') ? value : value.replace(' ', 'T');
  const d = new Date(/[zZ]|[+-]\d\d(:?\d\d)?$/.test(iso) ? iso : `${iso}Z`);
  if (Number.isNaN(d.getTime())) return value;
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())} ${p(d.getUTCHours())}:${p(
    d.getUTCMinutes(),
  )}:${p(d.getUTCSeconds())}`;
};

types.setTypeParser(1114, fmtTimestamp); // timestamp
types.setTypeParser(1184, fmtTimestamp); // timestamptz
types.setTypeParser(1082, (v) => v); // date → 'YYYY-MM-DD'
types.setTypeParser(1700, (v) => Number(v)); // numeric → number
types.setTypeParser(20, (v) => {
  const n = Number(v); // int8 → number while it is safe, else string
  return Number.isSafeInteger(n) ? n : v;
});

// ─── Pool ───────────────────────────────────────────────────────────────────
declare global {
  // eslint-disable-next-line no-var
  var __obahPool: Pool | undefined;
}

function buildPool(): Pool {
  const connectionString = process.env.DATABASE_URL || process.env.SUPABASE_DB_URL;
  if (!connectionString) {
    throw new Error(
      'DATABASE_URL is not set. Point it at your Supabase Postgres connection string ' +
        '(Project → Settings → Database → Connection string → URI). ' +
        'For serverless (Netlify) use the pooler on port 6543.',
    );
  }
  const isLocal = /@(localhost|127\.0\.0\.1|\[::1\])[:/]/.test(connectionString);
  const sslSetting = (process.env.DATABASE_SSL || '').toLowerCase();
  const ssl =
    sslSetting === 'false' || (sslSetting === '' && isLocal)
      ? undefined
      : { rejectUnauthorized: sslSetting === 'strict' };

  const config: PoolConfig = {
    connectionString,
    ssl,
    // Serverless-friendly defaults: Netlify functions are short-lived and the
    // Supabase pooler multiplexes for us.
    max: Number(process.env.DATABASE_POOL_MAX || 5),
    idleTimeoutMillis: Number(process.env.DATABASE_IDLE_TIMEOUT || 10_000),
    connectionTimeoutMillis: Number(process.env.DATABASE_CONNECT_TIMEOUT || 10_000),
    keepAlive: true,
    application_name: 'obahtech-web',
  };
  const pool = new Pool(config);
  pool.on('error', (err) => {
    // A broken idle client must never crash the Node process.
    console.error('[db] idle client error', err.message);
  });
  return pool;
}

export function getPool(): Pool {
  if (!global.__obahPool) global.__obahPool = buildPool();
  return global.__obahPool;
}

export async function closePool() {
  if (global.__obahPool) {
    await global.__obahPool.end();
    global.__obahPool = undefined;
  }
}

// ─── SQL translation (SQLite dialect → Postgres) ────────────────────────────
const INTERVAL_MAP: Record<string, string> = {
  'now': 'now()',
};

/**
 * Replace `?` (positional) and `@name` (SQLite named) placeholders with
 * `$1..$n`, skipping quoted literals. Returns the rewritten SQL plus the
 * ordered parameter names (`null` for positional `?`).
 */
function bindPlaceholders(sql: string) {
  let out = '';
  let idx = 0;
  let n = 0;
  const names: (string | null)[] = [];
  let inSingle = false;
  let inDouble = false;
  let inLineComment = false;
  let inBlockComment = false;

  while (idx < sql.length) {
    const ch = sql[idx];
    const next = sql[idx + 1];

    if (inLineComment) {
      out += ch;
      if (ch === '\n') inLineComment = false;
      idx++;
      continue;
    }
    if (inBlockComment) {
      out += ch;
      if (ch === '*' && next === '/') {
        out += next;
        idx += 2;
        inBlockComment = false;
        continue;
      }
      idx++;
      continue;
    }
    if (!inSingle && !inDouble) {
      if (ch === '-' && next === '-') {
        inLineComment = true;
        out += ch;
        idx++;
        continue;
      }
      if (ch === '/' && next === '*') {
        inBlockComment = true;
        out += ch + next;
        idx += 2;
        continue;
      }
    }
    if (ch === "'" && !inDouble) {
      // Handle SQL-escaped quotes ('') inside a string
      if (inSingle && next === "'") {
        out += ch + next;
        idx += 2;
        continue;
      }
      inSingle = !inSingle;
      out += ch;
      idx++;
      continue;
    }
    if (ch === '"' && !inSingle) {
      inDouble = !inDouble;
      out += ch;
      idx++;
      continue;
    }
    if (ch === '?' && !inSingle && !inDouble) {
      n += 1;
      out += `$${n}`;
      names.push(null);
      idx++;
      continue;
    }
    if (ch === '@' && !inSingle && !inDouble && /[A-Za-z_]/.test(next || '')) {
      let j = idx + 1;
      while (j < sql.length && /[\w]/.test(sql[j])) j++;
      const name = sql.slice(idx + 1, j);
      n += 1;
      out += `$${n}`;
      names.push(name);
      idx = j;
      continue;
    }
    out += ch;
    idx++;
  }
  return { sql: out, count: n, names };
}

/** Rewrite multi-argument `max(a, b)` / `min(a, b)` to greatest/least. */
function scalarMinMaxToGreatest(input: string): string {
  let out = '';
  let i = 0;
  const lower = input.toLowerCase();
  while (i < input.length) {
    const isMax = lower.startsWith('max(', i) && (i === 0 || !/[\w.]/.test(input[i - 1]));
    const isMin = !isMax && lower.startsWith('min(', i) && (i === 0 || !/[\w.]/.test(input[i - 1]));
    if (isMax || isMin) {
      const nameEnd = i + 3; // before '('
      let j = i + 4;
      let depth = 0;
      let topComma = false;
      for (; j < input.length; j++) {
        const c = input[j];
        if (c === '(') depth++;
        else if (c === ')') {
          if (depth === 0) break;
          depth--;
        } else if (c === ',' && depth === 0) {
          topComma = true;
          break;
        }
      }
      if (topComma) {
        out += (isMax ? 'greatest' : 'least') + '(';
        i = i + 4;
        continue;
      }
      // single argument → real aggregate, keep as-is
      out += input.slice(i, i + 4);
      i += 4;
      continue;
    }
    out += input[i];
    i++;
  }
  return out;
}

/** Rewrite `substr(<first>, ...)` into `substr((<first>)::text, ...)`. */
function castSubstrFirstArg(input: string): string {
  let out = '';
  let i = 0;
  const lower = input.toLowerCase();
  while (i < input.length) {
    if (lower.startsWith('substr(', i)) {
      let j = i + 'substr('.length;
      let depth = 0;
      let comma = -1;
      let close = -1;
      for (; j < input.length; j++) {
        const c = input[j];
        if (c === '(') depth++;
        else if (c === ')') {
          if (depth === 0) { close = j; break; }
          depth--;
        } else if (c === ',' && depth === 0) { comma = j; break; }
      }
      if (comma > 0) {
        out += input.slice(i, comma) + '::text';
        i = comma;
        continue;
      }
      if (close > 0) {
        out += input.slice(i, close) + '::text';
        i = close;
        continue;
      }
    }
    out += input[i];
    i++;
  }
  return out;
}

/** Translate the SQLite-isms this codebase uses into Postgres equivalents. */
export function translate(sql: string): string {
  let s = sql;

  // datetime('now') / datetime('now','-7 days') / datetime('now','+48 hours')
  s = s.replace(/datetime\(\s*'now'\s*,\s*'([+-]\d+)\s+(second|minute|hour|day|month|year)s?'\s*\)/gi, (_m, amt, unit) => {
    return `(now() + interval '${amt} ${unit}')`;
  });
  s = s.replace(/datetime\(\s*'now'\s*\)/gi, 'now()');
  s = s.replace(/date\(\s*'now'\s*\)/gi, 'current_date');
  // date(col) → (col)::date
  s = s.replace(/\bdate\(\s*([a-z_][\w.]*)\s*\)/gi, (_m, col) => {
    if (['now', 'current_date'].includes(col.toLowerCase())) return col;
    return `(${col})::date`;
  });
  // IFNULL → COALESCE
  s = s.replace(/\bIFNULL\(/gi, 'COALESCE(');
  // substr(<expr>, from, len) — cast the first argument to text so the same
  // call works for TEXT columns and timestamps (SQLite coerced automatically).
  s = castSubstrFirstArg(s);
  // SQLite's scalar max(a,b)/min(a,b) are greatest()/least() in Postgres
  // (where MAX/MIN are aggregates and reject multiple arguments).
  s = scalarMinMaxToGreatest(s);
  // Insert-or-ignore → ON CONFLICT DO NOTHING
  const orIgnore = /^\s*INSERT\s+OR\s+IGNORE\s+INTO/i.test(s);
  if (orIgnore) s = s.replace(/^\s*INSERT\s+OR\s+IGNORE\s+INTO/i, 'INSERT INTO');
  // Case-insensitive LIKE, matching SQLite's default behaviour
  s = s.replace(/\bLIKE\b/gi, 'ILIKE');

  if (orIgnore && !/\bON\s+CONFLICT\b/i.test(s)) {
    s = s.trimEnd();
    if (/\bRETURNING\b/i.test(s)) s = s.replace(/\s+RETURNING\b/i, ' ON CONFLICT DO NOTHING RETURNING');
    else s += ' ON CONFLICT DO NOTHING';
  }
  if (INTERVAL_MAP['now']) {
    /* placeholder for future interval helpers */
  }
  return s;
}

// ─── Parameter normalisation ───────────────────────────────────────────────
const NUMERIC_STRING = /^[1-9]\d{0,9}$/;

export function normaliseParams(params: unknown[]): unknown[] {
  return params.map((p) => {
    if (p === undefined) return null;
    if (p === null) return null;
    if (typeof p === 'boolean') return p ? 1 : 0;
    if (p instanceof Date) return p.toISOString();
    if (typeof p === 'number') return p;
    if (typeof p === 'bigint') return Number(p);
    if (typeof p === 'string') {
      // Form values arrive as strings and Postgres refuses `integer = text`.
      // Phone numbers, order numbers, slugs, emails and codes keep their exact
      // text form because they either start with 0 or contain non-digits.
      if (NUMERIC_STRING.test(p)) return Number(p);
      return p;
    }
    return p;
  });
}

// ─── Statement façade ──────────────────────────────────────────────────────
export type RunResult = { changes: number; lastInsertRowid: number | null };
type Runner = { query: (text: string, values: unknown[]) => Promise<{ rows: any[]; rowCount: number | null }> };

const WRITE_SQL = /^\s*(INSERT|UPDATE|DELETE)/i;

function buildSql(sql: string, mode: 'all' | 'get' | 'run') {
  let text = translate(sql);
  if (mode === 'run' && WRITE_SQL.test(text) && !/\bRETURNING\b/i.test(text)) {
    text = `${text.trimEnd()} RETURNING *`;
  }
  const bound = bindPlaceholders(text);
  return { text: bound.sql, names: bound.names };
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v) && !(v instanceof Date);
}

async function execute(runner: Runner, sql: string, params: unknown[], mode: 'all' | 'get' | 'run') {
  const { text, names } = buildSql(sql, mode);
  let values: unknown[];
  if (params.length === 1 && isPlainObject(params[0]) && names.some((nm) => nm !== null)) {
    // SQLite-style named parameters: stmt.run({ name, price, ... })
    const obj = params[0] as Record<string, unknown>;
    values = normaliseParams(names.map((nm) => (nm === null ? undefined : obj[nm])));
  } else {
    values = normaliseParams(params);
  }
  const res = await runner.query(text, values);
  if (mode === 'all') return res.rows;
  if (mode === 'get') return res.rows[0];
  const rows = res.rows ?? [];
  return {
    changes: rows.length,
    lastInsertRowid: rows[0] && 'id' in rows[0] ? Number(rows[0].id) : null,
  } as RunResult;
}

export function statement(runner: Runner, sql: string) {
  return {
    /** Run the statement and return every row. */
    all: async <T = any>(...params: unknown[]): Promise<T[]> =>
      (await execute(runner, sql, flatten(params), 'all')) as T[],
    /** Run the statement and return the first row (or undefined). */
    get: async <T = any>(...params: unknown[]): Promise<T | undefined> =>
      (await execute(runner, sql, flatten(params), 'get')) as T | undefined,
    /** Run a write statement. `lastInsertRowid` mirrors better-sqlite3. */
    run: async (...params: unknown[]): Promise<RunResult> =>
      (await execute(runner, sql, flatten(params), 'run')) as RunResult,
  };
}

function flatten(params: unknown[]): unknown[] {
  if (params.length === 1 && Array.isArray(params[0])) return params[0] as unknown[];
  return params;
}

export type Db = {
  prepare: (sql: string) => ReturnType<typeof statement>;
  query: (sql: string, params?: unknown[]) => Promise<any[]>;
  /**
   * better-sqlite3 compatible transaction helper:
   *   const run = db.transaction(async () => { ... });
   *   await run();
   * The returned function runs `fn` inside one Postgres transaction.
   */
  transaction: <A extends unknown[], R>(fn: (...args: A) => R | Promise<R>) => (...args: A) => Promise<R>;
};

function makeDb(runner: Runner): Db {
  return {
    prepare: (sql: string) => statement(runner, sql),
    query: async (sql: string, params: unknown[] = []) => (await execute(runner, sql, params, 'all')) as any[],
    transaction:
      <A extends unknown[], R>(fn: (...args: A) => R | Promise<R>) =>
      async (...args: A): Promise<R> =>
        tx(async () => fn(...args)),
  };
}

/**
 * Queries issued while a transaction is open are transparently routed to the
 * transaction's dedicated connection — even when the statement was prepared
 * before the transaction began. This is what lets the legacy
 * `db.transaction(fn)()` helper (and any statement handle) participate in the
 * open transaction without every call site changing.
 */
const txStore = new AsyncLocalStorage<PoolClient>();

const poolRunner: Runner = {
  query: (text, values) => {
    const client = txStore.getStore();
    if (client) return client.query(text, values as any[]);
    return getPool().query(text, values as any[]);
  },
};

/**
 * The shared handle. `getDb()` is kept as an alias so that the hundreds of
 * existing call sites (and any future module) resolve the same object.
 */
export const db: Db = makeDb(poolRunner);

export function getDb(): Db {
  return db;
}

/**
 * Run `fn` inside a single Postgres transaction on a dedicated connection.
 * Anything executed through the `d` handle it receives is part of the same
 * transaction; a thrown error rolls everything back.
 */
export async function tx<T>(fn: (d: Db) => Promise<T>): Promise<T> {
  const client: PoolClient = await getPool().connect();
  try {
    await client.query('BEGIN');
    // Everything `fn` executes — through any handle — runs on `client`.
    const result = await txStore.run(client, () => fn(db));
    await client.query('COMMIT');
    return result;
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch (rollbackError) {
      console.error('[db] rollback failed', rollbackError);
    }
    throw err;
  } finally {
    client.release();
  }
}

/** Small helper for one-off statements (scripts, health checks). */
export async function raw(sql: string, params: unknown[] = []) {
  return execute(poolRunner, sql, params, 'all');
}
