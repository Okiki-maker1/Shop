'use server';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';

const KEY = 'obah_compare';

export async function addToCompare(fd: FormData) {
  const id = Number(fd.get('product_id'));
  const current = (cookies().get(KEY)?.value || '')
    .split(',')
    .map((x) => Number(x))
    .filter(Boolean);
  const next = Array.from(new Set([...current, id])).slice(-4);
  cookies().set(KEY, next.join(','), { path: '/', maxAge: 3600, sameSite: 'lax' });
  redirect('/compare');
}

export async function clearCompare() {
  cookies().delete(KEY);
  revalidatePath('/compare');
  redirect('/compare');
}
