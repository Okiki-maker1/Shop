'use server';

import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { validatePair } from '@/lib/locations';
import { notifyOrder, notifyCustomer, logAdmin } from '@/lib/notify';
import { addOrderEvent } from '@/lib/orders';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();

async function me(path = '/account') {
  const u = await getSessionUser();
  if (!u) redirect(`/login?next=${encodeURIComponent(path)}`);
  return u;
}

export async function toggleWishlist(fd: FormData) {
  const user = await getSessionUser();
  const productId = Number(s(fd, 'product_id'));
  if (!user) redirect('/login?next=/wishlist');
  const db = getDb();
  const existing = await db.prepare('SELECT id FROM wishlists WHERE user_id = ? AND product_id = ?').get(user.id, productId);
  if (existing) await db.prepare('DELETE FROM wishlists WHERE id = ?').run((existing as any).id);
  else await db.prepare('INSERT INTO wishlists (user_id, product_id) VALUES (?,?)').run(user.id, productId);
  revalidatePath('/wishlist');
  revalidatePath('/');
  const back = s(fd, 'return_to');
  if (back) redirect(back);
}

export async function saveAddress(fd: FormData) {
  const user = await me();
  const db = getDb();
  const id = Number(s(fd, 'id') || 0);
  const fullName = s(fd, 'full_name');
  const phone = s(fd, 'phone');
  const street = s(fd, 'street');
  const instructions = s(fd, 'instructions');
  const label = s(fd, 'label') || 'Home';
  const pair =await  validatePair(db, Number(s(fd, 'state_id')), Number(s(fd, 'lga_id')));
  if (!pair.ok) redirect('/account?error=' + encodeURIComponent(pair.error!));
  if (!fullName || !phone || !street) redirect('/account?error=' + encodeURIComponent('Name, phone and street address are required.'));

  if (id) {
    const owned = await db.prepare('SELECT id FROM addresses WHERE id = ? AND user_id = ?').get(id, user.id);
    if (!owned) redirect('/account?error=' + encodeURIComponent('Address not found.'));
    await db.prepare(
      'UPDATE addresses SET label=?, full_name=?, phone=?, state_id=?, lga_id=?, street=?, instructions=? WHERE id=? AND user_id=?',
    ).run(label, fullName, phone, pair.state!.id, pair.lga!.id, street, instructions, id, user.id);
  } else {
    const count = (await db.prepare('SELECT COUNT(*) c FROM addresses WHERE user_id = ?').get(user.id) as any).c;
    const res = await db
      .prepare(
        'INSERT INTO addresses (user_id, label, full_name, phone, state_id, lga_id, street, instructions, is_default) VALUES (?,?,?,?,?,?,?,?,?)',
      )
      .run(user.id, label, fullName, phone, pair.state!.id, pair.lga!.id, street, instructions, count === 0 ? 1 : 0);
    if (count === 0) await db.prepare('UPDATE users SET state_id = ?, lga_id = ? WHERE id = ?').run(pair.state!.id, pair.lga!.id, user.id);
  }
  revalidatePath('/account');
  redirect('/account?saved=1#addresses');
}

export async function deleteAddress(fd: FormData) {
  const user = await me();
  const db = getDb();
  await db.prepare('DELETE FROM addresses WHERE id = ? AND user_id = ?').run(Number(s(fd, 'id')), user.id);
  revalidatePath('/account');
}

export async function setDefaultAddress(fd: FormData) {
  const user = await me();
  const db = getDb();
  const id = Number(s(fd, 'id'));
  await db.prepare('UPDATE addresses SET is_default = 0 WHERE user_id = ?').run(user.id);
  await db.prepare('UPDATE addresses SET is_default = 1 WHERE id = ? AND user_id = ?').run(id, user.id);
  revalidatePath('/account');
}

export async function updateProfile(fd: FormData) {
  const user = await me();
  const db = getDb();
  const fullName = s(fd, 'full_name');
  const phone = s(fd, 'phone');
  if (!fullName || !/^0\d{10}$/.test(phone.replace(/\D/g, '')))
    redirect('/account?error=' + encodeURIComponent('Enter your name and a valid Nigerian phone number.'));
  await db.prepare("UPDATE users SET full_name = ?, phone = ?, updated_at = datetime('now') WHERE id = ?").run(fullName, phone, user.id);
  revalidatePath('/account');
  redirect('/account?saved=1');
}

export async function requestCancellation(fd: FormData) {
  const user = await me('/orders');
  const db = getDb();
  const orderId = Number(s(fd, 'order_id'));
  const reason = s(fd, 'reason') || 'No reason provided';
  const order = await db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(orderId, user.id) as any;
  if (!order) redirect('/orders?error=' + encodeURIComponent('Order not found.'));
  const cancellable = ['pending_payment', 'payment_confirmed', 'order_confirmed', 'processing'];
  if (!cancellable.includes(order.status))
    redirect(`/orders/${order.order_number}?error=` + encodeURIComponent('This order can no longer be cancelled online. Please contact support.'));
  await db.prepare("UPDATE orders SET status = 'cancellation_requested', cancelled_reason = ?, updated_at = datetime('now') WHERE id = ?").run(reason, orderId);
  await addOrderEvent(orderId, 'cancellation_requested', `Customer requested cancellation: ${reason}`, user);
  await notifyOrder({
    orderId,
    type: 'cancellation_requested',
    title: `Cancellation requested — ${order.order_number}`,
    body: `${order.customer_name} requested cancellation. Reason: ${reason}`,
  });
  await notifyCustomer({ userId: user.id, type: 'order_status', title: `Cancellation requested for ${order.order_number}`, body: 'Our team will review your cancellation request shortly.', orderId });
  revalidatePath('/orders');
  redirect(`/orders/${order.order_number}?requested=1`);
}

export async function requestReturn(fd: FormData) {
  const user = await me('/orders');
  const db = getDb();
  const orderId = Number(s(fd, 'order_id'));
  const itemId = Number(s(fd, 'order_item_id')) || null;
  const reason = s(fd, 'reason');
  const explanation = s(fd, 'explanation');
  const photos = s(fd, 'photos');
  const order = await db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(orderId, user.id) as any;
  if (!order) redirect('/orders?error=' + encodeURIComponent('Order not found.'));
  if (order.status !== 'delivered')
    redirect(`/orders/${order.order_number}?error=` + encodeURIComponent('Returns can only be requested after delivery.'));
  const deliveredAt = (await db.prepare('SELECT delivered_at FROM deliveries WHERE order_id = ?').get(orderId) as any)?.delivered_at;
  const days = deliveredAt ? (Date.now() - new Date(deliveredAt.replace(' ', 'T') + 'Z').getTime()) / 864e5 : 999;
  if (days > 7) redirect(`/orders/${order.order_number}?error=` + encodeURIComponent('The 7-day return window for this order has closed. You can still file a warranty claim.'));
  if (!reason) redirect(`/orders/${order.order_number}?error=` + encodeURIComponent('Select a return reason.'));

  const res = await db
    .prepare('INSERT INTO return_requests (order_id, order_item_id, user_id, reason, explanation, photos) VALUES (?,?,?,?,?,?)')
    .run(orderId, itemId, user.id, reason, explanation, photos || null);
  await db.prepare("UPDATE orders SET status = 'return_requested', updated_at = datetime('now') WHERE id = ?").run(orderId);
  await addOrderEvent(orderId, 'return_requested', `Return requested: ${reason}`, user);
  await notifyOrder({
    orderId,
    type: 'return_requested',
    title: `Return requested — ${order.order_number}`,
    body: `${order.customer_name} requested a return. Reason: ${reason}. Return #${res.lastInsertRowid}.`,
  });
  await notifyCustomer({ userId: user.id, type: 'return', title: `Return request received for ${order.order_number}`, body: 'Our team will review your request within 24 hours.', orderId });
  revalidatePath('/orders');
  redirect(`/orders/${order.order_number}?return=1`);
}

export async function submitWarrantyClaim(fd: FormData) {
  const user = await me('/account#warranties');
  const db = getDb();
  const warrantyId = Number(s(fd, 'warranty_id'));
  const issue = s(fd, 'issue');
  const evidence = s(fd, 'evidence_url');
  const w = await db.prepare('SELECT * FROM warranties WHERE id = ? AND user_id = ?').get(warrantyId, user.id) as any;
  if (!w) redirect('/account?error=' + encodeURIComponent('Warranty not found.'));
  if (new Date(w.expiry_date) < new Date()) redirect('/account?error=' + encodeURIComponent('This warranty has expired.'));
  if (!issue) redirect('/account?error=' + encodeURIComponent('Describe the fault you are experiencing.'));
  const res = await db
    .prepare('INSERT INTO warranty_claims (warranty_id, order_id, user_id, issue, evidence_url) VALUES (?,?,?,?,?)')
    .run(warrantyId, w.order_id, user.id, issue, evidence || null);
  await db.prepare("UPDATE warranties SET status = 'claimed' WHERE id = ?").run(warrantyId);
  await notifyOrder({
    orderId: w.order_id,
    type: 'warranty_claim',
    title: `Warranty claim — ${w.product_name}`,
    body: `${user.full_name} filed warranty claim #${res.lastInsertRowid}: ${issue.slice(0, 140)}`,
  });
  await notifyCustomer({ userId: user.id, type: 'warranty', title: 'Warranty claim submitted', body: `Claim #${res.lastInsertRowid} for ${w.product_name} is under review.`, orderId: w.order_id });
  revalidatePath('/account');
  redirect('/account?claim=1#warranties');
}

export async function submitReview(fd: FormData) {
  const user = await getSessionUser();
  const productId = Number(s(fd, 'product_id'));
  const slug = s(fd, 'slug');
  if (!user) redirect(`/login?next=${encodeURIComponent('/product/' + slug)}`);
  const db = getDb();
  const rating = Math.min(5, Math.max(1, Number(s(fd, 'rating') || 5)));
  const purchased = await db
    .prepare(
      `SELECT o.id FROM orders o JOIN order_items oi ON oi.order_id = o.id
        WHERE o.user_id = ? AND oi.product_id = ? AND o.status = 'delivered' LIMIT 1`,
    )
    .get(user.id, productId) as any;
  await db.prepare('INSERT INTO reviews (product_id, user_id, order_id, author, rating, title, body) VALUES (?,?,?,?,?,?,?)').run(
    productId,
    user.id,
    purchased?.id ?? null,
    purchased ? `${user.full_name} (verified purchase)` : user.full_name,
    rating,
    s(fd, 'title') || null,
    s(fd, 'body') || null,
  );
  const agg = await db.prepare('SELECT AVG(rating) a, COUNT(*) c FROM reviews WHERE product_id = ? AND status = \'published\'').get(productId) as any;
  await db.prepare('UPDATE products SET rating_avg = ?, rating_count = ? WHERE id = ?').run(
    Math.round((agg.a ?? 0) * 10) / 10,
    agg.c,
    productId,
  );
  revalidatePath(`/product/${slug}`);
  redirect(`/product/${slug}?review=1#reviews`);
}

export async function createTicket(fd: FormData) {
  const db = getDb();
  const user = await getSessionUser();
  const name = s(fd, 'name') || user?.full_name || '';
  const email = s(fd, 'email') || user?.email || '';
  const category = s(fd, 'category') || 'other';
  const subject = s(fd, 'subject');
  const message = s(fd, 'message');
  const orderNumber = s(fd, 'order_number');
  let orderId: number | null = null;
  let stateId: number | null = user?.state_id ?? null;
  if (orderNumber) {
    const order = await db.prepare('SELECT * FROM orders WHERE order_number = ?').get(orderNumber) as any;
    if (order) {
      orderId = order.id;
      stateId = order.state_id;
    }
  }
  if (!name || !email || !subject || !message)
    redirect('/support?error=' + encodeURIComponent('Name, email, subject and message are required.'));
  const ref = `TKT-${Date.now().toString(36).toUpperCase()}`;
  await db.prepare(
    'INSERT INTO support_tickets (reference, user_id, order_id, name, email, phone, category, subject, message, state_id) VALUES (?,?,?,?,?,?,?,?,?,?)',
  ).run(ref, user?.id ?? null, orderId, name, email, s(fd, 'phone') || null, category, subject, message, stateId);
  if (orderId) {
    await notifyOrder({
      orderId,
      type: 'support_ticket',
      title: `Support ticket ${ref} — ${category}`,
      body: `${name}: ${subject}`,
    });
  } else {
    const supers = await db.prepare("SELECT id FROM users WHERE role = 'super_admin'").all() as any[];
    for (const sp of supers) {
      await db.prepare(
        "INSERT INTO notifications (type, audience, title, body, state_id, recipient_role, recipient_user_id) VALUES ('support_ticket','admin',?,?,?,'super_admin',?)",
      ).run(`Support ticket ${ref} — ${category}`, `${name}: ${subject}`, stateId, sp.id);
    }
  }
  redirect(`/support?sent=${encodeURIComponent(ref)}`);
}

export async function replyTicket(fd: FormData) {
  const user = await me('/support');
  const db = getDb();
  const ticketId = Number(s(fd, 'ticket_id'));
  const body = s(fd, 'body');
  if (!body) redirect('/support');
  await db.prepare("INSERT INTO ticket_messages (ticket_id, author_id, author_role, body) VALUES (?,?,?,?)").run(ticketId, user.id, user.role, body);
  await db.prepare("UPDATE support_tickets SET updated_at = datetime('now') WHERE id = ?").run(ticketId);
  revalidatePath('/support');
  redirect('/support?ok=1');
}

export async function markNotificationsRead(fd: FormData) {
  const user = await me('/notifications');
  const db = getDb();
  const id = Number(s(fd, 'id') || 0);
  if (id) {
    await db.prepare("UPDATE notifications SET is_read = 1, read_at = datetime('now') WHERE id = ? AND recipient_user_id = ?").run(id, user.id);
    await db.prepare("UPDATE notification_recipients SET read_at = datetime('now') WHERE notification_id = ? AND user_id = ?").run(id, user.id);
  } else {
    await db.prepare("UPDATE notifications SET is_read = 1, read_at = datetime('now') WHERE recipient_user_id = ? AND is_read = 0").run(user.id);
  }
  revalidatePath('/notifications');
}

export async function cancelOrderCustomer(fd: FormData) {
  // alias used by the orders list quick-action
  return requestCancellation(fd);
}

export async function saveDeliveryFeesUnused() {
  // placeholder to keep the module's action graph stable during refactors
  return null;
}
