'use server';

import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { getCartLines, clearCart, activePromo, PROMO_COOKIE } from '@/lib/cart';
import { createOrder } from '@/lib/orders';
import { validatePair } from '@/lib/locations';
import { startPayment } from '@/lib/payments';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();

export async function placeOrderAction(fd: FormData) {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/checkout');
  const db = getDb();
  const lines = await getCartLines(user.id);
  if (!lines.length) redirect('/cart?error=' + encodeURIComponent('Your cart is empty.'));

  const addressId = Number(s(fd, 'address_id') || 0);
  let fullName = s(fd, 'full_name');
  let phone = s(fd, 'phone');
  let email = s(fd, 'email') || user.email;
  let stateId = Number(s(fd, 'state_id'));
  let lgaId = Number(s(fd, 'lga_id'));
  let street = s(fd, 'street');
  let instructions = s(fd, 'instructions');

  if (addressId) {
    const addr = await db.prepare('SELECT * FROM addresses WHERE id = ? AND user_id = ?').get(addressId, user.id) as any;
    if (!addr) redirect('/checkout?error=' + encodeURIComponent('Selected delivery address was not found.'));
    fullName = addr.full_name;
    phone = addr.phone;
    stateId = addr.state_id;
    lgaId = addr.lga_id;
    street = addr.street;
    instructions = addr.instructions || instructions;
  }

  const pair =await  validatePair(db, stateId, lgaId);
  if (!pair.ok) redirect('/checkout?error=' + encodeURIComponent(pair.error!));
  if (!fullName || !phone || !street)
    redirect('/checkout?error=' + encodeURIComponent('Delivery name, phone and full address are required.'));
  if (!/^0\d{10}$/.test(phone.replace(/\D/g, '')))
    redirect('/checkout?error=' + encodeURIComponent('Enter a valid Nigerian phone number.'));

  const promo = await activePromo();
  let created;
  try {
    created =await  createOrder({
      user,
      customerName: fullName,
      phone,
      email,
      stateId: pair.state!.id,
      lgaId: pair.lga!.id,
      addressText: street,
      instructions,
      deliveryMethod: s(fd, 'delivery_method') || 'standard',
      promoCode: promo?.code ?? null,
      items: lines.map((l) => ({ productId: l.product_id, color: l.color, storage: l.storage, qty: l.qty })),
    });
  } catch (e: any) {
    redirect('/checkout?error=' + encodeURIComponent(e.message || 'We could not create your order.'));
  }

  await clearCart(user.id);
  cookies().delete(PROMO_COOKIE);

  // Kick off payment immediately (sandbox redirect when keys are absent)
  let link: string;
  try {
    const p = await startPayment(created.orderId);
    link = p.link;
  } catch {
    link = `/payments/${created.number}?error=${encodeURIComponent('Payment could not be initialised. You can retry from your order page.')}`;
  }
  redirect(link);
}

export async function retryPaymentAction(fd: FormData) {
  const user = await getSessionUser();
  if (!user) redirect('/login');
  const orderNumber = s(fd, 'order_number');
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE order_number = ? AND user_id = ?').get(orderNumber, user.id) as any;
  if (!order) redirect('/orders?error=' + encodeURIComponent('Order not found.'));
  try {
    const p = await startPayment(order.id);
    redirect(p.link);
  } catch (e: any) {
    redirect(`/orders/${orderNumber}?error=` + encodeURIComponent(e.message));
  }
}

export async function startPaymentAction(fd: FormData) {
  const user = await getSessionUser();
  if (!user) redirect('/login');
  const orderNumber = s(fd, 'order_number');
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE order_number = ?').get(orderNumber) as any;
  if (!order) redirect('/orders?error=' + encodeURIComponent('Order not found.'));
  if (user.role === 'customer' && order.user_id !== user.id) redirect('/orders?error=' + encodeURIComponent('Forbidden.'));
  try {
    const p = await startPayment(order.id);
    redirect(p.link);
  } catch (e: any) {
    redirect(`/payments/${orderNumber}?error=` + encodeURIComponent(e.message || 'Could not start payment.'));
  }
}
