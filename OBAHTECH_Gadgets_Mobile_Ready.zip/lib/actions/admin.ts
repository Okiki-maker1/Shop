'use server';

import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { getDb } from '@/lib/db';
import { getSessionUser, hashPassword, assertAdmin, assertSuperAdmin, type SessionUser } from '@/lib/auth';
import { changeOrderStatus, addOrderEvent, assignOrderToState } from '@/lib/orders';
import { notifyOrder, notifyCustomer, logAdmin, queueEmail, sendAnnouncement, deliverAnnouncement } from '@/lib/notify';
import { validatePair } from '@/lib/locations';
import { slugify, fmtDate } from '@/lib/format';
import { saveUpload } from '@/lib/uploads';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();
const n = (fd: FormData, k: string) => Number(fd.get(k) ?? 0);

async function admin(): Promise<SessionUser> {
  const u = await getSessionUser();
  if (!u || (u.role !== 'super_admin' && u.role !== 'state_admin')) redirect('/login?next=/admin');
  if (u.is_suspended) redirect('/login?error=suspended');
  return u;
}

async function superAdmin(): Promise<SessionUser> {
  const u = await admin();
  if (u.role !== 'super_admin') redirect('/admin?error=' + encodeURIComponent('Super administrator access required.'));
  return u;
}

function back(path: string, msg: string, tone: 'error' | 'ok' = 'error'): never {
  redirect(`${path}${path.includes('?') ? '&' : '?'}${tone}=${encodeURIComponent(msg)}`);
}

/** Loads an order and enforces state scoping for state administrators. */
async function scopedOrder(orderId: number, user: SessionUser) {
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) back('/admin/orders', 'Order not found.');
  if (user.role === 'state_admin' && order.state_id !== user.admin_state_id)
    back('/admin/orders', 'Access denied: that order belongs to another state.');
  return order;
}

// ─── Orders ────────────────────────────────────────────────────────────────
export async function adminChangeStatus(fd: FormData) {
  const user = await admin();
  const order = await scopedOrder(n(fd, 'order_id'), user);
  const status = s(fd, 'status');
  const note = s(fd, 'note') || null;
  try {
    await changeOrderStatus({ orderId: order.id, status, note, actor: user, skipTransitionCheck: user.role === 'super_admin' && fd.get('force') === '1' });
  } catch (e: any) {
    back(`/admin/orders/${order.id}`, e.message);
  }
  revalidatePath(`/admin/orders/${order.id}`);
  revalidatePath('/admin/orders');
  revalidatePath('/admin');
  back(`/admin/orders/${order.id}`, 'Order status updated.', 'ok');
}

export async function adminAssignOrder(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const orderId = n(fd, 'order_id');
  const adminId = n(fd, 'admin_id');
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) back('/admin/orders', 'Order not found.');
  let target: any = null;
  if (adminId) {
    target = await db.prepare("SELECT * FROM users WHERE id = ? AND role = 'state_admin'").get(adminId) as any;
    if (!target) back(`/admin/orders/${orderId}`, 'Selected administrator not found.');
    if (target.admin_state_id !== order.state_id)
      back(`/admin/orders/${orderId}`, 'An administrator can only be assigned to orders in their own state.');
  }
  await db.prepare("UPDATE orders SET assigned_admin_id = ?, updated_at = datetime('now') WHERE id = ?").run(target?.id ?? null, orderId);
  await db.prepare('INSERT INTO order_assignments (order_id, admin_id, admin_name, state_id, assigned_by, reason) VALUES (?,?,?,?,?,?)').run(
    orderId,
    target?.id ?? null,
    target?.full_name ?? null,
    order.state_id,
    user.id,
    s(fd, 'reason') || 'manual reassignment',
  );
  await addOrderEvent(orderId, order.status, `Order reassigned to ${target?.full_name ?? 'unassigned queue'} by ${user.full_name}`, user);
  await notifyOrder({
    orderId,
    type: 'order_modification',
    title: `Order ${order.order_number} reassigned${target ? ` to ${target.full_name}` : ' to the unassigned queue'}`,
    body: s(fd, 'reason') || 'Reassigned by the super administrator. Future notifications follow this assignment.',
  });
  await logAdmin(user, 'order.reassign', 'order', orderId, { adminId: target?.id ?? null });
  revalidatePath(`/admin/orders/${orderId}`);
  back(`/admin/orders/${orderId}`, 'Assignment updated.', 'ok');
}

export async function adminSetSerial(fd: FormData) {
  const user = await admin();
  const db = getDb();
  const itemId = n(fd, 'item_id');
  const item = await db.prepare('SELECT oi.*, o.state_id, o.order_number FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE oi.id = ?').get(itemId) as any;
  if (!item) back('/admin/orders', 'Item not found.');
  if (user.role === 'state_admin' && item.state_id !== user.admin_state_id) back('/admin/orders', 'Access denied.');
  await db.prepare('UPDATE order_items SET serial_no = ? WHERE id = ?').run(s(fd, 'serial_no') || null, itemId);
  await db.prepare('UPDATE warranties SET serial_no = ? WHERE order_item_id = ?').run(s(fd, 'serial_no') || null, itemId);
  await addOrderEvent(item.order_id, 'processing', `IMEI/serial recorded for ${item.name}`, user);
  await logAdmin(user, 'order.serial', 'order_item', itemId, { serial: s(fd, 'serial_no') });
  back(`/admin/orders/${item.order_id}`, 'Serial/IMEI saved.', 'ok');
}

// ─── Products ──────────────────────────────────────────────────────────────
export async function adminSaveProduct(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const name = s(fd, 'name');
  if (!name) back('/admin/products', 'Product name is required.');
  const categoryId = n(fd, 'category_id');
  const cat = await db.prepare('SELECT id FROM categories WHERE id = ?').get(categoryId);
  if (!cat) back('/admin/products', 'Choose a valid category.');
  const price = n(fd, 'price');
  if (price <= 0) back('/admin/products', 'Price must be greater than zero.');
  const data = {
    name,
    slug: id ? s(fd, 'slug') : slugify(name) + (await db.prepare('SELECT 1 FROM products WHERE slug = ?').get(slugify(name)) ? '-' + Date.now().toString(36).slice(-4) : ''),
    brand: s(fd, 'brand') || 'OBAHTECH',
    model: s(fd, 'model') || null,
    category_id: categoryId,
    description: s(fd, 'description') || null,
    short_description: s(fd, 'short_description') || null,
    ram: s(fd, 'ram') || null,
    battery: s(fd, 'battery') || null,
    screen_size: s(fd, 'screen_size') || null,
    network: s(fd, 'network') || null,
    condition: s(fd, 'condition') || 'New',
    warranty_months: n(fd, 'warranty_months') || 12,
    warranty_policy: s(fd, 'warranty_policy') || null,
    price,
    compare_price: n(fd, 'compare_price') || null,
    stock: n(fd, 'stock'),
    low_stock_at: n(fd, 'low_stock_at') || 5,
    sku: s(fd, 'sku') || `OBH-${Date.now().toString(36).toUpperCase()}`,
    tracks_serial: fd.get('tracks_serial') ? 1 : 0,
    is_featured: fd.get('is_featured') ? 1 : 0,
    is_flash_sale: fd.get('is_flash_sale') ? 1 : 0,
    flash_price: n(fd, 'flash_price') || null,
    is_active: fd.get('is_active') ? 1 : 0,
    storage_options: JSON.stringify(s(fd, 'storage_options').split(',').map((x) => x.trim()).filter(Boolean)),
    color_options: JSON.stringify(s(fd, 'color_options').split(',').map((x) => x.trim()).filter(Boolean)),
  };
  let productId = id;
  if (id) {
    await db.prepare(
      `UPDATE products SET name=@name, brand=@brand, model=@model, category_id=@category_id, description=@description,
        short_description=@short_description, ram=@ram, battery=@battery, screen_size=@screen_size, network=@network,
        condition=@condition, warranty_months=@warranty_months, warranty_policy=@warranty_policy, price=@price,
        compare_price=@compare_price, stock=@stock, low_stock_at=@low_stock_at, tracks_serial=@tracks_serial,
        is_featured=@is_featured, is_flash_sale=@is_flash_sale, flash_price=@flash_price, is_active=@is_active,
        storage_options=@storage_options, color_options=@color_options WHERE id=@id`,
    ).run({ ...data, id });
  } else {
    const res = await db.prepare(
      `INSERT INTO products (name, slug, brand, model, category_id, description, short_description, specs, ram, storage_options,
        color_options, battery, screen_size, network, condition, warranty_months, warranty_policy, price, compare_price, stock,
        low_stock_at, sku, tracks_serial, is_featured, is_flash_sale, flash_price, is_active)
       VALUES (@name,@slug,@brand,@model,@category_id,@description,@short_description,'{}',@ram,@storage_options,@color_options,
        @battery,@screen_size,@network,@condition,@warranty_months,@warranty_policy,@price,@compare_price,@stock,@low_stock_at,
        @sku,@tracks_serial,@is_featured,@is_flash_sale,@flash_price,@is_active)`,
    ).run(data);
    productId = Number(res.lastInsertRowid);
    await db.prepare('INSERT INTO product_images (product_id, url, sort_order) VALUES (?,?,0)').run(productId, '/products/phone-2.svg');
  }
  try {
    const url = await saveUpload(fd.get('image') as File, 'products');
    if (url) {
      const existing = (await db.prepare('SELECT COUNT(*) c FROM product_images WHERE product_id = ?').get(productId) as any).c;
      await db.prepare('INSERT INTO product_images (product_id, url, sort_order) VALUES (?,?,?)').run(productId, url, existing);
    }
    const extra = s(fd, 'image_url');
    if (extra) await db.prepare('INSERT INTO product_images (product_id, url, sort_order) VALUES (?,?,99)').run(productId, extra);
  } catch (e: any) {
    back('/admin/products', e.message);
  }
  await db.prepare('INSERT INTO stock_logs (product_id, change, reason, admin_id) VALUES (?,?,?,?)').run(productId, id ? 0 : data.stock, id ? 'product_edited' : 'product_created', user.id);
  await logAdmin(user, id ? 'product.update' : 'product.create', 'product', productId, { name });
  revalidatePath('/admin/products');
  revalidatePath('/');
  back('/admin/products', id ? 'Product updated.' : 'Product created.', 'ok');
}

export async function adminDeleteProduct(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  await db.prepare('UPDATE products SET is_active = 0 WHERE id = ?').run(id);
  await logAdmin(user, 'product.archive', 'product', id);
  back('/admin/products', 'Product archived (historical orders preserved).', 'ok');
}

export async function adminAdjustStock(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'product_id');
  const change = n(fd, 'change');
  const reason = s(fd, 'reason') || 'manual adjustment';
  const p = await db.prepare('SELECT * FROM products WHERE id = ?').get(id) as any;
  if (!p) back('/admin/inventory', 'Product not found.');
  if (p.stock + change < 0) back('/admin/inventory', 'Stock cannot go below zero.');
  await db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(change, id);
  await db.prepare('INSERT INTO stock_logs (product_id, change, reason, admin_id) VALUES (?,?,?,?)').run(id, change, reason, user.id);
  await logAdmin(user, 'inventory.adjust', 'product', id, { change, reason });
  back('/admin/inventory', 'Stock updated.', 'ok');
}

// ─── Categories ────────────────────────────────────────────────────────────
export async function adminSaveCategory(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const name = s(fd, 'name');
  if (!name) back('/admin/categories', 'Category name is required.');
  if (id) {
    await db.prepare('UPDATE categories SET name = ?, group_name = ?, sort_order = ?, is_active = ? WHERE id = ?').run(
      name,
      s(fd, 'group_name') || 'Devices',
      n(fd, 'sort_order'),
      fd.get('is_active') ? 1 : 0,
      id,
    );
  } else {
    const slug = slugify(name);
    if (await db.prepare('SELECT 1 FROM categories WHERE slug = ?').get(slug)) back('/admin/categories', 'A category with that name already exists.');
    await db.prepare('INSERT INTO categories (name, slug, group_name, sort_order, is_active) VALUES (?,?,?,?,?)').run(
      name,
      slug,
      s(fd, 'group_name') || 'Devices',
      n(fd, 'sort_order') || 99,
      fd.get('is_active') ? 1 : 0,
    );
  }
  await logAdmin(user, id ? 'category.update' : 'category.create', 'category', id || name);
  revalidatePath('/admin/categories');
  revalidatePath('/');
  back('/admin/categories', 'Category saved.', 'ok');
}

export async function adminDeleteCategory(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const used = (await db.prepare('SELECT COUNT(*) c FROM products WHERE category_id = ?').get(id) as any).c;
  if (used > 0) back('/admin/categories', `Cannot delete: ${used} product(s) still use this category. Reassign them first.`);
  await db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  await logAdmin(user, 'category.delete', 'category', id);
  back('/admin/categories', 'Category deleted.', 'ok');
}

export async function adminReorderCategory(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const dir = s(fd, 'dir') === 'up' ? -1 : 1;
  const row = await db.prepare('SELECT sort_order FROM categories WHERE id = ?').get(id) as any;
  if (row) await db.prepare('UPDATE categories SET sort_order = MAX(0, sort_order + ?) WHERE id = ?').run(dir, id);
  revalidatePath('/admin/categories');
  revalidatePath('/');
  back('/admin/categories', 'Order updated.', 'ok');
}

// ─── Banners & promotions ──────────────────────────────────────────────────
export async function adminSaveBanner(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const title = s(fd, 'title');
  if (!title) back('/admin/banners', 'Banner title is required.');
  let imageUrl = s(fd, 'image_url') || null;
  try {
    const up = await saveUpload(fd.get('image') as File, 'banners');
    if (up) imageUrl = up;
  } catch (e: any) {
    back('/admin/banners', e.message);
  }
  const data = {
    title,
    subtitle: s(fd, 'subtitle') || null,
    promo_text: s(fd, 'promo_text') || null,
    cta_label: s(fd, 'cta_label') || 'Shop now',
    cta_link: s(fd, 'cta_link') || '/category/all',
    image_url: imageUrl,
    bg_style: s(fd, 'bg_style') || 'orange',
    placement: s(fd, 'placement') || 'home_hero',
    starts_at: s(fd, 'starts_at') || null,
    ends_at: s(fd, 'ends_at') || null,
    is_active: fd.get('is_active') ? 1 : 0,
    sort_order: n(fd, 'sort_order'),
  };
  if (id) {
    await db.prepare(
      `UPDATE banners SET title=@title, subtitle=@subtitle, promo_text=@promo_text, cta_label=@cta_label, cta_link=@cta_link,
        image_url=@image_url, bg_style=@bg_style, placement=@placement, starts_at=@starts_at, ends_at=@ends_at,
        is_active=@is_active, sort_order=@sort_order WHERE id=@id`,
    ).run({ ...data, id });
  } else {
    await db.prepare(
      `INSERT INTO banners (title, subtitle, promo_text, cta_label, cta_link, image_url, bg_style, placement, starts_at, ends_at, is_active, sort_order)
       VALUES (@title,@subtitle,@promo_text,@cta_label,@cta_link,@image_url,@bg_style,@placement,@starts_at,@ends_at,@is_active,@sort_order)`,
    ).run(data);
  }
  await logAdmin(user, id ? 'banner.update' : 'banner.create', 'banner', id || title, data);
  revalidatePath('/');
  revalidatePath('/admin/banners');
  back('/admin/banners', 'Banner saved and live on the storefront.', 'ok');
}

export async function adminToggleBanner(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  await db.prepare('UPDATE banners SET is_active = ABS(is_active - 1) WHERE id = ?').run(id);
  await logAdmin(user, 'banner.toggle', 'banner', id);
  revalidatePath('/');
  back('/admin/banners', 'Banner visibility updated.', 'ok');
}

export async function adminDeleteBanner(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  await db.prepare('DELETE FROM banners WHERE id = ?').run(id);
  await logAdmin(user, 'banner.delete', 'banner', id);
  revalidatePath('/');
  back('/admin/banners', 'Banner deleted.', 'ok');
}

export async function adminSavePromo(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const code = s(fd, 'code').toUpperCase();
  if (!code) back('/admin/promotions', 'Discount code is required.');
  const data = {
    code,
    description: s(fd, 'description') || null,
    type: s(fd, 'type') || 'percent',
    value: n(fd, 'value'),
    min_order: n(fd, 'min_order'),
    max_uses: n(fd, 'max_uses') || null,
    starts_at: s(fd, 'starts_at') || null,
    ends_at: s(fd, 'ends_at') || null,
    is_active: fd.get('is_active') ? 1 : 0,
  };
  try {
    if (id) {
      await db.prepare('UPDATE promotions SET description=@description, type=@type, value=@value, min_order=@min_order, max_uses=@max_uses, starts_at=@starts_at, ends_at=@ends_at, is_active=@is_active WHERE id=@id').run({ ...data, id });
    } else {
      await db.prepare('INSERT INTO promotions (code, description, type, value, min_order, max_uses, starts_at, ends_at, is_active) VALUES (@code,@description,@type,@value,@min_order,@max_uses,@starts_at,@ends_at,@is_active)').run(data);
    }
  } catch {
    back('/admin/promotions', 'That discount code already exists.');
  }
  await logAdmin(user, id ? 'promotion.update' : 'promotion.create', 'promotion', id || code);
  back('/admin/promotions', 'Discount code saved.', 'ok');
}

export async function adminDeletePromo(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  await db.prepare('DELETE FROM promotions WHERE id = ?').run(n(fd, 'id'));
  back('/admin/promotions', 'Discount code deleted.', 'ok');
}

// ─── Administrators ────────────────────────────────────────────────────────
export async function adminCreateAdministrator(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const email = s(fd, 'email').toLowerCase();
  const fullName = s(fd, 'full_name');
  const password = s(fd, 'password');
  const stateId = n(fd, 'state_id');
  if (!email || !fullName) back('/admin/admins', 'Name and email are required.');
  if (password.length < 10) back('/admin/admins', 'Temporary password must be at least 10 characters.');
  if (await db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) back('/admin/admins', 'That email is already registered.');
  const state = await db.prepare('SELECT * FROM states WHERE id = ?').get(stateId) as any;
  if (!state) back('/admin/admins', 'Choose the state this administrator manages.');
  const active = await db.prepare("SELECT COUNT(*) c FROM users WHERE role='state_admin' AND admin_state_id = ? AND is_active = 1").get(stateId) as any;
  const res = await db
    .prepare(
      `INSERT INTO users (email, password_hash, full_name, phone, role, state_id, admin_state_id, email_verified, is_active)
       VALUES (?,?,?,?,'state_admin',?,?,1,1)`,
    )
    .run(email, hashPassword(password), fullName, s(fd, 'phone') || null, stateId, stateId);
  await logAdmin(user, 'admin.create', 'user', Number(res.lastInsertRowid), { email, state: state.name });
  await queueEmail(email, 'Your OBAHTECH Gadgets administrator account', `Hello ${fullName},\n\nYou have been provisioned as the OBAHTECH administrator for ${state.name} State.\nSign in at ${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/login with your email and the temporary password provided by the super administrator. Change it immediately after signing in.\n\n— OBAHTECH Gadgets`);
  back('/admin/admins', `Administrator created for ${state.name}.${active.c > 0 ? ' Note: a backup administrator already exists for this state.' : ''}`, 'ok');
}

export async function adminUpdateAdministrator(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const target = await db.prepare("SELECT * FROM users WHERE id = ? AND role = 'state_admin'").get(id) as any;
  if (!target) back('/admin/admins', 'Administrator not found.');
  const stateId = n(fd, 'state_id') || target.admin_state_id;
  await db.prepare('UPDATE users SET full_name = ?, phone = ?, admin_state_id = ?, state_id = ? WHERE id = ?').run(
    s(fd, 'full_name') || target.full_name,
    s(fd, 'phone') || target.phone,
    stateId,
    stateId,
    id,
  );
  await logAdmin(user, 'admin.update', 'user', id, { stateId });
  back('/admin/admins', 'Administrator updated.', 'ok');
}

export async function adminToggleAdministrator(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const target = await db.prepare("SELECT * FROM users WHERE id = ? AND role = 'state_admin'").get(id) as any;
  if (!target) back('/admin/admins', 'Administrator not found.');
  const suspend = s(fd, 'action') === 'suspend';
  await db.prepare('UPDATE users SET is_suspended = ? WHERE id = ?').run(suspend ? 1 : 0, id);
  if (suspend) await db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
  await logAdmin(user, suspend ? 'admin.suspend' : 'admin.reactivate', 'user', id);
  back('/admin/admins', suspend ? 'Administrator suspended and signed out.' : 'Administrator reactivated.', 'ok');
}

export async function adminDeleteAdministrator(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const target = await db.prepare("SELECT * FROM users WHERE id = ? AND role = 'state_admin'").get(id) as any;
  if (!target) back('/admin/admins', 'Administrator not found.');
  // Preserve historical records: deactivate + unassign, never hard-delete orders/logs.
  await db.prepare("UPDATE users SET is_active = 0, is_suspended = 1 WHERE id = ?").run(id);
  await db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
  const orders = await db.prepare('SELECT id FROM orders WHERE assigned_admin_id = ?').all(id) as any[];
  await db.prepare('UPDATE orders SET assigned_admin_id = NULL WHERE assigned_admin_id = ?').run(id);
  for (const o of orders) {
    await assignOrderToState(o.id, user, 'reassigned after administrator deletion');
  }
  await logAdmin(user, 'admin.delete', 'user', id, { affectedOrders: orders.length });
  const supers = await db.prepare("SELECT id FROM users WHERE role = 'super_admin'").all() as any[];
  for (const sp of supers) {
    await db.prepare("INSERT INTO notifications (type, audience, title, body, recipient_role, recipient_user_id) VALUES ('admin_change','admin',?,?,'super_admin',?)").run(
      `Administrator ${target.full_name} deleted`,
      `${orders.length} order(s) were moved to the state's active administrator or the unassigned queue. Historical records retained.`,
      sp.id,
    );
  }
  back('/admin/admins', `Administrator removed. ${orders.length} order(s) reassigned.`, 'ok');
}

export async function adminResetAdministratorPassword(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const id = n(fd, 'id');
  const password = s(fd, 'password');
  if (password.length < 10) back('/admin/admins', 'New password must be at least 10 characters.');
  const target = await db.prepare("SELECT * FROM users WHERE id = ? AND role IN ('state_admin','super_admin')").get(id) as any;
  if (!target) back('/admin/admins', 'Administrator not found.');
  await db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(password), id);
  await db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
  await logAdmin(user, 'admin.reset_password', 'user', id);
  await queueEmail(target.email, 'Your OBAHTECH password was reset', 'The super administrator reset your password. Sign in and change it immediately.');
  back('/admin/admins', 'Password reset and all sessions revoked.', 'ok');
}

// ─── Customer notifications / announcements ────────────────────────────────
export async function adminSendAnnouncement(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const title = s(fd, 'title');
  const body = s(fd, 'body');
  if (!title || !body) back('/admin/notifications', 'Title and message are required.');
  const audience = (s(fd, 'audience') || 'all') as any;
  const channels = ['in_app', fd.get('email') ? 'email' : null, fd.get('sms') ? 'sms' : null].filter(Boolean).join(',');
  const scheduledAt = s(fd, 'scheduled_at');
  const id = await sendAnnouncement({
    title,
    body,
    audience,
    stateId: audience === 'state' ? n(fd, 'state_id') : null,
    productId: audience === 'product_buyers' ? n(fd, 'product_id') : null,
    channels,
    scheduledAt: scheduledAt ? scheduledAt.replace('T', ' ') : null,
    sendNow: !scheduledAt,
    createdBy: user.id,
  });
  await logAdmin(user, 'announcement.create', 'announcement', id, { audience, channels });
  revalidatePath('/admin/notifications');
  back('/admin/notifications', scheduledAt ? 'Announcement scheduled.' : 'Announcement sent to customers.', 'ok');
}

export async function adminSendScheduledAnnouncement(fd: FormData) {
  const user =await  superAdmin();
  const id = n(fd, 'id');
  const count = await deliverAnnouncement(id);
  await logAdmin(user, 'announcement.send', 'announcement', id, { count });
  back('/admin/notifications', `Announcement delivered to ${count} customer(s).`, 'ok');
}

export async function adminDeleteAnnouncement(fd: FormData) {
  await superAdmin();
  await getDb().prepare('DELETE FROM announcements WHERE id = ?').run(n(fd, 'id'));
  back('/admin/notifications', 'Announcement deleted.', 'ok');
}

export async function adminNotifyStateCustomer(fd: FormData) {
  const user = await admin();
  const db = getDb();
  if (user.role !== 'state_admin') back('/admin/notifications', 'Use the super admin console for national announcements.');
  const orderId = n(fd, 'order_id');
  const order = await scopedOrder(orderId, user);
  const body = s(fd, 'body');
  if (!body) back(`/admin/orders/${orderId}`, 'Message body required.');
  if (order.user_id) {
    await notifyCustomer({ userId: order.user_id, type: 'order_status', title: `Message from your ${await stateNameSafe(order.state_id)} team`, body, orderId, stateId: order.state_id });
  }
  await logAdmin(user, 'customer.message', 'order', orderId);
  back(`/admin/orders/${orderId}`, 'Customer notified.', 'ok');
}

async function stateNameSafe(id: number) {
  const row = await getDb().prepare('SELECT name FROM states WHERE id = ?').get(id) as any;
  return row?.name ?? 'OBAHTECH';
}

// ─── Warranty claims ───────────────────────────────────────────────────────
export async function adminUpdateClaim(fd: FormData) {
  const user = await admin();
  const db = getDb();
  const id = n(fd, 'claim_id');
  const claim = await db.prepare('SELECT wc.*, o.state_id, o.order_number FROM warranty_claims wc JOIN orders o ON o.id = wc.order_id WHERE wc.id = ?').get(id) as any;
  if (!claim) back('/admin/warranties', 'Claim not found.');
  if (user.role === 'state_admin' && claim.state_id !== user.admin_state_id) back('/admin/warranties', 'Access denied: another state.');
  const status = s(fd, 'status');
  const note = s(fd, 'admin_note');
  await db.prepare("UPDATE warranty_claims SET status = ?, admin_note = ?, handled_by = ?, updated_at = datetime('now') WHERE id = ?").run(status, note, user.id, id);
  if (['repaired', 'replaced', 'closed', 'approved'].includes(status)) await db.prepare("UPDATE warranties SET status = 'claimed' WHERE id = ?").run(claim.warranty_id);
  await addOrderEvent(claim.order_id, 'return_requested', `Warranty claim #${id} → ${status}: ${note || ''}`, user);
  await notifyOrder({
    orderId: claim.order_id,
    type: 'warranty_claim',
    title: `Warranty claim #${id} updated — ${status.replace(/_/g, ' ')}`,
    body: note || `Claim status changed by ${user.full_name}.`,
  });
  if (claim.user_id)
    await notifyCustomer({ userId: claim.user_id, type: 'warranty', title: `Warranty claim #${id}: ${status.replace(/_/g, ' ')}`, body: note || 'Your claim was updated.', orderId: claim.order_id, stateId: claim.state_id });
  await logAdmin(user, 'warranty.update', 'warranty_claim', id, { status });
  back('/admin/warranties', 'Claim updated and both parties notified.', 'ok');
}

// ─── Returns & refunds ─────────────────────────────────────────────────────
export async function adminDecideReturn(fd: FormData) {
  const user = await admin();
  const db = getDb();
  const id = n(fd, 'return_id');
  const ret = await db.prepare('SELECT rr.*, o.state_id, o.total, o.order_number FROM return_requests rr JOIN orders o ON o.id = rr.order_id WHERE rr.id = ?').get(id) as any;
  if (!ret) back('/admin/returns', 'Return request not found.');
  if (user.role === 'state_admin' && ret.state_id !== user.admin_state_id) back('/admin/returns', 'Access denied: another state.');
  const decision = s(fd, 'decision');
  const note = s(fd, 'admin_note');
  const refundAmount = n(fd, 'refund_amount');
  if (decision === 'approved') {
    await db.prepare("UPDATE return_requests SET status = 'approved', admin_note = ?, refund_amount = ?, handled_by = ?, updated_at = datetime('now') WHERE id = ?").run(note, refundAmount || ret.total, user.id, id);
    await db.prepare("UPDATE orders SET status = 'refund_pending', payment_status = 'partial_refund', updated_at = datetime('now') WHERE id = ?").run(ret.order_id);
    await db.prepare('INSERT INTO refunds (order_id, return_id, amount, reason, status) VALUES (?,?,?,?,?)').run(ret.order_id, id, refundAmount || ret.total, note || 'Approved return', 'pending');
    await notifyOrder({
      orderId: ret.order_id,
      type: 'refund_requested',
      title: `Refund pending for ${ret.order_number} — ₦${(refundAmount || ret.total).toLocaleString()}`,
      body: `Return #${id} approved by ${user.full_name}. Awaiting refund processing.`,
    });
  } else {
    await db.prepare("UPDATE return_requests SET status = 'rejected', admin_note = ?, handled_by = ?, updated_at = datetime('now') WHERE id = ?").run(note, user.id, id);
    await db.prepare("UPDATE orders SET status = 'delivered', updated_at = datetime('now') WHERE id = ?").run(ret.order_id);
    await notifyOrder({ orderId: ret.order_id, type: 'return_requested', title: `Return #${id} rejected`, body: note || 'The return request did not meet policy.' });
  }
  if (ret.user_id)
    await notifyCustomer({ userId: ret.user_id, type: 'return', title: `Return #${id} ${decision}`, body: note || `Your return was ${decision}.`, orderId: ret.order_id, stateId: ret.state_id });
  await logAdmin(user, `return.${decision}`, 'return', id, { note });
  back('/admin/returns', `Return ${decision}.`, 'ok');
}

export async function adminCompleteRefund(fd: FormData) {
  const user = await admin();
  const db = getDb();
  const id = n(fd, 'refund_id');
  const refund = await db.prepare('SELECT r.*, o.order_number, o.state_id, o.user_id FROM refunds r JOIN orders o ON o.id = r.order_id WHERE r.id = ?').get(id) as any;
  if (!refund) back('/admin/returns', 'Refund not found.');
  if (user.role === 'state_admin' && refund.state_id !== user.admin_state_id) back('/admin/returns', 'Access denied.');
  const ref = s(fd, 'gateway_ref') || `REFUND-${Date.now().toString(36).toUpperCase()}`;
  await db.prepare("UPDATE refunds SET status = 'completed', completed_at = datetime('now'), gateway_ref = ?, processed_by = ? WHERE id = ?").run(ref, user.id, id);
  await db.prepare("UPDATE orders SET status = 'refunded', payment_status = 'refunded', updated_at = datetime('now') WHERE id = ?").run(refund.order_id);
  await db.prepare("INSERT INTO transactions (order_id, reference, type, amount, status) VALUES (?,?, 'refund', ?, 'successful')").run(refund.order_id, ref, refund.amount);
  await notifyOrder({ orderId: refund.order_id, type: 'refund_completed', title: `Refund completed for ${refund.order_number}`, body: `₦${refund.amount.toLocaleString()} refunded. Reference ${ref}.` });
  if (refund.user_id)
    await notifyCustomer({ userId: refund.user_id, type: 'return', title: `Refund completed for ${refund.order_number}`, body: `₦${refund.amount.toLocaleString()} has been refunded. Reference ${ref}.`, orderId: refund.order_id, stateId: refund.state_id });
  await logAdmin(user, 'refund.complete', 'refund', id, { ref });
  back('/admin/returns', 'Refund recorded.', 'ok');
}

// ─── Support tickets ───────────────────────────────────────────────────────
export async function adminReplyTicket(fd: FormData) {
  const user = await admin();
  const db = getDb();
  const id = n(fd, 'ticket_id');
  const ticket = await db.prepare('SELECT * FROM support_tickets WHERE id = ?').get(id) as any;
  if (!ticket) back('/admin/tickets', 'Ticket not found.');
  if (user.role === 'state_admin' && ticket.state_id && ticket.state_id !== user.admin_state_id)
    back('/admin/tickets', 'Access denied: ticket belongs to another state.');
  const body = s(fd, 'body');
  if (!body) back('/admin/tickets', 'Message body required.');
  await db.prepare("INSERT INTO ticket_messages (ticket_id, author_id, author_role, body) VALUES (?,?,?,?)").run(id, user.id, user.role, body);
  const status = s(fd, 'status');
  await db.prepare("UPDATE support_tickets SET status = COALESCE(NULLIF(?,''), status), assigned_admin_id = COALESCE(assigned_admin_id, ?), updated_at = datetime('now') WHERE id = ?").run(status, user.id, id);
  if (ticket.user_id) {
    await notifyCustomer({ userId: ticket.user_id, type: 'support_ticket', title: `Support replied to ${ticket.reference}`, body, orderId: ticket.order_id, stateId: ticket.state_id });
  }
  if (ticket.order_id)await  notifyOrder({ orderId: ticket.order_id, type: 'support_ticket', title: `Reply on ticket ${ticket.reference}`, body });
  await logAdmin(user, 'ticket.reply', 'ticket', id);
  back('/admin/tickets', 'Reply sent.', 'ok');
}

// ─── Delivery fees ─────────────────────────────────────────────────────────
export async function adminSaveDeliveryFee(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const pair =await  validatePair(db, n(fd, 'state_id'), n(fd, 'lga_id'));
  if (!pair.ok) back('/admin/delivery', pair.error!);
  await db.prepare('INSERT INTO delivery_fees (state_id, lga_id, method, fee, eta_days, min_order, is_active) VALUES (?,?,?,?,?,?,1)').run(
    pair.state!.id,
    pair.lga!.id,
    s(fd, 'method') || 'standard',
    n(fd, 'fee'),
    n(fd, 'eta_days') || 3,
    n(fd, 'min_order'),
  );
  await logAdmin(user, 'delivery_fee.create', 'delivery_fee', `${pair.state!.name}/${pair.lga!.name}`);
  back('/admin/delivery', 'Delivery rule saved.', 'ok');
}

export async function adminDeleteDeliveryFee(fd: FormData) {
  const user =await  superAdmin();
  await getDb().prepare('DELETE FROM delivery_fees WHERE id = ?').run(n(fd, 'id'));
  await logAdmin(user, 'delivery_fee.delete', 'delivery_fee', n(fd, 'id'));
  back('/admin/delivery', 'Delivery rule deleted.', 'ok');
}

export async function adminDeleteReview(fd: FormData) {
  const user =await  superAdmin();
  await getDb().prepare("UPDATE reviews SET status = 'hidden' WHERE id = ?").run(n(fd, 'id'));
  await logAdmin(user, 'review.hide', 'review', n(fd, 'id'));
  back('/admin/products', 'Review hidden from the storefront.', 'ok');
}

export async function adminMessageCustomer(fd: FormData) {
  const user =await  superAdmin();
  const db = getDb();
  const userId = n(fd, 'user_id');
  const body = s(fd, 'body');
  const target = await db.prepare("SELECT * FROM users WHERE id = ? AND role = 'customer'").get(userId) as any;
  if (!target) back('/admin/customers', 'Customer not found.');
  if (!body) back('/admin/customers', 'Message body required.');
  await notifyCustomer({ userId, type: 'announcement', title: 'Message from OBAHTECH Gadgets', body, stateId: target.state_id });
  await logAdmin(user, 'customer.message_direct', 'user', userId);
  back('/admin/customers', 'Message delivered to the customer.', 'ok');
}
