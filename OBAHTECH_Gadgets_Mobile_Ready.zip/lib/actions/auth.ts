'use server';

import { redirect } from 'next/navigation';
import crypto from 'node:crypto';
import { getDb } from '@/lib/db';
import { createVerificationToken } from '@/lib/verification';
import {
  createSession,
  destroySession,
  hashPassword,
  verifyPassword,
  rateLimit,
  clientIp,
  getSessionUser,
} from '@/lib/auth';
import { validatePair } from '@/lib/locations';
import { queueEmail, logAdmin } from '@/lib/notify';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();

function fail(path: string, msg: string, extra: Record<string, string> = {}): never {
  const q = new URLSearchParams({ error: msg, ...extra });
  redirect(`${path}?${q.toString()}`);
}

export async function registerAction(fd: FormData) {
  const db = getDb();
  const fullName = s(fd, 'full_name');
  const email = s(fd, 'email').toLowerCase();
  const phone = s(fd, 'phone');
  const password = s(fd, 'password');
  const confirm = s(fd, 'confirm_password');
  const stateId = Number(s(fd, 'state_id'));
  const lgaId = Number(s(fd, 'lga_id'));
  const back = '/register';
  const keep = { full_name: fullName, email, phone };

  const limit = rateLimit(`register:${clientIp()}`, 30, 10 * 60_000);
  if (!limit.ok) fail(back, 'Too many attempts. Please try again in a few minutes.', keep);
  if (!fullName || fullName.length < 3) fail(back, 'Enter your full name.', keep);
  if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) fail(back, 'Enter a valid email address.', keep);
  if (!/^0\d{10}$/.test(phone.replace(/[^0-9]/g, ''))) fail(back, 'Enter a valid Nigerian phone number (e.g. 08031234567).', keep);
  if (password.length < 8) fail(back, 'Password must be at least 8 characters.', keep);
  if (password !== confirm) fail(back, 'Passwords do not match.', keep);

  const pair =await  validatePair(db, stateId, lgaId);
  if (!pair.ok) fail(back, pair.error!, keep);

  const existing = await db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) fail(back, 'An account with that email already exists. Please sign in.', keep);

  const res = await db
    .prepare(
      `INSERT INTO users (email, password_hash, full_name, phone, role, state_id, lga_id, email_verified)
       VALUES (?,?,?,?,'customer',?,?,0)`,
    )
    .run(email, hashPassword(password), fullName, phone, pair.state!.id, pair.lga!.id);
  const userId = Number(res.lastInsertRowid);

  // default delivery address from registration data (delivery address stays immutable per order)
  await db.prepare(
    'INSERT INTO addresses (user_id, label, full_name, phone, state_id, lga_id, street, is_default) VALUES (?,?,?,?,?,?,?,1)',
  ).run(userId, 'Home', fullName, phone, pair.state!.id, pair.lga!.id, 'Add your street address');

  const token = await createVerificationToken(userId);
  await queueEmail(
    email,
    'Welcome to OBAHTECH Gadgets — verify your email',
    `Hi ${fullName},\n\nWelcome to OBAHTECH Gadgets.\n\nVerify your email address: ${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/verify?token=${token}\n\nYour delivery region: ${pair.state!.name} / ${pair.lga!.name}.\n\n— OBAHTECH Gadgets`,
  );
  await createSession(userId);
  redirect('/account?welcome=1');
}

export async function loginAction(fd: FormData) {
  const db = getDb();
  const email = s(fd, 'email').toLowerCase();
  const password = s(fd, 'password');
  const next = s(fd, 'next');
  const limit = rateLimit(`login:${clientIp()}:${email}`, 15, 5 * 60_000);
  if (!limit.ok) fail('/login', 'Too many sign-in attempts. Please wait a few minutes.');

  const user = await db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;
  // constant-ish response regardless of which field failed (no user enumeration)
  if (!user || !verifyPassword(password, user.password_hash)) {
    fail('/login', 'Invalid email or password.', { email });
  }
  if (user.is_suspended) fail('/login', 'This account is suspended. Contact the super administrator.', { email });
  if (!user.is_active) fail('/login', 'This account is inactive.', { email });

  await createSession(user.id);
  const dest = next && next.startsWith('/') ? next : user.role === 'customer' ? '/account' : '/admin';
  redirect(dest);
}

export async function logoutAction() {
  await destroySession();
  redirect('/login?message=' + encodeURIComponent('You have been signed out.'));
}

export async function forgotPasswordAction(fd: FormData) {
  const db = getDb();
  const email = s(fd, 'email').toLowerCase();
  const limit = rateLimit(`forgot:${clientIp()}`, 5, 10 * 60_000);
  if (!limit.ok) fail('/forgot-password', 'Too many requests. Try again later.');
  const user = await db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;
  if (user) {
    const token = crypto.randomBytes(32).toString('hex');
    const hash = crypto.createHash('sha256').update(token).digest('hex');
    await db.prepare("INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?,?,datetime('now','+1 hour'))").run(user.id, hash);
    await queueEmail(
      email,
      'Reset your OBAHTECH Gadgets password',
      `Use this link within 1 hour to reset your password:\n${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/reset-password?token=${token}`,
    );
  }
  redirect('/forgot-password?sent=1');
}

export async function resetPasswordAction(fd: FormData) {
  const db = getDb();
  const token = s(fd, 'token');
  const password = s(fd, 'password');
  const confirm = s(fd, 'confirm_password');
  if (password.length < 8) fail(`/reset-password?token=${token}`, 'Password must be at least 8 characters.');
  if (password !== confirm) fail(`/reset-password?token=${token}`, 'Passwords do not match.');
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  const row = await db
    .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > datetime('now')")
    .get(hash) as any;
  if (!row) fail('/forgot-password', 'That reset link is invalid or has expired. Request a new one.');
  await db.prepare('UPDATE users SET password_hash = ?, updated_at = datetime(\'now\') WHERE id = ?').run(hashPassword(password), row.user_id);
  await db.prepare("UPDATE password_resets SET used_at = datetime('now') WHERE id = ?").run(row.id);
  await db.prepare('DELETE FROM sessions WHERE user_id = ?').run(row.user_id);
  redirect('/login?message=' + encodeURIComponent('Password updated. Please sign in.'));
}

/** Secure first-run provisioning — refuses to run once a super admin exists. */
export async function setupSuperAdminAction(fd: FormData) {
  const db = getDb();
  const existing = await db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'super_admin'").get() as any;
  if (existing.c > 0) redirect('/setup?error=' + encodeURIComponent('Setup is locked: a super administrator already exists.'));
  const fullName = s(fd, 'full_name');
  const email = s(fd, 'email').toLowerCase();
  const phone = s(fd, 'phone');
  const password = s(fd, 'password');
  const confirm = s(fd, 'confirm_password');
  const key = s(fd, 'setup_key');
  if (process.env.SETUP_KEY && key !== process.env.SETUP_KEY) fail('/setup', 'Invalid setup key.');
  if (!fullName || password.length < 12) fail('/setup', 'Use your full name and a password of at least 12 characters.');
  if (password !== confirm) fail('/setup', 'Passwords do not match.');
  if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) fail('/setup', 'Enter a valid email address.');
  const res = await db
    .prepare("INSERT INTO users (email, password_hash, full_name, phone, role, email_verified, is_active) VALUES (?,?,?,?,'super_admin',1,1)")
    .run(email, hashPassword(password), fullName, phone || null);
  await logAdmin(null, 'super_admin.created', 'user', Number(res.lastInsertRowid), { email });
  await createSession(Number(res.lastInsertRowid));
  redirect('/admin?welcome=1');
}

export async function resendVerificationAction() {
  const user = await getSessionUser();
  if (!user) redirect('/login');
  const db = getDb();
  const row = await db.prepare('SELECT email_verified FROM users WHERE id = ?').get(user.id) as any;
  if (row?.email_verified) redirect('/account?message=' + encodeURIComponent('Your email is already verified.'));
  const limit = rateLimit(`verify:${user.id}`, 3, 10 * 60_000);
  if (!limit.ok) redirect('/account?message=' + encodeURIComponent('Please wait a few minutes before requesting another email.'));
  const token = await createVerificationToken(user.id);
  await queueEmail(user.email, 'Verify your OBAHTECH email', `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/verify?token=${token}`);
  redirect('/account?message=' + encodeURIComponent('Verification email sent — check your inbox.'));
}
