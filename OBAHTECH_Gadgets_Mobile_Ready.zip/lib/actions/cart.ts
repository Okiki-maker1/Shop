'use server';

import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { revalidatePath } from 'next/cache';
import { getSessionUser } from '@/lib/auth';
import { addToCart, updateCartQty, removeCartItem, PROMO_COOKIE } from '@/lib/cart';
import { getDb } from '@/lib/db';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();

async function requireCustomer(nextPath: string) {
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(nextPath)}`);
  return user;
}

export async function addToCartAction(fd: FormData) {
  const productId = Number(s(fd, 'product_id'));
  const qty = Number(s(fd, 'qty') || 1);
  const color = s(fd, 'color') || null;
  const storage = s(fd, 'storage') || null;
  const slug = s(fd, 'slug');
  const user = await requireCustomer(slug ? `/product/${slug}` : '/cart');
  try {
    await addToCart(user.id, productId, qty, color, storage);
  } catch (e: any) {
    redirect(`${slug ? `/product/${slug}` : '/cart'}?error=${encodeURIComponent(e.message)}`);
  }
  revalidatePath('/cart');
  redirect('/cart?added=1');
}

export async function updateQtyAction(fd: FormData) {
  const user = await requireCustomer('/cart');
  try {
    await updateCartQty(user.id, Number(s(fd, 'item_id')), Number(s(fd, 'qty')));
  } catch (e: any) {
    redirect(`/cart?error=${encodeURIComponent(e.message)}`);
  }
  revalidatePath('/cart');
  revalidatePath('/checkout');
}

export async function removeItemAction(fd: FormData) {
  const user = await requireCustomer('/cart');
  await removeCartItem(user.id, Number(s(fd, 'item_id')));
  revalidatePath('/cart');
  revalidatePath('/checkout');
}

export async function applyPromoAction(fd: FormData) {
  const code = s(fd, 'code').toUpperCase();
  const db = getDb();
  if (!code) {
    cookies().delete(PROMO_COOKIE);
    redirect('/cart?error=' + encodeURIComponent('Enter a discount code.'));
  }
  const promo = await db
    .prepare(
      `SELECT * FROM promotions WHERE code = ? AND is_active = 1
        AND (starts_at IS NULL OR starts_at <= datetime('now'))
        AND (ends_at IS NULL OR ends_at >= datetime('now'))`,
    )
    .get(code) as any;
  if (!promo) redirect('/cart?error=' + encodeURIComponent('That discount code is invalid or expired.'));
  if (promo.max_uses && promo.used_count >= promo.max_uses)
    redirect('/cart?error=' + encodeURIComponent('That discount code has been fully redeemed.'));
  cookies().set(PROMO_COOKIE, code, { path: '/', maxAge: 3600, sameSite: 'lax' });
  redirect('/cart?promo=1');
}

export async function clearPromoAction() {
  cookies().delete(PROMO_COOKIE);
  redirect('/cart');
}
