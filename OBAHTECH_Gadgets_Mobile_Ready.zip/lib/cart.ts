import { cookies } from 'next/headers';
import { getDb } from './db';
import { deliveryFeeFor } from './orders';

export const PROMO_COOKIE = 'obah_promo';

export async function getCartId(userId: number) {
  const db = getDb();
  let cart = await db.prepare('SELECT * FROM carts WHERE user_id = ?').get(userId) as any;
  if (!cart) {
    const res = await db.prepare('INSERT INTO carts (user_id) VALUES (?)').run(userId);
    cart = { id: Number(res.lastInsertRowid), user_id: userId };
  }
  return cart.id as number;
}

export type CartLine = {
  item_id: number;
  product_id: number;
  name: string;
  slug: string;
  brand: string;
  image: string | null;
  color: string | null;
  storage: string | null;
  qty: number;
  unit_price: number;
  line_total: number;
  stock_available: number;
  flash_price: number | null;
};

export async function getCartLines(userId: number): Promise<CartLine[]> {
  const db = getDb();
  const cartId = await getCartId(userId);
  return await db
    .prepare(
      `SELECT ci.id AS item_id, ci.product_id, ci.color, ci.storage, ci.qty,
              p.name, p.slug, p.brand, p.price, p.flash_price, p.is_flash_sale,
              (p.stock - p.reserved) AS stock_available,
              (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image,
              (CASE WHEN p.is_flash_sale = 1 AND p.flash_price IS NOT NULL THEN p.flash_price ELSE p.price END) AS unit_price,
              (CASE WHEN p.is_flash_sale = 1 AND p.flash_price IS NOT NULL THEN p.flash_price ELSE p.price END) * ci.qty AS line_total
         FROM cart_items ci JOIN products p ON p.id = ci.product_id
        WHERE ci.cart_id = ? ORDER BY ci.id DESC`,
    )
    .all(cartId) as CartLine[];
}

export async function cartCount(userId: number | null | undefined) {
  if (!userId) return 0;
  const db = getDb();
  const row = await db
    .prepare('SELECT COALESCE(SUM(ci.qty),0) c FROM cart_items ci JOIN carts c ON c.id = ci.cart_id WHERE c.user_id = ?')
    .get(userId) as any;
  return row?.c ?? 0;
}

export async function addToCart(userId: number, productId: number, qty = 1, color: string | null = null, storage: string | null = null) {
  const db = getDb();
  const p = await db.prepare('SELECT * FROM products WHERE id = ? AND is_active = 1').get(productId) as any;
  if (!p) throw new Error('Product unavailable.');
  const available = p.stock - p.reserved;
  if (available <= 0) throw new Error('This product is out of stock.');
  const cartId = await getCartId(userId);
  const existing = await db
    .prepare('SELECT * FROM cart_items WHERE cart_id = ? AND product_id = ? AND IFNULL(color,\'\') = IFNULL(?,\'\') AND IFNULL(storage,\'\') = IFNULL(?,\'\')')
    .get(cartId, productId, color, storage) as any;
  const q = Math.max(1, Math.floor(qty));
  const target = (existing?.qty ?? 0) + q;
  if (target > available) throw new Error(`Only ${available} unit(s) available.`);
  if (existing) await db.prepare('UPDATE cart_items SET qty = ? WHERE id = ?').run(target, existing.id);
  else await db.prepare('INSERT INTO cart_items (cart_id, product_id, color, storage, qty) VALUES (?,?,?,?,?)').run(cartId, productId, color, storage, q);
  await db.prepare("UPDATE carts SET updated_at = datetime('now') WHERE id = ?").run(cartId);
}

export async function updateCartQty(userId: number, itemId: number, qty: number) {
  const db = getDb();
  const cartId = await getCartId(userId);
  const item = await db
    .prepare('SELECT ci.*, p.stock, p.reserved FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.id = ? AND ci.cart_id = ?')
    .get(itemId, cartId) as any;
  if (!item) throw new Error('Cart item not found.');
  const available = item.stock - item.reserved;
  if (qty <= 0) {
    await db.prepare('DELETE FROM cart_items WHERE id = ?').run(itemId);
    return;
  }
  if (qty > available) throw new Error(`Only ${available} unit(s) available.`);
  await db.prepare('UPDATE cart_items SET qty = ? WHERE id = ?').run(Math.floor(qty), itemId);
}

export async function removeCartItem(userId: number, itemId: number) {
  const db = getDb();
  const cartId = await getCartId(userId);
  await db.prepare('DELETE FROM cart_items WHERE id = ? AND cart_id = ?').run(itemId, cartId);
}

export async function clearCart(userId: number) {
  const db = getDb();
  const cartId = await getCartId(userId);
  await db.prepare('DELETE FROM cart_items WHERE cart_id = ?').run(cartId);
}

export async function activePromo() {
  const code = cookies().get(PROMO_COOKIE)?.value;
  if (!code) return null;
  const db = getDb();
  return await db
    .prepare(
      `SELECT * FROM promotions WHERE code = ? AND is_active = 1
        AND (starts_at IS NULL OR starts_at <= datetime('now'))
        AND (ends_at IS NULL OR ends_at >= datetime('now'))`,
    )
    .get(code.toUpperCase()) as any;
}

export async function cartTotals(lines: CartLine[], stateId?: number | null, lgaId?: number | null, method = 'standard', promo?: any) {
  const subtotal = lines.reduce((s, l) => s + l.line_total, 0);
  let discount = 0;
  let freeDelivery = false;
  if (promo && subtotal >= (promo.min_order ?? 0)) {
    if (promo.type === 'percent') discount = Math.round((subtotal * promo.value) / 100);
    else if (promo.type === 'fixed') discount = Math.min(promo.value, subtotal);
    else if (promo.type === 'free_delivery') freeDelivery = true;
  }
  let deliveryFee = 0;
  let eta = 3;
  if (stateId) {
    const f = await deliveryFeeFor(stateId, lgaId ?? null, method, subtotal - discount);
    deliveryFee = freeDelivery ? 0 : f.fee;
    eta = f.eta;
  }
  const total = Math.max(0, subtotal - discount) + deliveryFee;
  return { subtotal, discount, deliveryFee, total, eta, itemCount: lines.reduce((s, l) => s + l.qty, 0) };
}
