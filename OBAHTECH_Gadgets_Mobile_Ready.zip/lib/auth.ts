import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { cookies, headers } from 'next/headers';
import { getDb } from './db';

const SESSION_COOKIE = 'obah_session';
const SESSION_DAYS = 14;

export type SessionUser = {
  id: number;
  email: string;
  full_name: string;
  phone: string | null;
  role: 'customer' | 'state_admin' | 'super_admin';
  state_id: number | null;
  lga_id: number | null;
  admin_state_id: number | null;
  avatar_url: string | null;
  state_name?: string | null;
  is_suspended: number;
};

export const hashPassword = (pw: string) => bcrypt.hashSync(pw, 10);
export const verifyPassword = (pw: string, hash: string) => {
  try {
    return bcrypt.compareSync(pw, hash);
  } catch {
    return false;
  }
};

const sha = (s: string) => crypto.createHash('sha256').update(s).digest('hex');

export async function createSession(userId: number) {
  const db = getDb();
  const raw = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  await db.prepare('INSERT INTO sessions (id, user_id, token_hash, expires_at) VALUES (?,?,?,?)').run(
    crypto.randomUUID(),
    userId,
    sha(raw),
    expires,
  );
  cookies().set(SESSION_COOKIE, raw, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: SESSION_DAYS * 86400,
  });
}

export async function destroySession() {
  const db = getDb();
  const raw = cookies().get(SESSION_COOKIE)?.value;
  if (raw) await db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(raw));
  cookies().delete(SESSION_COOKIE);
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const raw = cookies().get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  const db = getDb();
  const row = await db
    .prepare(
      `SELECT s.expires_at, u.id, u.email, u.full_name, u.phone, u.role, u.state_id, u.lga_id,
              u.admin_state_id, u.avatar_url, u.is_suspended, st.name AS state_name
         FROM sessions s
         JOIN users u ON u.id = s.user_id
         LEFT JOIN states st ON st.id = u.admin_state_id
        WHERE s.token_hash = ?`,
    )
    .get(sha(raw)) as any;
  if (!row) return null;
  if (new Date(row.expires_at).getTime() < Date.now()) {
    await db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(raw));
    return null;
  }
  if (row.is_suspended) return null;
  delete row.expires_at;
  return row as SessionUser;
}

export async function requireUser(): Promise<SessionUser> {
  const u = await getSessionUser();
  if (!u) throw new Error('AUTH_REQUIRED');
  return u;
}

export async function requireUserPage(redirectTo = '/login') {
  const { redirect } = await import('next/navigation');
  const u = await getSessionUser();
  if (!u) redirect(`${redirectTo}?next=${encodeURIComponent(currentPath())}`);
  return u!;
}

export async function requireAdminPage() {
  const { redirect } = await import('next/navigation');
  const u = await getSessionUser();
  if (!u || (u.role !== 'state_admin' && u.role !== 'super_admin')) redirect('/login?next=/admin');
  if (u.is_suspended) redirect('/login?error=suspended');
  return u!;
}

export async function requireSuperAdminPage() {
  const { redirect } = await import('next/navigation');
  const u = await requireAdminPage();
  if (u.role !== 'super_admin') redirect('/admin?error=forbidden');
  return u;
}

/** Server-side authorization helpers for mutations/API routes. */
export function assertAdmin(user: SessionUser | null) {
  if (!user || (user.role !== 'state_admin' && user.role !== 'super_admin')) throw new Error('FORBIDDEN');
  if (user.is_suspended) throw new Error('SUSPENDED');
  return user;
}
export function assertSuperAdmin(user: SessionUser | null) {
  const u = assertAdmin(user);
  if (u.role !== 'super_admin') throw new Error('FORBIDDEN');
  return u;
}

/**
 * State scoping — the single choke point that prevents cross-state access.
 * Super admins see everything; a state admin sees ONLY orders whose saved
 * delivery state matches their assignment (LGA-restricted when configured).
 */
export function orderScopeSql(user: SessionUser, alias = 'o') {
  if (user.role === 'super_admin') return { sql: '1=1', params: [] as any[] };
  if (!user.admin_state_id) return { sql: '1=0', params: [] as any[] };
  return { sql: `${alias}.state_id = ?`, params: [user.admin_state_id] as any[] };
}

export function canAccessOrder(user: SessionUser, order: any) {
  if (!order) return false;
  if (user.role === 'super_admin') return true;
  return user.role === 'state_admin' && user.admin_state_id === order.state_id;
}

function currentPath() {
  try {
    return headers().get('x-pathname') || '/';
  } catch {
    return '/';
  }
}

// ── Simple in-memory rate limiter (per process) ────────────────────────────
const buckets = new Map<string, { count: number; reset: number }>();
export function rateLimit(key: string, limit = 10, windowMs = 60_000) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset < now) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return { ok: true, remaining: limit - 1 };
  }
  b.count++;
  if (b.count > limit) return { ok: false, remaining: 0 };
  return { ok: true, remaining: limit - b.count };
}

export function clientIp() {
  try {
    const h = headers();
    return h.get('x-forwarded-for')?.split(',')[0]?.trim() || h.get('x-real-ip') || 'local';
  } catch {
    return 'local';
  }
}

/** CSRF defence for API routes: reject cross-site POSTs. */
export function assertSameOrigin(req?: Request) {
  const h = headers();
  const origin = h.get('origin');
  const host = h.get('host');
  if (!origin) return true; // same-origin navigations / server actions
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}
