import { seedLocations, stateByName, lgaByName } from './locations';
import bcrypt from 'bcryptjs';
import { slugify } from './format';

const P = (
  name: string,
  brand: string,
  model: string,
  cat: string,
  price: number,
  compare: number,
  stock: number,
  opts: Partial<{
    ram: string;
    storage: string[];
    colors: string[];
    battery: string;
    screen: string;
    network: string;
    condition: string;
    warranty: number;
    kind: string;
    tint: number;
    featured: boolean;
    flash: number | null;
    short: string;
    rating: number;
    reviews: number;
    serial: boolean;
    specs: Record<string, string>;
  }> = {},
) => ({ name, brand, model, cat, price, compare, stock, opts });

const PRODUCTS = [
  // ── Apple iPhones ────────────────────────────────────────────────────────
  P('Apple iPhone 15 Pro Max 256GB', 'Apple', 'iPhone 15 Pro Max', 'apple-iphones', 1450000, 1620000, 12, { ram: '8GB', storage: ['256GB', '512GB'], colors: ['Natural Titanium', 'Blue Titanium', 'Black Titanium'], battery: '4441mAh', screen: '6.7" Super Retina XDR 120Hz', network: '5G', warranty: 12, kind: 'phone', tint: 1, featured: true, short: 'Titanium flagship with A17 Pro and 5x telephoto camera.', rating: 4.8, reviews: 64, serial: true, specs: { Processor: 'A17 Pro', Camera: '48MP + 12MP + 12MP', OS: 'iOS 17', Charging: 'USB-C 25W, MagSafe' } }),
  P('Apple iPhone 15 128GB', 'Apple', 'iPhone 15', 'apple-iphones', 985000, 1120000, 18, { ram: '6GB', storage: ['128GB', '256GB'], colors: ['Pink', 'Blue', 'Black'], battery: '3349mAh', screen: '6.1" Super Retina XDR', network: '5G', warranty: 12, kind: 'phone', tint: 4, featured: true, flash: 925000, short: 'Dynamic Island, USB-C and a 48MP main camera.', rating: 4.7, reviews: 121, serial: true, specs: { Processor: 'A16 Bionic', Camera: '48MP + 12MP', OS: 'iOS 17' } }),
  P('Apple iPhone 14 128GB', 'Apple', 'iPhone 14', 'apple-iphones', 780000, 890000, 9, { ram: '6GB', storage: ['128GB', '256GB'], colors: ['Midnight', 'Starlight', 'Purple'], battery: '3279mAh', screen: '6.1" Super Retina XDR', network: '5G', warranty: 12, kind: 'phone', tint: 1, short: 'Reliable dual-camera iPhone with all-day battery.', rating: 4.6, reviews: 88, serial: true }),
  P('Apple iPhone 13 128GB', 'Apple', 'iPhone 13', 'apple-iphones', 625000, 720000, 15, { ram: '4GB', storage: ['128GB', '256GB'], colors: ['Blue', 'Midnight', 'Red'], battery: '3240mAh', screen: '6.1" Super Retina XDR', network: '5G', warranty: 12, kind: 'phone', tint: 1, short: 'Best-value iPhone with cinematic mode.', rating: 4.5, reviews: 210, serial: true }),
  P('Apple iPhone 11 64GB', 'Apple', 'iPhone 11', 'apple-iphones', 345000, 410000, 22, { ram: '4GB', storage: ['64GB', '128GB'], colors: ['Black', 'White', 'Green'], battery: '3110mAh', screen: '6.1" Liquid Retina', network: '4G LTE', warranty: 6, kind: 'phone', tint: 0, short: 'Affordable entry into the iPhone ecosystem.', rating: 4.3, reviews: 302, serial: true }),
  P('Apple iPhone SE (3rd Gen) 64GB', 'Apple', 'iPhone SE 3', 'apple-iphones', 395000, 450000, 7, { ram: '4GB', storage: ['64GB'], colors: ['Midnight', 'Starlight'], battery: '2018mAh', screen: '4.7" Retina HD', network: '5G', warranty: 12, kind: 'phone', tint: 0, short: 'Compact iPhone with Touch ID and A15 Bionic.', rating: 4.2, reviews: 41, serial: true }),

  // ── Samsung ──────────────────────────────────────────────────────────────
  P('Samsung Galaxy S24 Ultra 512GB', 'Samsung', 'Galaxy S24 Ultra', 'samsung-smartphones', 1380000, 1560000, 10, { ram: '12GB', storage: ['256GB', '512GB'], colors: ['Titanium Gray', 'Titanium Violet'], battery: '5000mAh', screen: '6.8" QHD+ AMOLED 120Hz', network: '5G', warranty: 12, kind: 'phone', tint: 2, featured: true, short: 'Galaxy AI, S Pen and a 200MP camera.', rating: 4.8, reviews: 73, serial: true, specs: { Processor: 'Snapdragon 8 Gen 3', Camera: '200MP quad', OS: 'Android 14, One UI 6.1' } }),
  P('Samsung Galaxy S23 FE 256GB', 'Samsung', 'Galaxy S23 FE', 'samsung-smartphones', 640000, 720000, 14, { ram: '8GB', storage: ['128GB', '256GB'], colors: ['Mint', 'Graphite'], battery: '4500mAh', screen: '6.4" AMOLED 120Hz', network: '5G', warranty: 12, kind: 'phone', tint: 3, flash: 599000, short: 'Fan Edition flagship experience at a fair price.', rating: 4.5, reviews: 52, serial: true }),
  P('Samsung Galaxy A55 5G 256GB', 'Samsung', 'Galaxy A55', 'samsung-smartphones', 385000, 435000, 26, { ram: '8GB', storage: ['128GB', '256GB'], colors: ['Awesome Iceblue', 'Awesome Navy'], battery: '5000mAh', screen: '6.6" Super AMOLED 120Hz', network: '5G', warranty: 12, kind: 'phone', tint: 1, featured: true, short: 'Premium mid-ranger with OIS and metal frame.', rating: 4.4, reviews: 167, serial: true }),
  P('Samsung Galaxy A15 128GB', 'Samsung', 'Galaxy A15', 'samsung-smartphones', 169000, 195000, 40, { ram: '4GB', storage: ['128GB'], colors: ['Blue Black', 'Light Blue'], battery: '5000mAh', screen: '6.5" Super AMOLED 90Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 5, short: 'Big AMOLED screen and two-day battery life.', rating: 4.2, reviews: 289, serial: true }),
  P('Samsung Galaxy Z Flip 5 256GB', 'Samsung', 'Galaxy Z Flip5', 'samsung-smartphones', 1050000, 1250000, 5, { ram: '8GB', storage: ['256GB'], colors: ['Cream', 'Graphite', 'Mint'], battery: '3700mAh', screen: '6.7" Foldable AMOLED', network: '5G', warranty: 12, kind: 'phone', tint: 2, short: 'Pocketable foldable with Flex Window.', rating: 4.4, reviews: 28, serial: true }),

  // ── Tecno ────────────────────────────────────────────────────────────────
  P('Tecno Camon 30 Premier 5G', 'Tecno', 'Camon 30 Premier', 'tecno-smartphones', 429000, 480000, 20, { ram: '12GB', storage: ['512GB'], colors: ['Iceland Basaltic Dark', 'Alps Snowy Silver'], battery: '5000mAh', screen: '6.77" LTPO AMOLED', network: '5G', warranty: 12, kind: 'phone', tint: 1, featured: true, short: 'PolarAce imaging system with Sony sensors.', rating: 4.5, reviews: 96, serial: true }),
  P('Tecno Camon 20 256GB', 'Tecno', 'Camon 20', 'tecno-smartphones', 215000, 245000, 33, { ram: '8GB', storage: ['256GB'], colors: ['Predawn Black', 'Serenity Blue'], battery: '5000mAh', screen: '6.67" AMOLED', network: '4G LTE', warranty: 12, kind: 'phone', tint: 2, short: 'Sharp AMOLED display and 64MP RGBW camera.', rating: 4.3, reviews: 142, serial: true }),
  P('Tecno Spark 20 Pro 256GB', 'Tecno', 'Spark 20 Pro', 'tecno-smartphones', 158000, 182000, 48, { ram: '8GB', storage: ['256GB'], colors: ['Magic Skin Green', 'Cyber White'], battery: '5000mAh', screen: '6.78" 120Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 3, flash: 145000, short: 'Budget hero with 108MP camera.', rating: 4.1, reviews: 355, serial: true }),
  P('Tecno Pova 6 Pro 5G 256GB', 'Tecno', 'Pova 6 Pro', 'tecno-smartphones', 295000, 330000, 17, { ram: '12GB', storage: ['256GB'], colors: ['Meteorite Grey', 'Comet Green'], battery: '6000mAh', screen: '6.78" AMOLED 120Hz', network: '5G', warranty: 12, kind: 'phone', tint: 0, short: 'Massive battery built for gaming.', rating: 4.3, reviews: 74, serial: true }),
  P('Tecno Phantom V Fold 5G', 'Tecno', 'Phantom V Fold', 'tecno-smartphones', 890000, 1010000, 4, { ram: '12GB', storage: ['256GB'], colors: ['Black Ripple'], battery: '5000mAh', screen: '7.85" Foldable LTPO', network: '5G', warranty: 12, kind: 'phone', tint: 0, short: 'Affordable foldable with a 7.85" inner display.', rating: 4.0, reviews: 12, serial: true }),

  // ── Infinix ──────────────────────────────────────────────────────────────
  P('Infinix Note 40 Pro 256GB', 'Infinix', 'Note 40 Pro', 'infinix-smartphones', 265000, 298000, 30, { ram: '8GB', storage: ['256GB'], colors: ['Obsidian Black', 'Titan Gold'], battery: '5000mAh', screen: '6.78" AMOLED 120Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 4, featured: true, short: 'All-round fast charging with magnetic MagCharge.', rating: 4.4, reviews: 118, serial: true }),
  P('Infinix Hot 50 128GB', 'Infinix', 'Hot 50', 'infinix-smartphones', 142000, 165000, 55, { ram: '8GB', storage: ['128GB'], colors: ['Sleek Black', 'Vibrant Blue'], battery: '5000mAh', screen: '6.7" 120Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 3, short: 'Slim, tough and very affordable.', rating: 4.2, reviews: 401, serial: true }),
  P('Infinix Zero 30 5G 256GB', 'Infinix', 'Zero 30', 'infinix-smartphones', 310000, 355000, 16, { ram: '12GB', storage: ['256GB'], colors: ['Golden Hour', 'Rome Green'], battery: '5000mAh', screen: '6.78" AMOLED 144Hz', network: '5G', warranty: 12, kind: 'phone', tint: 3, short: '4K selfie video and 144Hz curved AMOLED.', rating: 4.3, reviews: 63, serial: true }),
  P('Infinix Smart 9 64GB', 'Infinix', 'Smart 9', 'infinix-smartphones', 89000, 105000, 60, { ram: '4GB', storage: ['64GB'], colors: ['Mystic Purple', 'Metallic Black'], battery: '5000mAh', screen: '6.6" 90Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 5, short: 'A dependable first smartphone.', rating: 4.0, reviews: 233, serial: true }),

  // ── Redmi / Xiaomi ───────────────────────────────────────────────────────
  P('Xiaomi Redmi Note 13 Pro 256GB', 'Xiaomi', 'Redmi Note 13 Pro', 'redmi-xiaomi', 265000, 299000, 28, { ram: '8GB', storage: ['256GB'], colors: ['Midnight Black', 'Ocean Teal'], battery: '5100mAh', screen: '6.67" AMOLED 120Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 3, featured: true, short: '200MP camera with 67W turbo charging.', rating: 4.5, reviews: 189, serial: true }),
  P('Xiaomi Redmi 13C 128GB', 'Xiaomi', 'Redmi 13C', 'redmi-xiaomi', 112000, 128000, 44, { ram: '6GB', storage: ['128GB'], colors: ['Clover Green', 'Navy Blue'], battery: '5000mAh', screen: '6.74" 90Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 3, flash: 104000, short: 'Great value 50MP camera phone.', rating: 4.1, reviews: 312, serial: true }),
  P('Xiaomi 14 5G 512GB', 'Xiaomi', 'Xiaomi 14', 'redmi-xiaomi', 980000, 1100000, 6, { ram: '12GB', storage: ['256GB', '512GB'], colors: ['Jade Green', 'Black'], battery: '4610mAh', screen: '6.36" LTPO AMOLED', network: '5G', warranty: 12, kind: 'phone', tint: 1, short: 'Leica optics in a compact flagship.', rating: 4.7, reviews: 37, serial: true }),
  P('Xiaomi POCO X6 Pro 256GB', 'Xiaomi', 'POCO X6 Pro', 'redmi-xiaomi', 315000, 360000, 19, { ram: '12GB', storage: ['256GB'], colors: ['Yellow', 'Black'], battery: '5000mAh', screen: '6.67" AMOLED 120Hz', network: '5G', warranty: 12, kind: 'phone', tint: 5, short: 'Gaming-grade performance per naira.', rating: 4.4, reviews: 88, serial: true }),

  // ── Google Pixel ─────────────────────────────────────────────────────────
  P('Google Pixel 8 Pro 256GB', 'Google', 'Pixel 8 Pro', 'google-pixel', 1120000, 1250000, 5, { ram: '12GB', storage: ['128GB', '256GB'], colors: ['Obsidian', 'Porcelain'], battery: '5050mAh', screen: '6.7" LTPO OLED', network: '5G', warranty: 12, kind: 'phone', tint: 0, featured: true, short: 'Best-in-class computational photography.', rating: 4.7, reviews: 44, serial: true }),
  P('Google Pixel 8 128GB', 'Google', 'Pixel 8', 'google-pixel', 845000, 940000, 8, { ram: '8GB', storage: ['128GB'], colors: ['Hazel', 'Obsidian'], battery: '4575mAh', screen: '6.2" OLED 120Hz', network: '5G', warranty: 12, kind: 'phone', tint: 1, short: 'Compact Pixel with 7 years of updates.', rating: 4.6, reviews: 31, serial: true }),
  P('Google Pixel 7a 128GB', 'Google', 'Pixel 7a', 'google-pixel', 520000, 590000, 11, { ram: '8GB', storage: ['128GB'], colors: ['Charcoal', 'Sea'], battery: '4385mAh', screen: '6.1" OLED 90Hz', network: '5G', warranty: 12, kind: 'phone', tint: 2, short: 'The affordable way into Pixel cameras.', rating: 4.4, reviews: 57, serial: true }),

  // ── Itel ─────────────────────────────────────────────────────────────────
  P('Itel A70 128GB', 'Itel', 'A70', 'itel', 72000, 85000, 70, { ram: '4GB', storage: ['128GB'], colors: ['Starry Black', 'Azure Blue'], battery: '5000mAh', screen: '6.6" HD+', network: '4G LTE', warranty: 12, kind: 'phone', tint: 2, short: 'Budget-friendly 128GB storage.', rating: 3.9, reviews: 224, serial: true }),
  P('Itel S24 128GB', 'Itel', 'S24', 'itel', 96000, 112000, 52, { ram: '8GB', storage: ['128GB'], colors: ['Meteor Black', 'Sunrise Gold'], battery: '5000mAh', screen: '6.6" 90Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 5, short: '50MP selfie camera for creators.', rating: 4.0, reviews: 176, serial: true }),
  P('Itel P55 128GB', 'Itel', 'P55', 'itel', 105000, 122000, 38, { ram: '8GB', storage: ['128GB'], colors: ['Galaxy Blue', 'Mystery White'], battery: '5000mAh', screen: '6.6" 90Hz', network: '4G LTE', warranty: 12, kind: 'phone', tint: 1, short: 'Fast charging on a budget.', rating: 4.1, reviews: 143, serial: true }),

  // ── Nokia ────────────────────────────────────────────────────────────────
  P('Nokia G42 5G 128GB', 'Nokia', 'G42 5G', 'nokia', 148000, 168000, 19, { ram: '6GB', storage: ['128GB'], colors: ['So Purple', 'So Grey'], battery: '5000mAh', screen: '6.56" 90Hz', network: '5G', warranty: 12, kind: 'phone', tint: 2, short: 'QuickFix repairable design, 3 years of updates.', rating: 4.2, reviews: 39, serial: true }),
  P('Nokia X30 5G 256GB', 'Nokia', 'X30 5G', 'nokia', 395000, 450000, 9, { ram: '8GB', storage: ['256GB'], colors: ['Ice White', 'Cloudy Blue'], battery: '4200mAh', screen: '6.43" AMOLED 90Hz', network: '5G', warranty: 12, kind: 'phone', tint: 0, short: 'Recycled aluminium build and PureView camera.', rating: 4.1, reviews: 22, serial: true }),
  P('Nokia 105 (2023) Dual SIM', 'Nokia', '105', 'nokia', 22500, 26000, 120, { ram: '4MB', storage: ['128MB'], colors: ['Charcoal', 'Blue'], battery: '1000mAh', screen: '1.8" QQVGA', network: '2G', warranty: 12, kind: 'phone', tint: 0, short: 'Legendary battery life feature phone.', rating: 4.4, reviews: 512 }),

  // ── Tablets ──────────────────────────────────────────────────────────────
  P('Apple iPad (10th Gen) 64GB Wi-Fi', 'Apple', 'iPad 10', 'tablets', 680000, 760000, 13, { ram: '4GB', storage: ['64GB', '256GB'], colors: ['Blue', 'Silver'], battery: '7606mAh', screen: '10.9" Liquid Retina', network: 'Wi-Fi', warranty: 12, kind: 'tablet', tint: 1, featured: true, short: 'Colourful all-screen iPad with USB-C.', rating: 4.6, reviews: 61, serial: true }),
  P('Samsung Galaxy Tab S9 FE 128GB', 'Samsung', 'Galaxy Tab S9 FE', 'tablets', 565000, 640000, 10, { ram: '6GB', storage: ['128GB'], colors: ['Mint', 'Gray'], battery: '8000mAh', screen: '10.9" TFT 90Hz', network: 'Wi-Fi', warranty: 12, kind: 'tablet', tint: 3, short: 'S Pen included with a vivid display.', rating: 4.3, reviews: 34, serial: true }),
  P('Xiaomi Pad 6 256GB', 'Xiaomi', 'Pad 6', 'tablets', 345000, 395000, 15, { ram: '8GB', storage: ['128GB', '256GB'], colors: ['Graphite Grey', 'Mist Blue'], battery: '8840mAh', screen: '11" 144Hz', network: 'Wi-Fi', warranty: 12, kind: 'tablet', tint: 0, short: '144Hz tablet made for streaming and study.', rating: 4.4, reviews: 47, serial: true }),
  P('Lenovo Tab M11 128GB', 'Lenovo', 'Tab M11', 'tablets', 215000, 245000, 18, { ram: '4GB', storage: ['128GB'], colors: ['Luna Grey'], battery: '7040mAh', screen: '11" FHD+ 90Hz', network: 'Wi-Fi', warranty: 12, kind: 'tablet', tint: 0, short: 'Budget tablet with pen support.', rating: 4.0, reviews: 26, serial: true }),

  // ── Smartwatches ─────────────────────────────────────────────────────────
  P('Apple Watch SE (2nd Gen) 40mm', 'Apple', 'Watch SE 2', 'smartwatches', 285000, 320000, 14, { storage: ['32GB'], colors: ['Midnight', 'Starlight'], battery: 'Up to 18h', screen: '40mm Retina LTPO', network: 'Bluetooth', warranty: 12, kind: 'watch', tint: 1, featured: true, short: 'Health and safety essentials on your wrist.', rating: 4.5, reviews: 58 }),
  P('Samsung Galaxy Watch 6 44mm', 'Samsung', 'Galaxy Watch6', 'smartwatches', 325000, 370000, 11, { ram: '2GB', storage: ['16GB'], colors: ['Graphite', 'Silver'], battery: '425mAh', screen: '1.5" AMOLED', network: 'Bluetooth', warranty: 12, kind: 'watch', tint: 0, short: 'Advanced sleep coaching and body composition.', rating: 4.4, reviews: 42 }),
  P('Amazfit GTS 4 Mini', 'Amazfit', 'GTS 4 Mini', 'smartwatches', 68000, 79000, 35, { storage: ['—'], colors: ['Midnight Black', 'Moonlight White'], battery: '270mAh (15 days)', screen: '1.65" AMOLED', network: 'Bluetooth', warranty: 12, kind: 'watch', tint: 3, flash: 61500, short: 'Two weeks of battery and 120+ sport modes.', rating: 4.2, reviews: 96 }),
  P('Xiaomi Redmi Watch 4', 'Xiaomi', 'Redmi Watch 4', 'smartwatches', 52000, 62000, 41, { storage: ['—'], colors: ['Obsidian Black', 'Silver Grey'], battery: '470mAh (20 days)', screen: '1.97" AMOLED', network: 'Bluetooth', warranty: 12, kind: 'watch', tint: 2, short: 'Large AMOLED display at an entry price.', rating: 4.1, reviews: 133 }),

  // ── Bluetooth speakers ───────────────────────────────────────────────────
  P('JBL Flip 6 Portable Speaker', 'JBL', 'Flip 6', 'bluetooth-speakers', 115000, 132000, 25, { colors: ['Black', 'Blue', 'Red'], battery: '4800mAh (12h)', screen: '—', network: 'Bluetooth 5.1', warranty: 12, kind: 'speaker', tint: 0, featured: true, short: 'Bold JBL Pro Sound, IP67 waterproof.', rating: 4.7, reviews: 84 }),
  P('Anker Soundcore Motion 300', 'Anker', 'Motion 300', 'bluetooth-speakers', 78000, 89000, 21, { colors: ['Black', 'Green'], battery: '13h playtime', screen: '—', network: 'Bluetooth 5.3', warranty: 12, kind: 'speaker', tint: 3, short: 'Hi-Res spatial audio in a portable body.', rating: 4.4, reviews: 39 }),
  P('Oraimo BoomPop 2 Speaker', 'Oraimo', 'BoomPop 2', 'bluetooth-speakers', 34500, 42000, 44, { colors: ['Black', 'Blue'], battery: '10h playtime', screen: '—', network: 'Bluetooth 5.0', warranty: 12, kind: 'speaker', tint: 2, flash: 31500, short: 'Punchy bass for the price.', rating: 4.1, reviews: 267 }),

  // ── Earphones & headphones ───────────────────────────────────────────────
  P('Apple AirPods Pro (2nd Gen, USB-C)', 'Apple', 'AirPods Pro 2', 'earphones-headphones', 285000, 320000, 17, { colors: ['White'], battery: '6h + 30h case', screen: '—', network: 'Bluetooth 5.3', warranty: 12, kind: 'earbuds', tint: 5, featured: true, short: 'Active noise cancellation with adaptive audio.', rating: 4.8, reviews: 156, serial: true }),
  P('Samsung Galaxy Buds FE', 'Samsung', 'Galaxy Buds FE', 'earphones-headphones', 78000, 92000, 29, { colors: ['Graphite', 'White'], battery: '8.5h + 21h case', screen: '—', network: 'Bluetooth 5.2', warranty: 12, kind: 'earbuds', tint: 0, short: 'ANC earbuds that fit your everyday.', rating: 4.3, reviews: 71 }),
  P('Oraimo FreePods 4 ANC', 'Oraimo', 'FreePods 4', 'earphones-headphones', 24500, 30000, 66, { colors: ['Black', 'White'], battery: '6h + 24h case', screen: '—', network: 'Bluetooth 5.2', warranty: 12, kind: 'earbuds', tint: 1, flash: 21900, short: 'Best-selling budget ANC earbuds.', rating: 4.2, reviews: 588 }),
  P('Sony WH-CH720N Headphones', 'Sony', 'WH-CH720N', 'earphones-headphones', 118000, 138000, 12, { colors: ['Black', 'White'], battery: '35h playtime', screen: '—', network: 'Bluetooth 5.2', warranty: 12, kind: 'earbuds', tint: 0, short: 'Lightweight over-ear noise cancelling.', rating: 4.5, reviews: 44 }),

  // ── Chargers ─────────────────────────────────────────────────────────────
  P('Apple 20W USB-C Power Adapter', 'Apple', 'MHJA3', 'phone-chargers', 18500, 22000, 90, { colors: ['White'], battery: '20W output', network: 'USB-C PD', warranty: 6, kind: 'charger', tint: 5, short: 'Genuine fast charger for iPhone.', rating: 4.7, reviews: 210 }),
  P('Samsung 45W USB-C Super Fast Charger', 'Samsung', 'EP-T4510', 'phone-chargers', 25000, 30000, 64, { colors: ['Black', 'White'], battery: '45W output', network: 'USB-C PD 3.0', warranty: 6, kind: 'charger', tint: 0, short: 'Charge a Galaxy from 0–65% in 30 minutes.', rating: 4.5, reviews: 88 }),
  P('Oraimo 33W Fast Charger + Cable', 'Oraimo', 'OCW-U75S', 'phone-chargers', 9800, 12500, 140, { colors: ['White', 'Black'], battery: '33W output', network: 'USB-A + USB-C', warranty: 6, kind: 'charger', tint: 5, short: 'Reliable everyday fast charger.', rating: 4.3, reviews: 421 }),

  // ── Power banks ──────────────────────────────────────────────────────────
  P('Anker PowerCore 20000mAh 22.5W', 'Anker', 'A1287', 'power-banks', 42000, 49000, 31, { colors: ['Black'], battery: '20000mAh', network: 'USB-C + USB-A', warranty: 12, kind: 'powerbank', tint: 0, featured: true, short: 'Charges a phone four times over.', rating: 4.7, reviews: 132 }),
  P('Oraimo 20000mAh Power Bank', 'Oraimo', 'OPB-P208DN', 'power-banks', 26500, 32000, 58, { colors: ['Black', 'Blue'], battery: '20000mAh', network: 'USB-C + dual USB-A', warranty: 12, kind: 'powerbank', tint: 1, flash: 23900, short: 'Fast-charging power bank with digital display.', rating: 4.4, reviews: 376 }),
  P('Xiaomi 10000mAh Slim Power Bank', 'Xiaomi', 'PB100LZM', 'power-banks', 21000, 25000, 47, { colors: ['Silver', 'Black'], battery: '10000mAh', network: 'USB-C 22.5W', warranty: 6, kind: 'powerbank', tint: 5, short: 'Pocket-sized with 22.5W output.', rating: 4.3, reviews: 199 }),

  // ── Phone cases ──────────────────────────────────────────────────────────
  P('iPhone 15 Silicone Case with MagSafe', 'Apple', 'MT2D3', 'phone-cases', 8500, 11000, 120, { colors: ['Storm Blue', 'Black', 'Clay'], network: 'MagSafe', warranty: 3, kind: 'phonecase', tint: 1, short: 'Soft-touch silicone with MagSafe magnets.', rating: 4.4, reviews: 94 }),
  P('Samsung Galaxy A55 Clear Case', 'Samsung', 'EF-QA556', 'phone-cases', 6500, 8500, 150, { colors: ['Transparent'], network: '—', warranty: 3, kind: 'phonecase', tint: 0, short: 'Slim transparent shockproof case.', rating: 4.1, reviews: 61 }),
  P('Tecno Camon 30 Shockproof Case', 'Tecno', 'CAM30-CASE', 'phone-cases', 5000, 7000, 200, { colors: ['Black', 'Green'], network: '—', warranty: 3, kind: 'phonecase', tint: 3, short: 'Reinforced corners, raised camera lip.', rating: 4.0, reviews: 45 }),

  // ── Screen protectors ────────────────────────────────────────────────────
  P('iPhone 15 Tempered Glass (2-Pack)', 'OBAHTECH', 'TG-IP15', 'screen-protectors', 6000, 8000, 210, { colors: ['Clear'], network: '—', warranty: 3, kind: 'glass', tint: 1, short: '9H hardness with installation kit.', rating: 4.5, reviews: 312 }),
  P('Universal Privacy Screen Guard', 'OBAHTECH', 'TG-PRIV', 'screen-protectors', 5500, 7500, 180, { colors: ['Clear'], network: '—', warranty: 3, kind: 'glass', tint: 0, short: 'Blocks side-angle viewing.', rating: 4.2, reviews: 87 }),
  P('Samsung Galaxy A15 Tempered Glass', 'OBAHTECH', 'TG-A15', 'screen-protectors', 4500, 6000, 240, { colors: ['Clear'], network: '—', warranty: 3, kind: 'glass', tint: 3, short: 'Full-coverage edge-to-edge glass.', rating: 4.3, reviews: 128 }),

  // ── Other electronics ────────────────────────────────────────────────────
  P('Oraimo 32" Smart LED Television', 'Oraimo', 'OS-TV32', 'other-electronics', 145000, 168000, 9, { colors: ['Black'], screen: '32" HD Ready', network: 'Wi-Fi, HDMI x2', warranty: 12, kind: 'electronics', tint: 0, short: 'Smart TV with built-in streaming apps.', rating: 4.2, reviews: 33 }),
  P('Xiaomi Mi TV Stick 4K', 'Xiaomi', 'MDZ-27-AA', 'other-electronics', 45000, 52000, 27, { colors: ['Black'], screen: '—', network: 'Wi-Fi, HDMI', warranty: 12, kind: 'electronics', tint: 2, short: 'Turn any TV into a 4K Android TV.', rating: 4.4, reviews: 76 }),
  P('Anker Bluetooth Audio Transmitter', 'Anker', 'A3230', 'other-electronics', 18000, 22000, 38, { colors: ['Black'], network: 'Bluetooth 5.0, 3.5mm', warranty: 12, kind: 'electronics', tint: 0, short: 'Add Bluetooth to your car or home audio.', rating: 4.1, reviews: 54 }),
  P('Oraimo Surge-Protected Extension Board', 'Oraimo', 'OPB-B01', 'other-electronics', 12500, 15500, 72, { colors: ['White'], network: '4 sockets + USB', warranty: 12, kind: 'electronics', tint: 5, short: 'Four sockets, two USB ports, surge protection.', rating: 4.3, reviews: 118 }),
];

const CATEGORIES: [string, string, string, string][] = [
  ['Apple iPhones', 'apple-iphones', 'Smartphones', 'phone'],
  ['Samsung Smartphones', 'samsung-smartphones', 'Smartphones', 'phone'],
  ['Tecno Smartphones', 'tecno-smartphones', 'Smartphones', 'phone'],
  ['Infinix Smartphones', 'infinix-smartphones', 'Smartphones', 'phone'],
  ['Redmi & Xiaomi', 'redmi-xiaomi', 'Smartphones', 'phone'],
  ['Google Pixel', 'google-pixel', 'Smartphones', 'phone'],
  ['Itel', 'itel', 'Smartphones', 'phone'],
  ['Nokia', 'nokia', 'Smartphones', 'phone'],
  ['Tablets', 'tablets', 'Devices', 'tablet'],
  ['Smartwatches', 'smartwatches', 'Accessories', 'watch'],
  ['Bluetooth Speakers', 'bluetooth-speakers', 'Accessories', 'speaker'],
  ['Earphones & Headphones', 'earphones-headphones', 'Accessories', 'earbuds'],
  ['Phone Chargers', 'phone-chargers', 'Accessories', 'charger'],
  ['Power Banks', 'power-banks', 'Accessories', 'powerbank'],
  ['Phone Cases', 'phone-cases', 'Accessories', 'phonecase'],
  ['Screen Protectors', 'screen-protectors', 'Accessories', 'glass'],
  ['Other Electronics', 'other-electronics', 'Devices', 'electronics'],
];

const ROLE_PERMS: Record<string, string[]> = {
  super_admin: [
    'orders.view_all', 'orders.manage_all', 'orders.reassign', 'products.manage', 'categories.manage',
    'banners.manage', 'promotions.manage', 'admins.manage', 'customers.notify', 'analytics.nationwide',
    'returns.manage', 'warranties.manage', 'refunds.approve', 'tickets.manage', 'inventory.manage', 'settings.manage',
  ],
  state_admin: [
    'orders.view_state', 'orders.manage_state', 'deliveries.update_state', 'returns.review_state',
    'warranties.review_state', 'tickets.manage_state', 'analytics.state',
  ],
  customer: ['cart.manage', 'orders.own', 'reviews.write', 'warranty.claim', 'returns.request', 'support.open'],
};

export async function ensureSeeded(db: any) {
  await seedLocations(db);
  const already = ((await db.prepare('SELECT COUNT(*) c FROM categories').get()) as any).c as number;
  if (already > 0) return;

  const run = db.transaction(async () => {
    // roles + permissions
    const roles: [string, string, string][] = [
      ['super_admin', 'Super Administrator', 'Nationwide control of the marketplace'],
      ['state_admin', 'State Administrator', 'Manages orders for one assigned state'],
      ['customer', 'Customer', 'Shops on the storefront'],
    ];
    const insRole = await db.prepare('INSERT INTO roles (key, label, description) VALUES (?,?,?)');
    for (const r of roles) await insRole.run(...r);
    const insPerm = await db.prepare('INSERT OR IGNORE INTO permissions (key, role_key) VALUES (?,?)');
    const insRP = await db.prepare('INSERT OR IGNORE INTO role_permissions (role_key, permission_key) VALUES (?,?)');
    for (const [role, perms] of Object.entries(ROLE_PERMS)) for (const p of perms) {await  insPerm.run(p, role);await  insRP.run(role, p); }

    // categories
    const insCat = await db.prepare('INSERT INTO categories (name, slug, group_name, sort_order) VALUES (?,?,?,?)');
    const catIds: Record<string, number> = {};
    for (let i = 0; i < CATEGORIES.length; i++) {
      const [name, slug, group] = CATEGORIES[i];
      catIds[slug] = Number((await insCat.run(name, slug, group, i)).lastInsertRowid);
    }

    // products
    const insP = await db.prepare(
      `INSERT INTO products (name, slug, brand, model, category_id, description, short_description, specs, ram,
        storage_options, color_options, battery, screen_size, network, condition, warranty_months, warranty_policy,
        price, compare_price, stock, low_stock_at, sku, tracks_serial, rating_avg, rating_count, is_featured,
        is_flash_sale, flash_price, flash_ends_at)
       VALUES (@name,@slug,@brand,@model,@category_id,@description,@short_description,@specs,@ram,
        @storage_options,@color_options,@battery,@screen_size,@network,@condition,@warranty_months,@warranty_policy,
        @price,@compare_price,@stock,@low_stock_at,@sku,@tracks_serial,@rating_avg,@rating_count,@is_featured,
        @is_flash_sale,@flash_price,@flash_ends_at)`,
    );
    const insImg = await db.prepare('INSERT INTO product_images (product_id, url, alt, sort_order) VALUES (?,?,?,?)');
    const insVar = await db.prepare('INSERT INTO product_variants (product_id, color, storage, price, stock, sku) VALUES (?,?,?,?,?,?)');
    const seen = new Set<string>();
    for (const [i, prod] of PRODUCTS.entries()) {
      let slug = slugify(prod.name);
      while (seen.has(slug)) slug += '-x';
      seen.add(slug);
      const o = prod.opts;
      const kind = o.kind || 'phone';
      const tint = (i % 6) + 1;
      const specs = {
        Display: o.screen || '—',
        Battery: o.battery || '—',
        RAM: o.ram || '—',
        Network: o.network || '—',
        ...(o.specs || {}),
      };
      const info = await insP.run({
        name: prod.name,
        slug,
        brand: prod.brand,
        model: prod.model,
        category_id: catIds[prod.cat],
        description:
          o.short ||
          `${prod.name} available at OBAHTECH Gadgets with nationwide delivery. Genuine product, verified warranty and 7-day return window on eligible items.`,
        short_description: o.short || null,
        specs: JSON.stringify(specs),
        ram: o.ram || null,
        storage_options: JSON.stringify(o.storage || []),
        color_options: JSON.stringify(o.colors || ['Standard']),
        battery: o.battery || null,
        screen_size: o.screen || null,
        network: o.network || null,
        condition: o.condition || 'New',
        warranty_months: o.warranty ?? 12,
        warranty_policy: `${o.warranty ?? 12}-month OBAHTECH Gadgets warranty covering manufacturing defects only. Accidental damage, liquid damage and unauthorised repairs are excluded. Keep your invoice and IMEI/serial number.`,
        price: prod.price,
        compare_price: prod.compare,
        stock: prod.stock,
        low_stock_at: 5,
        sku: `OBH-${prod.brand.slice(0, 3).toUpperCase()}-${String(i + 1).padStart(4, '0')}`,
        tracks_serial: o.serial ? 1 : 0,
        rating_avg: o.rating ?? 4.2,
        rating_count: o.reviews ?? 20,
        is_featured: o.featured ? 1 : 0,
        is_flash_sale: o.flash ? 1 : 0,
        flash_price: o.flash ?? null,
        flash_ends_at: o.flash ? new Date(Date.now() + 5 * 864e5).toISOString() : null,
      });
      const pid = Number(info.lastInsertRowid);
      await insImg.run(pid, `/products/${kind}-${tint}.svg`, prod.name, 0);
      await insImg.run(pid, `/products/${kind}-${((tint) % 6) + 1}.svg`, `${prod.name} alternate view`, 1);
      for (const [si, s] of (o.storage || ['Standard']).entries()) {
        const bump = si > 0 ? Math.round(prod.price * 0.18) * si : 0;
        await insVar.run(pid, (o.colors || ['Standard'])[0], s, prod.price + bump, Math.max(1, Math.round(prod.stock / 2)), `OBH-${pid}-${si}`);
      }
    }

    // delivery fees: statewide standard + express, plus Lagos LGA overrides
    const insFee = await db.prepare('INSERT INTO delivery_fees (state_id, lga_id, method, fee, eta_days, min_order) VALUES (?,?,?,?,?,?)');
    const states = await db.prepare('SELECT id, name FROM states').all() as any[];
    const highValue = ['Lagos', 'Federal Capital Territory', 'Rivers', 'Ogun', 'Oyo', 'Kano', 'Anambra', 'Delta', 'Enugu', 'Abia', 'Edo', 'Kaduna'];
    for (const s of states) {
      const base = highValue.includes(s.name) ? 2500 : 4500;
      await insFee.run(s.id, null, 'standard', base, highValue.includes(s.name) ? 2 : 4, 0);
      await insFee.run(s.id, null, 'express', base + 2500, 1, 0);
      await insFee.run(s.id, null, 'standard', 4000, 3, 250000); // free-delivery threshold partner rate
    }
    const lagos = await stateByName(db, 'Lagos');
    if (lagos) {
      for (const lga of ['Ikeja', 'Lagos Island', 'Eti-Osa', 'Surulere', 'Yaba', 'Ikorodu', 'Alimosho']) {
        const l = await lgaByName(db, lagos.id, lga);
        if (l)await  insFee.run(lagos.id, l.id, 'standard', 2000, 1, 0);
      }
    }

    // promotions
    const insPromo = await db.prepare(
      `INSERT INTO promotions (code, description, type, value, min_order, max_uses, starts_at, ends_at, is_active)
       VALUES (?,?,?,?,?,?,datetime('now'),?,1)`,
    );
    await insPromo.run('OBAH10', '10% off orders above ₦150,000', 'percent', 10, 150000, 500, new Date(Date.now() + 60 * 864e5).toISOString());
    await insPromo.run('FREESHIP', 'Free delivery on orders above ₦300,000', 'free_delivery', 0, 300000, 300, new Date(Date.now() + 30 * 864e5).toISOString());
    await insPromo.run('GADGET5K', '₦5,000 off orders above ₦200,000', 'fixed', 5000, 200000, 1000, new Date(Date.now() + 90 * 864e5).toISOString());

    // banners
    const insBanner = await db.prepare(
      `INSERT INTO banners (title, subtitle, promo_text, cta_label, cta_link, image_url, bg_style, placement, starts_at, ends_at, is_active, sort_order)
       VALUES (?,?,?,?,?,?,?,?,datetime('now'),?,1,?)`,
    );
    await insBanner.run('Mega Phone Fest — up to 30% off', 'Genuine iPhones, Samsung, Tecno and Infinix — nationwide delivery in 1–4 days.', 'Up to 30% OFF', 'Shop smartphones', '/category/tecno-smartphones', '/brand/hero-art.svg', 'orange', 'home_hero', new Date(Date.now() + 45 * 864e5).toISOString(), 0);
    await insBanner.run('Flagship season is here', 'Galaxy S24 Ultra, iPhone 15 Pro Max and Pixel 8 Pro — with 12-month warranty.', 'New arrivals', 'See flagships', '/category/samsung-smartphones', '/brand/hero-art.svg', 'dark', 'home_hero', new Date(Date.now() + 45 * 864e5).toISOString(), 1);
    await insBanner.run('Accessories from ₦4,500', 'Chargers, cases, screen guards and power banks you can trust.', 'Free delivery over ₦300k', 'Shop accessories', '/category/power-banks', null, 'teal', 'home_hero', new Date(Date.now() + 45 * 864e5).toISOString(), 2);
    await insBanner.run('Flash Sale — ends soon', 'Limited stock at unbeatable prices. When it is gone, it is gone.', 'Up to 40% off', 'See flash deals', '/?flash=1', null, 'coral', 'promo_strip', new Date(Date.now() + 20 * 864e5).toISOString(), 0);
    await insBanner.run('Pay on delivery in Lagos', 'Order today, pay when it arrives. Available in selected Lagos LGAs.', 'Lagos only', 'Learn more', '/support', null, 'navy', 'category_banner', new Date(Date.now() + 30 * 864e5).toISOString(), 0);

    // reviews on a few popular products
    const reviewRows: [string, string, number, string, string][] = [
      ['Apple iPhone 15 Pro Max 256GB', 'Chinedu O.', 5, 'Genuine and sealed', 'Delivered in Ikeja within 24 hours. Sealed box, full warranty card inside. Very happy.'],
      ['Apple iPhone 15 Pro Max 256GB', 'Aisha B.', 4, 'Great phone, price is fair', 'Camera is outstanding. Delivery took 2 days to Surulere.'],
      ['Tecno Spark 20 Pro 256GB', 'Emeka N.', 5, 'Best budget phone', 'Battery lasts a full day of heavy use. Service at OBAHTECH was professional.'],
      ['Samsung Galaxy A55 5G 256GB', 'Tolu A.', 5, 'Smooth and premium', 'Feels like a flagship. The AMOLED is beautiful.'],
      ['Oraimo FreePods 4 ANC', 'Grace I.', 4, 'Good value', 'ANC works well for the price. Case is a bit bulky.'],
      ['Infinix Note 40 Pro 256GB', 'Musa K.', 5, 'Charging is mad', 'From 10% to 100% in under 45 minutes. Genuine product.'],
    ];
    const insRev = await db.prepare(
      'INSERT INTO reviews (product_id, user_id, author, rating, title, body, status) VALUES (?,NULL,?,?,?,?, \'published\')',
    );
    for (const [pname, author, rating, title, body] of reviewRows) {
      const p = await db.prepare('SELECT id FROM products WHERE name = ?').get(pname) as any;
      if (p)await  insRev.run(p.id, author, rating, title, body);
    }

    await seedDemoAccounts(db);
    await seedDemoOrders(db);
  });
  await run();
}

async function seedDemoAccounts(db: any) {
  if (process.env.SEED_DEMO === 'false') return;
  const pw = (p: string) => bcrypt.hashSync(p, 10);
  const insUser = await db.prepare(
    `INSERT INTO users (email, password_hash, full_name, phone, role, state_id, lga_id, admin_state_id, email_verified)
     VALUES (?,?,?,?,?,?,?,?,1)`,
  );
  const lagos = await stateByName(db, 'Lagos')!;
  const superId = Number(
    (await insUser.run('super@obahtech.ng', pw('SuperAdmin#2026'), 'Obahtech Super Admin', '08030000001', 'super_admin', lagos.id, null, null)).lastInsertRowid,
  );
  const stateAdmins: [string, string, string][] = [
    ['Lagos', 'lagos@obahtech.ng', 'Ifeoma Eze (Lagos)'],
    ['Rivers', 'rivers@obahtech.ng', 'Boma Jack (Rivers)'],
    ['Oyo', 'oyo@obahtech.ng', 'Segun Adeyemi (Oyo)'],
    ['Ogun', 'ogun@obahtech.ng', 'Funmi Ojo (Ogun)'],
    ['Kano', 'kano@obahtech.ng', 'Sadiq Bello (Kano)'],
    ['Federal Capital Territory', 'fct@obahtech.ng', 'Ngozi Uba (FCT)'],
    ['Anambra', 'anambra@obahtech.ng', 'Chidi Okonkwo (Anambra)'],
    ['Delta', 'delta@obahtech.ng', 'Efe Okoro (Delta)'],
  ];
  for (const [state, email, name] of stateAdmins) {
    const s = await stateByName(db, state)!;
    await insUser.run(email, pw('StateAdmin#2026'), name, '0803000' + Math.floor(1000 + Math.random() * 8999), 'state_admin', s.id, null, s.id);
  }
  const ikeja = await lgaByName(db, lagos.id, 'Ikeja')!;
  const demoId = Number(
    (await insUser.run('demo@obahtech.ng', pw('Customer#2026'), 'Ada Obi', '08065550101', 'customer', lagos.id, ikeja.id, null)).lastInsertRowid,
  );
  await db.prepare(
    "INSERT INTO addresses (user_id, label, full_name, phone, state_id, lga_id, street, instructions, is_default) VALUES (?,?,?,?,?,?,?,?,1)",
  ).run(demoId, 'Home', 'Ada Obi', '08065550101', lagos.id, ikeja.id, '12 Allen Avenue, Ikeja', 'Call on arrival at the gate');

  // a second Lagos customer + a Rivers customer so state isolation is demonstrable
  const riversState = (await stateByName(db, 'Rivers'))!;
  const ph = (await lgaByName(db, riversState.id, 'Port Harcourt'))!;
  await insUser.run('rivers.customer@obahtech.ng', pw('Customer#2026'), 'Tamuno Briggs', '08065550202', 'customer', riversState.id, ph.id, null);
  const oyoState = (await stateByName(db, 'Oyo'))!;
  const ibadan = (await lgaByName(db, oyoState.id, 'Ibadan North'))!;
  await insUser.run('oyo.customer@obahtech.ng', pw('Customer#2026'), 'Bisi Lawal', '08065550303', 'customer', oyoState.id, ibadan.id, null);
}

async function seedDemoOrders(db: any) {
  if (process.env.SEED_DEMO === 'false') return;
  const demo = await db.prepare("SELECT * FROM users WHERE email = 'demo@obahtech.ng'").get() as any;
  if (!demo) return;
  const pick = async (name: string) => await db.prepare('SELECT * FROM products WHERE name = ?').get(name) as any;
  const img = async (pid: number) => (await db.prepare('SELECT url FROM product_images WHERE product_id = ? ORDER BY sort_order LIMIT 1').get(pid) as any)?.url;

  const scenarios: any[] = [
    { state: 'Lagos', lga: 'Ikeja', status: 'delivered', daysAgo: 9, items: [['Apple iPhone 15 Pro Max 256GB', 1, 'Natural Titanium', '256GB']], paid: true },
    { state: 'Lagos', lga: 'Surulere', status: 'out_for_delivery', daysAgo: 2, items: [['Samsung Galaxy A55 5G 256GB', 1, 'Awesome Navy', '256GB'], ['Oraimo FreePods 4 ANC', 1, 'Black', null]], paid: true },
    { state: 'Lagos', lga: 'Eti-Osa', status: 'cancellation_requested', daysAgo: 1, items: [['Tecno Spark 20 Pro 256GB', 1, 'Cyber White', '256GB']], paid: true },
    { state: 'Rivers', lga: 'Port Harcourt', status: 'processing', daysAgo: 3, items: [['Infinix Note 40 Pro 256GB', 1, 'Obsidian Black', '256GB']], paid: true },
    { state: 'Oyo', lga: 'Ibadan North', status: 'pending_payment', daysAgo: 0, items: [['Xiaomi Redmi Note 13 Pro 256GB', 1, 'Ocean Teal', '256GB']], paid: false },
    { state: 'Federal Capital Territory', lga: 'Municipal Area Council', status: 'order_confirmed', daysAgo: 4, items: [['Apple iPad (10th Gen) 64GB Wi-Fi', 1, 'Blue', '64GB']], paid: true },
    { state: 'Kano', lga: 'Nasarawa', status: 'delivered', daysAgo: 14, items: [['Itel S24 128GB', 1, 'Meteor Black', '128GB']], paid: true },
    { state: 'Anambra', lga: 'Onitsha North', status: 'shipped', daysAgo: 2, items: [['JBL Flip 6 Portable Speaker', 2, 'Black', null]], paid: true },
  ];

  const custByState: Record<string, any> = {
    Lagos: demo,
    Rivers: await db.prepare("SELECT * FROM users WHERE email = 'rivers.customer@obahtech.ng'").get(),
    Oyo: await db.prepare("SELECT * FROM users WHERE email = 'oyo.customer@obahtech.ng'").get(),
  };

  for (const [idx, sc] of scenarios.entries()) {
    const st = await stateByName(db, sc.state)!;
    const lg = await lgaByName(db, st.id, sc.lga)!;
    const customer = custByState[sc.state] || demo;
    const created = new Date(Date.now() - sc.daysAgo * 864e5 - idx * 36e5);
    const createdSql = created.toISOString().slice(0, 19).replace('T', ' ');
    let subtotal = 0;
    const lines = await Promise.all(sc.items.map(async ([name, qty, color, storage]: any[]) => {
      const p = await pick(name);
      const unit = p.is_flash_sale && p.flash_price ? p.flash_price : p.price;
      subtotal += unit * qty;
      return { p, qty, unit, color, storage };
    }));
    const fee = sc.state === 'Lagos' ? 2000 : 2500;
    const total = subtotal + fee;
    const orderNo = `OBH-${created.getFullYear()}${String(created.getMonth() + 1).padStart(2, '0')}${String(created.getDate()).padStart(2, '0')}-D${String(idx + 1).padStart(3, '0')}`;
    const admin = await db
      .prepare("SELECT id FROM users WHERE role = 'state_admin' AND admin_state_id = ? LIMIT 1")
      .get(st.id) as any;

    const oid = Number(
      (await db
        .prepare(
          `INSERT INTO orders (order_number, user_id, customer_name, phone, email, status, payment_status, subtotal, discount,
             delivery_fee, total, state_id, lga_id, address_text, instructions, delivery_method, assigned_admin_id, tracking_ref, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,0,?,?,?,?,?,?,?,?,?,?,?)`,
        )
        .run(
          orderNo,
          customer.id,
          customer.full_name,
          customer.phone,
          customer.email,
          sc.status,
          sc.paid ? 'paid' : 'unpaid',
          subtotal,
          fee,
          total,
          st.id,
          lg.id,
          `${Math.floor(1 + Math.random() * 80)} ${sc.lga} Road, ${sc.lga}, ${sc.state}`,
          'Please call before delivery',
          'standard',
          admin?.id ?? null,
          `TRK-${orderNo.slice(4)}`,
          createdSql,
          createdSql,
        )).lastInsertRowid,
    );

    for (const l of lines) {
      await db.prepare(
        `INSERT INTO order_items (order_id, product_id, name, image, brand, model, color, storage, qty, unit_price, line_total)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      ).run(oid, l.p.id, l.p.name,await  img(l.p.id), l.p.brand, l.p.model, l.color, l.storage, l.qty, l.unit, l.unit * l.qty);
    }

    await db.prepare(
      "INSERT INTO deliveries (order_id, status, tracking_ref, courier, eta_date, shipped_at, delivered_at) VALUES (?,?,?,?,?,?,?)",
    ).run(
      oid,
      sc.status === 'delivered' ? 'delivered' : sc.status === 'shipped' || sc.status === 'out_for_delivery' ? 'shipped' : 'pending',
      `TRK-${orderNo.slice(4)}`,
      'OBAHTECH Logistics',
      new Date(created.getTime() + 3 * 864e5).toISOString().slice(0, 10),
      sc.status === 'delivered' || sc.status === 'shipped' || sc.status === 'out_for_delivery' ? created.toISOString().slice(0, 19).replace('T', ' ') : null,
      sc.status === 'delivered' ? new Date(created.getTime() + 2 * 864e5).toISOString().slice(0, 19).replace('T', ' ') : null,
    );

    if (sc.paid) {
      await db.prepare(
        `INSERT INTO payments (order_id, tx_ref, flw_ref, method, amount, currency, status, sandbox, created_at, verified_at)
         VALUES (?,?,?,?,?,'NGN','successful',1,?,?)`,
      ).run(oid, `OBH-TX-${orderNo}-DEMO`, `FLW-DEMO-${oid}`, 'card', total, createdSql, createdSql);
      await db.prepare("INSERT INTO transactions (payment_id, order_id, reference, type, amount, status) VALUES (NULL,?,?, 'charge', ?, 'successful')").run(
        oid,
        `OBH-TX-${orderNo}-DEMO`,
        total,
      );
    }

    const flow = ['pending_payment', 'payment_confirmed', 'order_confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered'];
    const reach = sc.status === 'cancellation_requested' ? 3 : flow.indexOf(sc.status);
    for (let i = 0; i <= Math.max(1, reach); i++) {
      const st2 = flow[i] ?? sc.status;
      await db.prepare('INSERT INTO order_events (order_id, status, note, actor_role, created_at) VALUES (?,?,?,?,?)').run(
        oid,
        i > reach ? sc.status : st2,
        i === 0 ? 'Order created — awaiting payment' : `Status updated to ${st2.replace(/_/g, ' ')}`,
        i === 0 ? 'customer' : 'system',
        new Date(created.getTime() + i * 36e5).toISOString().slice(0, 19).replace('T', ' '),
      );
    }
    if (sc.status === 'cancellation_requested') {
      await db.prepare("INSERT INTO order_events (order_id, status, note, actor_role, created_at) VALUES (?,?,'Customer requested cancellation','customer',datetime('now'))").run(oid, 'cancellation_requested');
    }

    // notification history for the assigned admin + super admin
    const recipients = admin
      ? await db.prepare("SELECT id, role FROM users WHERE role = 'super_admin' OR id = ?").all(admin.id)
      : await db.prepare("SELECT id, role FROM users WHERE role = 'super_admin'").all();
    for (const r of recipients as any[]) {
      await db.prepare(
        `INSERT INTO notifications (type, audience, title, body, order_id, state_id, recipient_role, recipient_user_id, is_read, created_at)
         VALUES ('new_order','admin',?,?,?,?,?,?,0,?)`,
      ).run(
        `New order ${orderNo} — ${customer.full_name} (${sc.state})`,
        `Order for delivery to ${sc.lga}, ${sc.state}. Total ₦${total.toLocaleString()}.`,
        oid,
        st.id,
        r.role,
        r.id,
        createdSql,
      );
    }

    // warranties for delivered orders
    if (sc.status === 'delivered') {
      const items = await db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(oid) as any[];
      for (const it of items) {
        const p = await pick(it.name);
        const delivery = new Date(created.getTime() + 2 * 864e5);
        const expiry = new Date(delivery);
        expiry.setMonth(expiry.getMonth() + (p?.warranty_months ?? 12));
        await db.prepare(
          `INSERT INTO warranties (order_id, order_item_id, user_id, product_id, product_name, model, serial_no, purchase_date,
             delivery_date, start_date, duration_months, expiry_date, conditions)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        ).run(
          oid,
          it.id,
          customer.id,
          it.product_id,
          it.name,
          it.model,
          `SN-${oid}${it.id}26`,
          createdSql,
          delivery.toISOString().slice(0, 10),
          delivery.toISOString().slice(0, 10),
          p?.warranty_months ?? 12,
          expiry.toISOString().slice(0, 10),
          `${p?.warranty_months ?? 12}-month OBAHTECH Gadgets warranty covering manufacturing defects only.`,
        );
      }
    }

    // one warranty claim + one return request + one ticket for a richer demo
    if (idx === 1) {
      const w = await db.prepare('SELECT * FROM warranties WHERE order_id = ?').get(oid) as any;
      if (w) {
        await db.prepare(
          "INSERT INTO warranty_claims (warranty_id, order_id, user_id, issue, status, created_at) VALUES (?,?,?,?,'under_review',datetime('now'))",
        ).run(w.id, oid, customer.id, 'Battery drains very fast after charging overnight. Requesting inspection.');
        await db.prepare("INSERT INTO notifications (type, audience, title, body, order_id, state_id, recipient_role, recipient_user_id) VALUES ('warranty_claim','admin',?,?,?,?,'super_admin',(SELECT id FROM users WHERE role='super_admin' LIMIT 1))").run(
          `Warranty claim on ${orderNo}`,
          'Customer submitted a warranty claim for a delivered item.',
          oid,
          st.id,
        );
      }
    }
    if (idx === 3) {
      await db.prepare(
        "INSERT INTO support_tickets (reference, user_id, order_id, name, email, phone, category, subject, message, status, state_id) VALUES (?,?,?,?,?,?,?,?,?,'open',?)",
      ).run(
        `TKT-${1000 + idx}`,
        customer.id,
        oid,
        customer.full_name,
        customer.email,
        customer.phone,
        'delivery',
        'Delivery rider has not called',
        'I have been waiting since morning, please confirm when the rider will arrive.',
        st.id,
      );
    }
    if (idx === 4) {
      await db.prepare(
        "INSERT INTO support_tickets (reference, user_id, order_id, name, email, phone, category, subject, message, status, state_id) VALUES (?,?,?,?,?,?,?,?,?,'open',?)",
      ).run(
        `TKT-${2000 + idx}`,
        (await db.prepare("SELECT id FROM users WHERE email = 'oyo.customer@obahtech.ng'").get() as any).id,
        oid,
        'Bisi Lawal',
        'oyo.customer@obahtech.ng',
        '08065550303',
        'order',
        'Payment not reflecting',
        'I paid but my order still shows pending payment.',
        st.id,
      );
    }
  }
}
