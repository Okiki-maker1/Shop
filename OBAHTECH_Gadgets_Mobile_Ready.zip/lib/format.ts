export const NGN = (n: number | null | undefined) =>
  '₦' + Math.round(Number(n || 0)).toLocaleString('en-NG');

export const NGNcompact = (n: number) =>
  n >= 1_000_000 ? `₦${(n / 1_000_000).toFixed(1)}m` : n >= 1000 ? `₦${Math.round(n / 1000)}k` : NGN(n);

export const disc = (price: number, compare?: number | null) =>
  compare && compare > price ? Math.round(((compare - price) / compare) * 100) : 0;

export function fmtDate(d?: string | null) {
  if (!d) return '—';
  const date = new Date(d.includes('T') ? d : d.replace(' ', 'T') + 'Z');
  if (isNaN(date.getTime())) return d;
  return date.toLocaleDateString('en-NG', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function fmtDateTime(d?: string | null) {
  if (!d) return '—';
  const date = new Date(d.includes('T') ? d : d.replace(' ', 'T') + 'Z');
  if (isNaN(date.getTime())) return d;
  return date.toLocaleString('en-NG', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function timeAgo(d?: string | null) {
  if (!d) return '';
  const date = new Date(d.includes('T') ? d : d.replace(' ', 'T') + 'Z').getTime();
  const s = Math.floor((Date.now() - date) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 604800) return `${Math.floor(s / 86400)}d ago`;
  return fmtDate(d);
}

export const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export const ORDER_STATUSES = [
  'pending_payment',
  'payment_confirmed',
  'order_confirmed',
  'processing',
  'packed',
  'shipped',
  'out_for_delivery',
  'delivered',
  'cancellation_requested',
  'cancelled',
  'return_requested',
  'returned',
  'refund_pending',
  'refunded',
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const STATUS_LABEL: Record<string, string> = {
  pending_payment: 'Pending payment',
  payment_confirmed: 'Payment confirmed',
  order_confirmed: 'Order confirmed',
  processing: 'Processing',
  packed: 'Packed',
  shipped: 'Shipped',
  out_for_delivery: 'Out for delivery',
  delivered: 'Delivered',
  cancellation_requested: 'Cancellation requested',
  cancelled: 'Cancelled',
  return_requested: 'Return requested',
  returned: 'Returned',
  refund_pending: 'Refund pending',
  refunded: 'Refunded',
};

export const STATUS_STYLE: Record<string, string> = {
  pending_payment: 'bg-amber-50 text-amber-700 ring-amber-200',
  payment_confirmed: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  order_confirmed: 'bg-sky-50 text-sky-700 ring-sky-200',
  processing: 'bg-indigo-50 text-indigo-700 ring-indigo-200',
  packed: 'bg-violet-50 text-violet-700 ring-violet-200',
  shipped: 'bg-blue-50 text-blue-700 ring-blue-200',
  out_for_delivery: 'bg-cyan-50 text-cyan-700 ring-cyan-200',
  delivered: 'bg-green-50 text-green-700 ring-green-200',
  cancellation_requested: 'bg-orange-50 text-orange-700 ring-orange-200',
  cancelled: 'bg-rose-50 text-rose-700 ring-rose-200',
  return_requested: 'bg-orange-50 text-orange-700 ring-orange-200',
  returned: 'bg-slate-100 text-slate-700 ring-slate-200',
  refund_pending: 'bg-amber-50 text-amber-700 ring-amber-200',
  refunded: 'bg-teal-50 text-teal-700 ring-teal-200',
};

/** Forward-only delivery pipeline used by admin action buttons. */
export const NEXT_STATUS: Record<string, string[]> = {
  pending_payment: ['order_confirmed', 'cancelled'],
  payment_confirmed: ['order_confirmed', 'cancelled'],
  order_confirmed: ['processing', 'cancelled'],
  processing: ['packed', 'cancelled'],
  packed: ['shipped', 'cancelled'],
  shipped: ['out_for_delivery'],
  out_for_delivery: ['delivered'],
  cancellation_requested: ['cancelled', 'processing'],
  return_requested: ['returned', 'delivered'],
  delivered: ['return_requested'],
};

export const TRACKING_STAGES = [
  'order_confirmed',
  'processing',
  'packed',
  'shipped',
  'out_for_delivery',
  'delivered',
];

export function orderNumber() {
  const d = new Date();
  const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `OBH-${stamp}-${rand}`;
}

export function txRef(orderNo: string) {
  return `OBH-TX-${orderNo}-${Date.now().toString(36).toUpperCase()}`;
}

export const REASONS_RETURN = [
  'Damaged product',
  'Wrong product delivered',
  'Missing product',
  'Defective phone',
  'Product not matching description',
  'Other approved reason',
];
