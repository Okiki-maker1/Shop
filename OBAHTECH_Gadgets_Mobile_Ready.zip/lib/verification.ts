import crypto from 'node:crypto';
import { getDb } from './db';

/**
 * Email-verification tokens. Only a SHA-256 hash is stored, so a database leak
 * cannot be replayed against the /verify endpoint. Links expire in 48 hours and
 * are single-use.
 */
export async function createVerificationToken(userId: number) {
  const db = getDb();
  const token = crypto.randomBytes(24).toString('hex');
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  await db.prepare("DELETE FROM email_verifications WHERE user_id = ? AND used_at IS NULL").run(userId);
  await db.prepare("INSERT INTO email_verifications (user_id, token_hash, expires_at) VALUES (?,?,datetime('now','+48 hours'))").run(
    userId,
    hash,
  );
  return token;
}

export async function consumeVerificationToken(token: string): Promise<'verified' | 'already' | 'invalid'> {
  const db = getDb();
  if (!token) return 'invalid';
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  const row = await db.prepare('SELECT * FROM email_verifications WHERE token_hash = ?').get(hash) as any;
  if (!row) return 'invalid';
  if (row.used_at) return 'already';
  if (new Date(row.expires_at.replace(' ', 'T') + 'Z').getTime() < Date.now()) return 'invalid';
  await db.prepare("UPDATE email_verifications SET used_at = datetime('now') WHERE id = ?").run(row.id);
  await db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(row.user_id);
  return 'verified';
}
