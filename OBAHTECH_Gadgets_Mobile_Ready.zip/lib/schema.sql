-- OBAHTECH Gadgets — relational schema (SQLite runtime adapter).
-- The production Supabase Postgres schema with RLS policies lives in supabase/schema.sql
-- and mirrors these tables 1:1 (same names, same relationships).

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ─── Location reference data ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS states (
  id      INTEGER PRIMARY KEY,
  name    TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS lgas (
  id       INTEGER PRIMARY KEY,
  state_id INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
  name     TEXT NOT NULL,
  UNIQUE (state_id, name)
);

-- ─── Identity, roles, permissions ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS roles (
  id          INTEGER PRIMARY KEY,
  key         TEXT NOT NULL UNIQUE,      -- super_admin | state_admin | customer
  label       TEXT NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS permissions (
  id   INTEGER PRIMARY KEY,
  key  TEXT NOT NULL UNIQUE,             -- orders.view_all, orders.view_state, banners.manage ...
  role_key TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_key       TEXT NOT NULL REFERENCES roles(key) ON DELETE CASCADE,
  permission_key TEXT NOT NULL REFERENCES permissions(key) ON DELETE CASCADE,
  PRIMARY KEY (role_key, permission_key)
);

CREATE TABLE IF NOT EXISTS users (
  id             INTEGER PRIMARY KEY,
  email          TEXT NOT NULL UNIQUE,
  password_hash  TEXT NOT NULL,
  full_name      TEXT NOT NULL,
  phone          TEXT,
  role           TEXT NOT NULL DEFAULT 'customer' REFERENCES roles(key),
  state_id       INTEGER REFERENCES states(id),
  lga_id         INTEGER REFERENCES lgas(id),
  admin_state_id INTEGER REFERENCES states(id),  -- state an administrator is assigned to
  is_active      INTEGER NOT NULL DEFAULT 1,
  is_suspended   INTEGER NOT NULL DEFAULT 0,
  email_verified INTEGER NOT NULL DEFAULT 0,
  avatar_url     TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_admin_state ON users(admin_state_id);

CREATE TABLE IF NOT EXISTS sessions (
  id         TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS password_resets (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at    TEXT
);

CREATE TABLE IF NOT EXISTS addresses (
  id            INTEGER PRIMARY KEY,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label         TEXT NOT NULL DEFAULT 'Home',
  full_name     TEXT NOT NULL,
  phone         TEXT NOT NULL,
  state_id      INTEGER NOT NULL REFERENCES states(id),
  lga_id        INTEGER NOT NULL REFERENCES lgas(id),
  street        TEXT NOT NULL,
  instructions  TEXT,
  is_default    INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_addresses_user ON addresses(user_id);

-- ─── Catalogue ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
  id            INTEGER PRIMARY KEY,
  name          TEXT NOT NULL UNIQUE,
  slug          TEXT NOT NULL UNIQUE,
  icon          TEXT,
  group_name    TEXT,
  sort_order    INTEGER NOT NULL DEFAULT 0,
  is_active     INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS products (
  id                INTEGER PRIMARY KEY,
  name              TEXT NOT NULL,
  slug              TEXT NOT NULL UNIQUE,
  brand             TEXT NOT NULL,
  model             TEXT,
  category_id       INTEGER NOT NULL REFERENCES categories(id),
  description       TEXT,
  short_description TEXT,
  specs             TEXT,                -- JSON object of specification rows
  ram               TEXT,
  storage_options   TEXT,                -- JSON array
  color_options     TEXT,                -- JSON array
  battery           TEXT,
  screen_size       TEXT,
  network           TEXT,
  condition         TEXT DEFAULT 'New',
  warranty_months   INTEGER NOT NULL DEFAULT 12,
  warranty_policy   TEXT,
  price             INTEGER NOT NULL,    -- kobo-free naira integer
  compare_price     INTEGER,
  stock             INTEGER NOT NULL DEFAULT 0,
  reserved          INTEGER NOT NULL DEFAULT 0,
  sold              INTEGER NOT NULL DEFAULT 0,
  returned_stock    INTEGER NOT NULL DEFAULT 0,
  damaged_stock     INTEGER NOT NULL DEFAULT 0,
  low_stock_at      INTEGER NOT NULL DEFAULT 5,
  sku               TEXT UNIQUE,
  tracks_serial     INTEGER NOT NULL DEFAULT 0,
  rating_avg        REAL NOT NULL DEFAULT 0,
  rating_count      INTEGER NOT NULL DEFAULT 0,
  is_featured       INTEGER NOT NULL DEFAULT 0,
  is_flash_sale     INTEGER NOT NULL DEFAULT 0,
  flash_price       INTEGER,
  flash_ends_at     TEXT,
  is_active         INTEGER NOT NULL DEFAULT 1,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_products_cat ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured);

CREATE TABLE IF NOT EXISTS product_images (
  id         INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url        TEXT NOT NULL,
  alt        TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_images_product ON product_images(product_id);

CREATE TABLE IF NOT EXISTS product_variants (
  id         INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  color      TEXT NOT NULL,
  storage    TEXT,
  price      INTEGER NOT NULL,
  stock      INTEGER NOT NULL DEFAULT 0,
  sku        TEXT
);

CREATE TABLE IF NOT EXISTS stock_logs (
  id         INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  change     INTEGER NOT NULL,
  reason     TEXT NOT NULL,
  admin_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  order_id   INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reviews (
  id         INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  order_id   INTEGER,
  author     TEXT NOT NULL,
  rating     INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title      TEXT,
  body       TEXT,
  status     TEXT NOT NULL DEFAULT 'published',  -- published | hidden
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);

-- ─── Cart & wishlist ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS carts (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cart_items (
  id         INTEGER PRIMARY KEY,
  cart_id    INTEGER NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  color      TEXT,
  storage    TEXT,
  qty        INTEGER NOT NULL DEFAULT 1 CHECK (qty > 0),
  UNIQUE (cart_id, product_id, color, storage)
);

CREATE TABLE IF NOT EXISTS wishlists (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, product_id)
);

-- ─── Delivery pricing ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS delivery_fees (
  id         INTEGER PRIMARY KEY,
  state_id   INTEGER NOT NULL REFERENCES states(id),
  lga_id     INTEGER REFERENCES lgas(id),
  method     TEXT NOT NULL DEFAULT 'standard',   -- standard | express | pickup
  fee        INTEGER NOT NULL,
  eta_days   INTEGER NOT NULL DEFAULT 3,
  min_order  INTEGER DEFAULT 0,
  is_active  INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_fees_state ON delivery_fees(state_id);

-- ─── Orders ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
  id                INTEGER PRIMARY KEY,
  order_number      TEXT NOT NULL UNIQUE,
  user_id           INTEGER REFERENCES users(id) ON DELETE SET NULL,
  customer_name     TEXT NOT NULL,
  phone             TEXT NOT NULL,
  email             TEXT NOT NULL,
  status            TEXT NOT NULL DEFAULT 'pending_payment',
  payment_status    TEXT NOT NULL DEFAULT 'unpaid',   -- unpaid | paid | failed | refunded | partial_refund
  subtotal          INTEGER NOT NULL,
  discount          INTEGER NOT NULL DEFAULT 0,
  promo_code        TEXT,
  delivery_fee      INTEGER NOT NULL DEFAULT 0,
  total             INTEGER NOT NULL,
  state_id          INTEGER NOT NULL REFERENCES states(id),
  lga_id            INTEGER NOT NULL REFERENCES lgas(id),
  address_text      TEXT NOT NULL,
  instructions      TEXT,
  delivery_method   TEXT NOT NULL DEFAULT 'standard',
  assigned_admin_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  tracking_ref      TEXT,
  cancelled_reason  TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_state ON orders(state_id);
CREATE INDEX IF NOT EXISTS idx_orders_admin ON orders(assigned_admin_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);

CREATE TABLE IF NOT EXISTS order_items (
  id          INTEGER PRIMARY KEY,
  order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id  INTEGER REFERENCES products(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  image       TEXT,
  brand       TEXT,
  model       TEXT,
  color       TEXT,
  storage     TEXT,
  qty         INTEGER NOT NULL,
  unit_price  INTEGER NOT NULL,
  line_total  INTEGER NOT NULL,
  serial_no   TEXT
);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS order_assignments (
  id         INTEGER PRIMARY KEY,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  admin_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  admin_name TEXT,
  state_id   INTEGER REFERENCES states(id),
  assigned_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reason     TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_events (
  id         INTEGER PRIMARY KEY,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status     TEXT NOT NULL,
  note       TEXT,
  actor_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_role TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_order ON order_events(order_id);

CREATE TABLE IF NOT EXISTS deliveries (
  id                   INTEGER PRIMARY KEY,
  order_id             INTEGER NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
  status               TEXT NOT NULL DEFAULT 'pending',
  tracking_ref         TEXT,
  courier              TEXT,
  eta_date             TEXT,
  shipped_at           TEXT,
  out_for_delivery_at  TEXT,
  delivered_at         TEXT,
  received_by          TEXT,
  updated_at           TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ─── Payments ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payments (
  id            INTEGER PRIMARY KEY,
  order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  tx_ref        TEXT NOT NULL UNIQUE,
  flw_ref       TEXT,
  gateway       TEXT NOT NULL DEFAULT 'flutterwave',
  method        TEXT,
  amount        INTEGER NOT NULL,
  currency      TEXT NOT NULL DEFAULT 'NGN',
  status        TEXT NOT NULL DEFAULT 'pending',   -- pending | successful | failed | abandoned
  sandbox       INTEGER NOT NULL DEFAULT 0,
  raw_response  TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  verified_at   TEXT
);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);

CREATE TABLE IF NOT EXISTS transactions (
  id         INTEGER PRIMARY KEY,
  payment_id INTEGER REFERENCES payments(id) ON DELETE CASCADE,
  order_id   INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  reference  TEXT,
  type       TEXT NOT NULL,        -- charge | refund | reversal
  amount     INTEGER NOT NULL,
  status     TEXT NOT NULL,
  meta       TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS refunds (
  id          INTEGER PRIMARY KEY,
  order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  return_id   INTEGER,
  amount      INTEGER NOT NULL,
  reason      TEXT,
  status      TEXT NOT NULL DEFAULT 'pending',  -- pending | approved | processing | completed | rejected
  processed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  gateway_ref TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at TEXT
);

-- ─── Marketing ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS banners (
  id           INTEGER PRIMARY KEY,
  title        TEXT NOT NULL,
  subtitle     TEXT,
  promo_text   TEXT,
  cta_label    TEXT,
  cta_link     TEXT,
  image_url    TEXT,
  bg_style     TEXT,                -- gradient key used by the renderer
  placement    TEXT NOT NULL DEFAULT 'home_hero',
  starts_at    TEXT,
  ends_at      TEXT,
  is_active    INTEGER NOT NULL DEFAULT 1,
  sort_order   INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS promotions (
  id           INTEGER PRIMARY KEY,
  code         TEXT NOT NULL UNIQUE,
  description  TEXT,
  type         TEXT NOT NULL DEFAULT 'percent',   -- percent | fixed | free_delivery
  value        INTEGER NOT NULL,
  min_order    INTEGER NOT NULL DEFAULT 0,
  max_uses     INTEGER,
  used_count   INTEGER NOT NULL DEFAULT 0,
  starts_at    TEXT,
  ends_at      TEXT,
  is_active    INTEGER NOT NULL DEFAULT 1,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ─── Notifications ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id                INTEGER PRIMARY KEY,
  type              TEXT NOT NULL,          -- new_order | payment_success | ...
  audience          TEXT NOT NULL,          -- admin | customer
  title             TEXT NOT NULL,
  body              TEXT,
  order_id          INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  state_id          INTEGER REFERENCES states(id),
  recipient_role    TEXT,                   -- super_admin | state_admin | customer | all_customers
  recipient_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  is_read           INTEGER NOT NULL DEFAULT 0,
  read_at           TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(recipient_user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_notif_order ON notifications(order_id);

CREATE TABLE IF NOT EXISTS notification_recipients (
  id              INTEGER PRIMARY KEY,
  notification_id INTEGER NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel         TEXT NOT NULL DEFAULT 'in_app',
  delivered_at    TEXT,
  read_at         TEXT,
  UNIQUE (notification_id, user_id, channel)
);

CREATE TABLE IF NOT EXISTS announcements (
  id            INTEGER PRIMARY KEY,
  title         TEXT NOT NULL,
  body          TEXT NOT NULL,
  audience      TEXT NOT NULL DEFAULT 'all',   -- all | state | product_buyers | selected
  state_id      INTEGER REFERENCES states(id),
  product_id    INTEGER REFERENCES products(id) ON DELETE SET NULL,
  channels      TEXT NOT NULL DEFAULT 'in_app',
  scheduled_at  TEXT,
  sent_at       TEXT,
  recipients    INTEGER NOT NULL DEFAULT 0,
  created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ─── Warranty / returns / support ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS warranties (
  id             INTEGER PRIMARY KEY,
  order_id       INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  order_item_id  INTEGER REFERENCES order_items(id) ON DELETE CASCADE,
  user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id     INTEGER REFERENCES products(id) ON DELETE SET NULL,
  product_name   TEXT NOT NULL,
  model          TEXT,
  serial_no      TEXT,
  purchase_date  TEXT NOT NULL,
  delivery_date  TEXT,
  start_date     TEXT NOT NULL,
  duration_months INTEGER NOT NULL,
  expiry_date    TEXT NOT NULL,
  conditions     TEXT,
  status         TEXT NOT NULL DEFAULT 'active'   -- active | expired | claimed | void
);
CREATE INDEX IF NOT EXISTS idx_warranties_user ON warranties(user_id);
CREATE INDEX IF NOT EXISTS idx_warranties_order ON warranties(order_id);

CREATE TABLE IF NOT EXISTS warranty_claims (
  id           INTEGER PRIMARY KEY,
  warranty_id  INTEGER NOT NULL REFERENCES warranties(id) ON DELETE CASCADE,
  order_id     INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  issue        TEXT NOT NULL,
  evidence_url TEXT,
  status       TEXT NOT NULL DEFAULT 'submitted', -- submitted | under_review | info_needed | approved | rejected | repaired | replaced | closed
  admin_note   TEXT,
  resolution   TEXT,
  handled_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS return_requests (
  id            INTEGER PRIMARY KEY,
  order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  order_item_id INTEGER REFERENCES order_items(id) ON DELETE SET NULL,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason        TEXT NOT NULL,
  explanation   TEXT,
  photos        TEXT,
  status        TEXT NOT NULL DEFAULT 'requested', -- requested | approved | rejected | item_received | refunded
  admin_note    TEXT,
  refund_amount INTEGER,
  handled_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id         INTEGER PRIMARY KEY,
  reference  TEXT NOT NULL UNIQUE,
  user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  order_id   INTEGER REFERENCES orders(id) ON DELETE SET NULL,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL,
  phone      TEXT,
  category   TEXT NOT NULL,   -- order | delivery | warranty | return | product | other
  subject    TEXT NOT NULL,
  message    TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'open',   -- open | in_progress | resolved | closed
  priority   TEXT NOT NULL DEFAULT 'normal',
  state_id   INTEGER REFERENCES states(id),
  assigned_admin_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ticket_messages (
  id         INTEGER PRIMARY KEY,
  ticket_id  INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  author_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  author_role TEXT NOT NULL,
  body       TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ─── Audit ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admin_logs (
  id         INTEGER PRIMARY KEY,
  admin_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  admin_name TEXT,
  action     TEXT NOT NULL,
  entity     TEXT,
  entity_id  TEXT,
  meta       TEXT,
  ip         TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_logs_admin ON admin_logs(admin_id);

CREATE TABLE IF NOT EXISTS email_verifications (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at    TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sms_outbox (
  id         INTEGER PRIMARY KEY,
  to_phone   TEXT NOT NULL,
  message    TEXT NOT NULL,
  provider   TEXT,
  status     TEXT NOT NULL DEFAULT 'queued',  -- queued | sent | failed | logged
  error      TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS email_outbox (
  id         INTEGER PRIMARY KEY,
  to_email   TEXT NOT NULL,
  subject    TEXT NOT NULL,
  body       TEXT NOT NULL,
  provider   TEXT,
  status     TEXT NOT NULL DEFAULT 'queued',  -- queued | sent | failed | logged
  error      TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
