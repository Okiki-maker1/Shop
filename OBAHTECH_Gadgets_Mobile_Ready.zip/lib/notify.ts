import { getDb, tx } from './db';
import type { SessionUser } from './auth';

/**
 * ── STRICT STATE-BASED NOTIFICATION ROUTING ─────────────────────────────────
 * Every order-related administrative notification goes to exactly:
 *   1. all super admins (nationwide)
 *   2. the administrator currently assigned to the order (must belong to the
 *      order's SAVED delivery state — never another state's admin)
 * If no state admin is assigned the order stays in the unassigned queue and
 * only the super admin is notified. Private order alerts are never broadcast.
 */
export async function adminRecipientsForOrder(orderId: number): Promise<{ id: number; email: string; full_name: string; role: string }[]> {
  const db = getDb();
  const order = await db.prepare('SELECT id, state_id, assigned_admin_id FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) return [];
  const supers = await db
    .prepare("SELECT id, email, full_name, role FROM users WHERE role = 'super_admin' AND is_active = 1 AND is_suspended = 0")
    .all() as any[];
  let assigned: any = null;
  if (order.assigned_admin_id) {
    assigned = await db
      .prepare(
        `SELECT id, email, full_name, role, admin_state_id FROM users
          WHERE id = ? AND role = 'state_admin' AND is_active = 1 AND is_suspended = 0`,
      )
      .get(order.assigned_admin_id) as any;
    // Guard: an admin from another state must never receive this order's alerts.
    if (assigned && assigned.admin_state_id !== order.state_id) assigned = null;
  }
  if (!assigned) {
    // fall back to the active administrator of the order's delivery state
    assigned = await db
      .prepare(
        `SELECT id, email, full_name, role, admin_state_id FROM users
          WHERE role = 'state_admin' AND admin_state_id = ? AND is_active = 1 AND is_suspended = 0
          ORDER BY id LIMIT 1`,
      )
      .get(order.state_id) as any;
  }
  const list = [...supers];
  if (assigned && !list.some((s) => s.id === assigned.id)) list.push(assigned);
  return list;
}

export type OrderNotifType =
  | 'new_order'
  | 'payment_success'
  | 'payment_failed'
  | 'order_confirmed'
  | 'order_processing'
  | 'order_shipped'
  | 'order_out_for_delivery'
  | 'order_delivered'
  | 'cancellation_requested'
  | 'order_cancelled'
  | 'return_requested'
  | 'refund_requested'
  | 'refund_completed'
  | 'warranty_claim'
  | 'delivery_complaint'
  | 'order_modification'
  | 'support_ticket'
  | 'low_stock';

export async function notifyOrder(opts: {
  orderId: number;
  type: OrderNotifType;
  title: string;
  body?: string;
  actor?: SessionUser | null;
  email?: boolean;
}) {
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(opts.orderId) as any;
  if (!order) return [];
  const recipients = await adminRecipientsForOrder(opts.orderId);
  const created: number[] = [];
  await tx(async (d) => {
    const txIns = d.prepare(
      `INSERT INTO notifications (type, audience, title, body, order_id, state_id, recipient_role, recipient_user_id)
       VALUES (?, 'admin', ?, ?, ?, ?, ?, ?)`,
    );
    const txInsR = d.prepare(
      "INSERT OR IGNORE INTO notification_recipients (notification_id, user_id, channel, delivered_at) VALUES (?,?,?,datetime('now'))",
    );
    for (const r of recipients) {
      const res = await txIns.run(opts.type, opts.title, opts.body ?? null, order.id, order.state_id, r.role, r.id);
      const nid = Number(res.lastInsertRowid);
      await txInsR.run(nid, r.id, 'in_app');
      created.push(nid);
      if (opts.email !== false) {
        await queueEmail(r.email, `[OBAHTECH] ${opts.title}`, `${opts.title}\n\n${opts.body ?? ''}\n\nOrder: ${order.order_number}\nState: ${await stateName(order.state_id)}\n\nOpen your dashboard to review.`);
      }
    }
  });
  return created;
}

export async function notifyCustomer(opts: {
  userId: number;
  type: string;
  title: string;
  body?: string;
  orderId?: number | null;
  email?: boolean;
  stateId?: number | null;
}) {
  const db = getDb();
  const res = await db
    .prepare(
      `INSERT INTO notifications (type, audience, title, body, order_id, state_id, recipient_role, recipient_user_id)
       VALUES (?, 'customer', ?, ?, ?, ?, 'customer', ?)`,
    )
    .run(opts.type, opts.title, opts.body ?? null, opts.orderId ?? null, opts.stateId ?? null, opts.userId);
  const id = Number(res.lastInsertRowid);
  await db.prepare("INSERT OR IGNORE INTO notification_recipients (notification_id, user_id, channel, delivered_at) VALUES (?,?,'in_app',datetime('now'))").run(id, opts.userId);
  if (opts.email !== false) {
    const u = await db.prepare('SELECT email, phone FROM users WHERE id = ?').get(opts.userId) as any;
    if (u?.email) await queueEmail(u.email, `OBAHTECH Gadgets — ${opts.title}`, `${opts.title}\n\n${opts.body ?? ''}`);
    if (u?.phone) await queueSms(u.phone, `OBAHTECH: ${opts.title}`);
  }
  return id;
}

export async function queueEmail(to: string, subject: string, body: string) {
  const db = getDb();
  const provider = process.env.EMAIL_PROVIDER || '';
  const key = process.env.EMAIL_API_KEY || '';
  const res = await db
    .prepare('INSERT INTO email_outbox (to_email, subject, body, provider, status) VALUES (?,?,?,?,?)')
    .run(to, subject, body, provider || 'console', key ? 'queued' : 'logged');
  const id = Number(res.lastInsertRowid);
  if (key && provider === 'resend') {
    fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.EMAIL_FROM, to, subject, text: body }),
    })
      .then(async (r) => await db.prepare('UPDATE email_outbox SET status = ? WHERE id = ?').run(r.ok ? 'sent' : 'failed', id))
      .catch(async () => await db.prepare("UPDATE email_outbox SET status = 'failed' WHERE id = ?").run(id));
  }
  return id;
}

/**
 * Queues an SMS. When SMS_API_KEY is configured the message is pushed to the
 * Termii-compatible gateway immediately; otherwise it is logged to sms_outbox
 * with status 'logged' so nothing silently disappears.
 */
export async function queueSms(to: string, message: string) {
  if (!to) return 0;
  const db = getDb();
  const key = process.env.SMS_API_KEY || '';
  const sender = process.env.SMS_SENDER || 'OBAHTECH';
  const res = await db
    .prepare('INSERT INTO sms_outbox (to_phone, message, provider, status) VALUES (?,?,?,?)')
    .run(to, message, key ? 'termii' : 'console', key ? 'queued' : 'logged');
  const id = Number(res.lastInsertRowid);
  if (key) {
    const base = process.env.SMS_API_URL || 'https://api.ng.termii.com/api/sms/send';
    fetch(base, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: key, to, from: sender, sms: message, type: 'plain', channel: 'generic' }),
    })
      .then(async (r) => {
        const ok = r.ok;
        await db.prepare('UPDATE sms_outbox SET status = ?, error = ? WHERE id = ?').run(
          ok ? 'sent' : 'failed',
          ok ? null : (await r.text()).slice(0, 300),
          id,
        );
      })
      .catch(async (e) => await db.prepare('UPDATE sms_outbox SET status = ?, error = ? WHERE id = ?').run('failed', String(e).slice(0, 300), id));
  }
  return id;
}

export async function logAdmin(user: SessionUser | null, action: string, entity?: string, entityId?: string | number, meta?: any) {
  const db = getDb();
  await db.prepare('INSERT INTO admin_logs (admin_id, admin_name, action, entity, entity_id, meta) VALUES (?,?,?,?,?,?)').run(
    user?.id ?? null,
    user?.full_name ?? 'system',
    action,
    entity ?? null,
    entityId != null ? String(entityId) : null,
    meta ? JSON.stringify(meta) : null,
  );
}

export async function stateName(stateId: number) {
  const db = getDb();
  return (await db.prepare('SELECT name FROM states WHERE id = ?').get(stateId) as any)?.name ?? 'Unknown';
}

/** Customer announcements (marketing/operational) — fan-out to in-app rows. */
export async function sendAnnouncement(opts: {
  title: string;
  body: string;
  audience: 'all' | 'state' | 'product_buyers' | 'selected';
  stateId?: number | null;
  productId?: number | null;
  userIds?: number[];
  channels?: string;
  scheduledAt?: string | null;
  createdBy?: number | null;
  sendNow?: boolean;
}) {
  const db = getDb();
  const res = await db
    .prepare(
      `INSERT INTO announcements (title, body, audience, state_id, product_id, channels, scheduled_at, sent_at, created_by)
       VALUES (?,?,?,?,?,?,?,?,?)`,
    )
    .run(
      opts.title,
      opts.body,
      opts.audience,
      opts.stateId ?? null,
      opts.productId ?? null,
      opts.channels ?? 'in_app',
      opts.scheduledAt ?? null,
      null, // sent_at is stamped by deliverAnnouncement after the fan-out
      opts.createdBy ?? null,
    );
  const announcementId = Number(res.lastInsertRowid);
  if (opts.sendNow !== false) await deliverAnnouncement(announcementId);
  return announcementId;
}

export async function announcementRecipients(a: any): Promise<{ id: number; email: string }[]> {
  const db = getDb();
  if (a.audience === 'all') return await db.prepare("SELECT id, email FROM users WHERE role = 'customer'").all() as any;
  if (a.audience === 'state')
    return await db.prepare("SELECT id, email FROM users WHERE role = 'customer' AND state_id = ?").all(a.state_id) as any;
  if (a.audience === 'product_buyers')
    return await db
      .prepare(
        `SELECT DISTINCT u.id, u.email FROM users u
           JOIN orders o ON o.user_id = u.id
           JOIN order_items oi ON oi.order_id = o.id
          WHERE oi.product_id = ?`,
      )
      .all(a.product_id) as any;
  return await db.prepare("SELECT id, email FROM users WHERE role = 'customer'").all() as any;
}

export async function deliverAnnouncement(announcementId: number) {
  const db = getDb();
  const a = await db.prepare('SELECT * FROM announcements WHERE id = ?').get(announcementId) as any;
  if (!a || a.sent_at) return 0;
  const recipients = await announcementRecipients(a);
  await tx(async (d) => {
    const ins = d.prepare(
      `INSERT INTO notifications (type, audience, title, body, state_id, recipient_role, recipient_user_id)
       VALUES ('announcement', 'customer', ?, ?, ?, 'customer', ?)`,
    );
    for (const r of recipients) await ins.run(a.title, a.body, a.state_id ?? null, r.id);
    await d.prepare("UPDATE announcements SET sent_at = datetime('now'), recipients = ? WHERE id = ?").run(recipients.length, announcementId);
  });
  const channels = a.channels || 'in_app';
  if (channels.includes('email')) {
    for (const r of recipients) await queueEmail(r.email, `OBAHTECH Gadgets — ${a.title}`, `${a.title}\n\n${a.body}`);
  }
  if (channels.includes('sms')) {
    const phones = await db
      .prepare("SELECT phone FROM users WHERE id IN (" + recipients.map(() => '?').join(',') + ") AND phone IS NOT NULL AND phone <> ''")
      .all(...recipients.map((r: any) => r.id)) as any[];
    for (const p of phones) await queueSms(p.phone, `OBAHTECH: ${a.title}. ${String(a.body).slice(0, 110)}`);
  }
  return recipients.length;
}
