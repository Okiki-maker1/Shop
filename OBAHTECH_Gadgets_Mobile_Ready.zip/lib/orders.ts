import { getDb, tx } from './db';
import { notifyOrder, notifyCustomer, logAdmin, stateName } from './notify';
import { NEXT_STATUS, STATUS_LABEL, orderNumber as genOrderNumber } from './format';
import type { SessionUser } from './auth';

/** Delivery pricing: LGA override → state rule → national fallback. */
export async function deliveryFeeFor(stateId: number, lgaId: number | null, method = 'standard', subtotal = 0) {
  const db = getDb();
  if (method === 'pickup') return { fee: 0, eta: 1 };
  const lgaRule = lgaId
    ? (await db
        .prepare(
          `SELECT fee, eta_days FROM delivery_fees
            WHERE state_id = ? AND lga_id = ? AND method = ? AND is_active = 1 AND min_order <= ?
            ORDER BY min_order DESC LIMIT 1`,
        )
        .get(stateId, lgaId, method, subtotal) as any)
    : null;
  if (lgaRule) return { fee: lgaRule.fee, eta: lgaRule.eta_days };
  const stateRule = await db
    .prepare(
      `SELECT fee, eta_days FROM delivery_fees
        WHERE state_id = ? AND lga_id IS NULL AND method = ? AND is_active = 1 AND min_order <= ?
        ORDER BY min_order DESC LIMIT 1`,
    )
    .get(stateId, method, subtotal) as any;
  if (stateRule) return { fee: stateRule.fee, eta: stateRule.eta_days };
  return { fee: method === 'express' ? 6500 : 3500, eta: method === 'express' ? 1 : 4 };
}

/**
 * ── AUTOMATIC STATE-BASED ORDER ASSIGNMENT ─────────────────────────────────
 * Determines the order's SAVED delivery state and attaches the active
 * administrator for that state. Never assigns an out-of-state administrator.
 * Unmatched orders stay in the unassigned queue; only the super admin is told.
 */
export async function assignOrderToState(orderId: number, assignedBy: SessionUser | null = null, reason = 'auto') {
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) return { admin: null, unassigned: true };
  const admin = await db
    .prepare(
      `SELECT id, full_name, email, admin_state_id FROM users
        WHERE role = 'state_admin' AND admin_state_id = ? AND is_active = 1 AND is_suspended = 0
        ORDER BY id LIMIT 1`,
    )
    .get(order.state_id) as any;

  await db.prepare('UPDATE orders SET assigned_admin_id = ?, updated_at = datetime(\'now\') WHERE id = ?').run(
    admin?.id ?? null,
    orderId,
  );
  await db.prepare(
    'INSERT INTO order_assignments (order_id, admin_id, admin_name, state_id, assigned_by, reason) VALUES (?,?,?,?,?,?)',
  ).run(orderId, admin?.id ?? null, admin?.full_name ?? null, order.state_id, assignedBy?.id ?? null, reason);

  if (!admin) {
    await notifyOrder({
      orderId,
      type: 'new_order',
      title: `Unassigned order ${order.order_number} — no administrator for ${await stateName(order.state_id)}`,
      body: `No active state administrator is assigned to ${await stateName(order.state_id)}. The order is in the unassigned queue and needs super-admin attention.`,
    });
  }
  return { admin, unassigned: !admin };
}

export type NewOrderInput = {
  user: SessionUser;
  customerName: string;
  phone: string;
  email: string;
  stateId: number;
  lgaId: number;
  addressText: string;
  instructions?: string | null;
  deliveryMethod?: string;
  promoCode?: string | null;
  items: { productId: number; color?: string | null; storage?: string | null; qty: number }[];
};

/** Atomic order creation + stock reservation. Throws on any inconsistency. */
export async function createOrder(input: NewOrderInput) {
  const db = getDb();
  if (!input.items.length) throw new Error('Your cart is empty.');
  const result = await tx(async (d) => {
    let subtotal = 0;
    const rows: any[] = [];
    for (const it of input.items) {
      const p = await d.prepare('SELECT * FROM products WHERE id = ? AND is_active = 1').get(it.productId) as any;
      if (!p) throw new Error('A product in your cart is no longer available.');
      const qty = Math.max(1, Math.floor(it.qty));
      const available = p.stock - p.reserved;
      if (available < qty) throw new Error(`${p.name} has only ${available} unit(s) left in stock.`);
      const unit = p.is_flash_sale && p.flash_price ? p.flash_price : p.price;
      const line = unit * qty;
      subtotal += line;
      rows.push({ p, qty, unit, line, color: it.color, storage: it.storage });
    }

    let discount = 0;
    let promoLabel: string | null = null;
    let freeDelivery = false;
    if (input.promoCode) {
      const promo = await d
        .prepare(
          `SELECT * FROM promotions WHERE code = ? AND is_active = 1
             AND (starts_at IS NULL OR starts_at <= datetime('now'))
             AND (ends_at IS NULL OR ends_at >= datetime('now'))`,
        )
        .get(input.promoCode.toUpperCase()) as any;
      if (!promo) throw new Error('That discount code is invalid or has expired.');
      if (promo.max_uses && promo.used_count >= promo.max_uses) throw new Error('That discount code has been fully redeemed.');
      if (subtotal < promo.min_order) throw new Error(`Add ₦${(promo.min_order - subtotal).toLocaleString()} more to use ${promo.code}.`);
      if (promo.type === 'percent') discount = Math.round((subtotal * promo.value) / 100);
      else if (promo.type === 'fixed') discount = Math.min(promo.value, subtotal);
      else if (promo.type === 'free_delivery') freeDelivery = true;
      promoLabel = promo.code;
    }

    const method = input.deliveryMethod || 'standard';
    const feeInfo = await deliveryFeeFor(input.stateId, input.lgaId, method, subtotal - discount);
    const deliveryFee = freeDelivery ? 0 : feeInfo.fee;
    const total = Math.max(0, subtotal - discount) + deliveryFee;
    const number = genOrderNumber();

    const orderRes = await d
      .prepare(
        `INSERT INTO orders (order_number, user_id, customer_name, phone, email, status, payment_status,
            subtotal, discount, promo_code, delivery_fee, total, state_id, lga_id, address_text, instructions, delivery_method)
         VALUES (?,?,?,?,?, 'pending_payment', 'unpaid', ?,?,?,?,?,?,?,?,?,?)`,
      )
      .run(
        number,
        input.user.id,
        input.customerName,
        input.phone,
        input.email,
        subtotal,
        discount,
        promoLabel,
        deliveryFee,
        total,
        input.stateId,
        input.lgaId,
        input.addressText,
        input.instructions ?? null,
        method,
      );
    const orderId = Number(orderRes.lastInsertRowid);

    const insItem = await d.prepare(
      `INSERT INTO order_items (order_id, product_id, name, image, brand, model, color, storage, qty, unit_price, line_total)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    );
    for (const r of rows) {
      const img = await d.prepare('SELECT url FROM product_images WHERE product_id = ? ORDER BY sort_order LIMIT 1').get(r.p.id) as any;
      await insItem.run(orderId, r.p.id, r.p.name, img?.url ?? null, r.p.brand, r.p.model, r.color ?? null, r.storage ?? null, r.qty, r.unit, r.line);
      // reserve stock atomically
      await d.prepare('UPDATE products SET stock = stock - ?, reserved = reserved + ? WHERE id = ? AND stock - reserved >= 0').run(
        r.qty,
        r.qty,
        r.p.id,
      );
      await d.prepare('INSERT INTO stock_logs (product_id, change, reason, order_id) VALUES (?,?,?,?)').run(
        r.p.id,
        -r.qty,
        'reserved_for_order',
        orderId,
      );
    }

    if (promoLabel) await d.prepare('UPDATE promotions SET used_count = used_count + 1 WHERE code = ?').run(promoLabel);

    const eta = new Date(Date.now() + feeInfo.eta * 864e5).toISOString().slice(0, 10);
    await d.prepare(
      'INSERT INTO deliveries (order_id, status, tracking_ref, eta_date) VALUES (?,?,?,?)',
    ).run(orderId, 'pending', `TRK-${number.slice(4)}`, eta);

    await d.prepare(
      "INSERT INTO order_events (order_id, status, note, actor_id, actor_role) VALUES (?, 'pending_payment', 'Order created — awaiting payment', ?, 'customer')",
    ).run(orderId, input.user.id);

    return { orderId, number, subtotal, discount, deliveryFee, total };
  });

  // assignment + notifications happen after commit
  const { admin } = await assignOrderToState(result.orderId);
  const stateLabel = await stateName(input.stateId);
  await notifyOrder({
    orderId: result.orderId,
    type: 'new_order',
    title: `New order ${result.number} — ${input.customerName} (${stateLabel})`,
    body: `A new order was placed for delivery to ${stateLabel}. Total ₦${result.total.toLocaleString()}. ${
      admin ? `Assigned to ${admin.full_name}.` : 'UNASSIGNED — no administrator configured for this state.'
    }`,
  });
  await notifyCustomer({
    userId: input.user.id,
    type: 'order_created',
    title: `Order ${result.number} received`,
    body: `We have received your order. Complete payment to start processing. Total ₦${result.total.toLocaleString()}.`,
    orderId: result.orderId,
    stateId: input.stateId,
  });
  return result;
}

export async function addOrderEvent(orderId: number, status: string, note: string | null, actor: SessionUser | null) {
  const db = getDb();
  await db.prepare('INSERT INTO order_events (order_id, status, note, actor_id, actor_role) VALUES (?,?,?,?,?)').run(
    orderId,
    status,
    note,
    actor?.id ?? null,
    actor?.role ?? 'system',
  );
}

export function allowedNextStatuses(order: any, user: SessionUser) {
  const base = NEXT_STATUS[order.status] ?? [];
  if (user.role === 'super_admin') {
    const all = ['order_confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered', 'cancelled', 'returned', 'refund_pending', 'refunded'];
    return Array.from(new Set([...base, ...all])).filter((s) => s !== order.status);
  }
  return base;
}

/** Central status machine: authorization, transitions, side-effects, notifications. */
export async function changeOrderStatus(opts: {
  orderId: number;
  status: string;
  note?: string | null;
  actor: SessionUser;
  skipTransitionCheck?: boolean;
}) {
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(opts.orderId) as any;
  if (!order) throw new Error('Order not found.');
  const actor = opts.actor;
  if (actor.role === 'state_admin' && actor.admin_state_id !== order.state_id) {
    throw new Error('FORBIDDEN: this order belongs to another state.');
  }
  if (!opts.skipTransitionCheck) {
    const allowed = allowedNextStatuses(order, actor);
    if (!allowed.includes(opts.status)) {
      throw new Error(`Cannot move order from ${STATUS_LABEL[order.status]} to ${STATUS_LABEL[opts.status]}.`);
    }
  }

  await tx<void>(async (d) => {
    const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
    await d.prepare("UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?").run(opts.status, order.id);
    const del = await d.prepare('SELECT * FROM deliveries WHERE order_id = ?').get(order.id) as any;
    if (del) {
      if (opts.status === 'shipped')
        await d.prepare("UPDATE deliveries SET status='shipped', shipped_at=COALESCE(shipped_at, ?), updated_at=datetime('now') WHERE order_id=?").run(now, order.id);
      else if (opts.status === 'out_for_delivery')
        await d.prepare("UPDATE deliveries SET status='out_for_delivery', out_for_delivery_at=?, updated_at=datetime('now') WHERE order_id=?").run(now, order.id);
      else if (opts.status === 'delivered')
        await d.prepare("UPDATE deliveries SET status='delivered', delivered_at=?, updated_at=datetime('now') WHERE order_id=?").run(now, order.id);
      else
        await d.prepare("UPDATE deliveries SET status=?, updated_at=datetime('now') WHERE order_id=?").run(opts.status, order.id);
    }
    if (opts.status === 'cancelled' && order.status !== 'cancelled') {
      // release reserved stock
      const items = await d.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id) as any[];
      for (const it of items) {
        if (!it.product_id) continue;
        await d.prepare('UPDATE products SET stock = stock + ?, reserved = MAX(reserved - ?, 0) WHERE id = ?').run(it.qty, it.qty, it.product_id);
        await d.prepare('INSERT INTO stock_logs (product_id, change, reason, order_id, admin_id) VALUES (?,?,?,?,?)').run(
          it.product_id,
          it.qty,
          'released_from_cancelled_order',
          order.id,
          actor.id,
        );
      }
    }
    await d.prepare(
      'INSERT INTO order_events (order_id, status, note, actor_id, actor_role) VALUES (?,?,?,?,?)',
    ).run(order.id, opts.status, opts.note ?? null, actor.id, actor.role);
  });

  const typeMap: Record<string, any> = {
    order_confirmed: 'order_confirmed',
    processing: 'order_processing',
    packed: 'order_processing',
    shipped: 'order_shipped',
    out_for_delivery: 'order_out_for_delivery',
    delivered: 'order_delivered',
    cancelled: 'order_cancelled',
    returned: 'return_requested',
    refund_pending: 'refund_requested',
    refunded: 'refund_completed',
  };
  await notifyOrder({
    orderId: order.id,
    type: typeMap[opts.status] ?? 'order_confirmed',
    title: `Order ${order.order_number} → ${STATUS_LABEL[opts.status]}`,
    body: opts.note || `Status updated by ${actor.full_name} (${actor.role === 'super_admin' ? 'Super admin' : 'State administrator'}).`,
  });
  if (order.user_id) {
    await notifyCustomer({
      userId: order.user_id,
      type: 'order_status',
      title: `Order ${order.order_number}: ${STATUS_LABEL[opts.status]}`,
      body: opts.note || `Your order is now ${STATUS_LABEL[opts.status]}.`,
      orderId: order.id,
      stateId: order.state_id,
    });
  }
  if (opts.status === 'delivered')await  createWarrantiesForOrder(order.id);
  await logAdmin(actor, `order.status.${opts.status}`, 'order', order.id, { note: opts.note });
  return await db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id);
}

/** Create one warranty record per delivered item, starting at delivery date. */
export async function createWarrantiesForOrder(orderId: number) {
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order?.user_id) return 0;
  const deliveryDate = (await db.prepare('SELECT delivered_at FROM deliveries WHERE order_id = ?').get(orderId) as any)?.delivered_at
    || new Date().toISOString().slice(0, 10);
  const items = await db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId) as any[];
  let created = 0;
  for (const it of items) {
    const existing = await db.prepare('SELECT id FROM warranties WHERE order_item_id = ?').get(it.id);
    if (existing) continue;
    const p = it.product_id ? (await db.prepare('SELECT * FROM products WHERE id = ?').get(it.product_id) as any) : null;
    const months = p?.warranty_months ?? 12;
    const start = new Date(deliveryDate);
    const expiry = new Date(start);
    expiry.setMonth(expiry.getMonth() + months);
    await db.prepare(
      `INSERT INTO warranties (order_id, order_item_id, user_id, product_id, product_name, model, serial_no,
        purchase_date, delivery_date, start_date, duration_months, expiry_date, conditions)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    ).run(
      orderId,
      it.id,
      order.user_id,
      it.product_id,
      it.name,
      it.model,
      it.serial_no,
      order.created_at,
      deliveryDate,
      start.toISOString().slice(0, 10),
      months,
      expiry.toISOString().slice(0, 10),
      p?.warranty_policy ||
        `${months}-month OBAHTECH Gadgets warranty covering manufacturing defects. Excludes physical damage, liquid damage and unauthorised repairs.`,
    );
    created++;
  }
  return created;
}

export async function orderSummaryForNotification(orderId: number) {
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) return null;
  const items = await db
    .prepare('SELECT name, image, model, color, storage, qty, unit_price, line_total FROM order_items WHERE order_id = ?')
    .all(orderId) as any[];
  return {
    order,
    items,
    state: (await db.prepare('SELECT name FROM states WHERE id = ?').get(order.state_id) as any)?.name,
    lga: (await db.prepare('SELECT name FROM lgas WHERE id = ?').get(order.lga_id) as any)?.name,
  };
}
