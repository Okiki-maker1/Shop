import { getDb } from './db';

export type ProductRow = {
  id: number;
  name: string;
  slug: string;
  brand: string;
  model: string;
  category_id: number;
  category_name?: string;
  category_slug?: string;
  description: string;
  short_description: string | null;
  specs: string | null;
  ram: string | null;
  storage_options: string | null;
  color_options: string | null;
  battery: string | null;
  screen_size: string | null;
  network: string | null;
  condition: string;
  warranty_months: number;
  warranty_policy: string | null;
  price: number;
  compare_price: number | null;
  stock: number;
  reserved: number;
  sold: number;
  low_stock_at: number;
  sku: string;
  tracks_serial: number;
  rating_avg: number;
  rating_count: number;
  is_featured: number;
  is_flash_sale: number;
  flash_price: number | null;
  flash_ends_at: string | null;
  is_active: number;
  image: string | null;
};

const BASE = `
  SELECT p.*, c.name AS category_name, c.slug AS category_slug,
         (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
    FROM products p JOIN categories c ON c.id = p.category_id`;

export type ProductFilters = {
  q?: string;
  category?: string;
  brand?: string;
  minPrice?: number;
  maxPrice?: number;
  ram?: string;
  storage?: string;
  condition?: string;
  network?: string;
  sort?: string;
  page?: number;
  perPage?: number;
  featured?: boolean;
  flash?: boolean;
  inStock?: boolean;
  includeInactive?: boolean;
};

export async function listProducts(f: ProductFilters) {
  const db = getDb();
  const where: string[] = [];
  const params: any[] = [];
  if (!f.includeInactive) where.push('p.is_active = 1');
  if (f.category && f.category !== 'all') {
    where.push('c.slug = ?');
    params.push(f.category);
  }
  if (f.q) {
    where.push('(p.name LIKE ? OR p.brand LIKE ? OR p.model LIKE ? OR p.description LIKE ? OR c.name LIKE ?)');
    const like = `%${f.q}%`;
    params.push(like, like, like, like, like);
  }
  if (f.brand) {
    where.push('p.brand = ?');
    params.push(f.brand);
  }
  if (f.minPrice) {
    where.push('p.price >= ?');
    params.push(f.minPrice);
  }
  if (f.maxPrice) {
    where.push('p.price <= ?');
    params.push(f.maxPrice);
  }
  if (f.ram) {
    where.push('p.ram = ?');
    params.push(f.ram);
  }
  if (f.storage) {
    where.push('p.storage_options LIKE ?');
    params.push(`%${f.storage}%`);
  }
  if (f.condition) {
    where.push('p.condition = ?');
    params.push(f.condition);
  }
  if (f.network) {
    where.push('p.network LIKE ?');
    params.push(`%${f.network}%`);
  }
  if (f.featured) where.push('p.is_featured = 1');
  if (f.flash) where.push('p.is_flash_sale = 1 AND p.flash_price IS NOT NULL');
  if (f.inStock) where.push('(p.stock - p.reserved) > 0');

  const sortMap: Record<string, string> = {
    'price-asc': 'p.price ASC',
    'price-desc': 'p.price DESC',
    newest: 'p.created_at DESC, p.id DESC',
    rating: 'p.rating_avg DESC, p.rating_count DESC',
    popular: 'p.sold DESC, p.rating_count DESC',
    discount: '(COALESCE(p.compare_price, p.price) - p.price) DESC',
  };
  const order = sortMap[f.sort || 'popular'] ?? sortMap.popular;
  const perPage = Math.min(60, f.perPage ?? 24);
  const page = Math.max(1, f.page ?? 1);
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const total = (await db.prepare(`SELECT COUNT(*) c FROM products p JOIN categories c ON c.id = p.category_id ${whereSql}`).get(...params) as any).c;
  const items = await db
    .prepare(`${BASE} ${whereSql} ORDER BY ${order} LIMIT ? OFFSET ?`)
    .all(...params, perPage, (page - 1) * perPage) as ProductRow[];
  return { items, total, page, pages: Math.max(1, Math.ceil(total / perPage)), perPage };
}

export async function productBySlug(slug: string) {
  const db = getDb();
  return await db.prepare(`${BASE} WHERE p.slug = ?`).get(slug) as ProductRow | undefined;
}

export async function productById(id: number) {
  const db = getDb();
  return await db.prepare(`${BASE} WHERE p.id = ?`).get(id) as ProductRow | undefined;
}

export async function productImages(id: number) {
  const db = getDb();
  return await db
    .prepare('SELECT id, url, alt, sort_order FROM product_images WHERE product_id = ? ORDER BY sort_order')
    .all(id) as { id: number; url: string; alt: string | null; sort_order: number }[];
}

export async function productVariants(id: number) {
  const db = getDb();
  return await db.prepare('SELECT * FROM product_variants WHERE product_id = ?').all(id) as any[];
}

export async function productReviews(id: number) {
  const db = getDb();
  return await db
    .prepare("SELECT * FROM reviews WHERE product_id = ? AND status = 'published' ORDER BY id DESC LIMIT 20")
    .all(id) as any[];
}

export async function categories() {
  const db = getDb();
  return await db.prepare('SELECT * FROM categories ORDER BY sort_order').all() as any[];
}

export async function activeBanners(placement: string) {
  const db = getDb();
  return await db
    .prepare(
      `SELECT * FROM banners WHERE placement = ? AND is_active = 1
        AND (starts_at IS NULL OR starts_at <= datetime('now'))
        AND (ends_at IS NULL OR ends_at >= datetime('now'))
        ORDER BY sort_order, id`,
    )
    .all(placement) as any[];
}

export async function facets(categorySlug?: string) {
  const db = getDb();
  const cat = categorySlug && categorySlug !== 'all' ? `AND c.slug = '${categorySlug.replace(/[^a-z0-9-]/g, '')}'` : '';
  const brands = await db
    .prepare(`SELECT p.brand AS brand, COUNT(*) c FROM products p JOIN categories c ON c.id = p.category_id WHERE p.is_active = 1 ${cat} GROUP BY p.brand ORDER BY c DESC`)
    .all() as any[];
  const rams = await db
    .prepare(`SELECT p.ram AS ram, COUNT(*) c FROM products p JOIN categories c ON c.id = p.category_id WHERE p.is_active = 1 AND p.ram IS NOT NULL ${cat} GROUP BY p.ram ORDER BY c DESC LIMIT 10`)
    .all() as any[];
  const storages = await db
    .prepare(`SELECT p.storage_options AS s FROM products p JOIN categories c ON c.id = p.category_id WHERE p.is_active = 1 ${cat} GROUP BY p.storage_options`)
    .all() as any[];
  const storageSet = new Set<string>();
  for (const row of storages) {
    try {
      (JSON.parse(row.s || '[]') as string[]).forEach((s) => storageSet.add(s));
    } catch {}
  }
  const conditions = await db
    .prepare(`SELECT DISTINCT p.condition AS condition FROM products p JOIN categories c ON c.id = p.category_id WHERE p.is_active = 1 ${cat}`)
    .all() as any[];
  return {
    brands,
    rams: rams.filter((r) => r.ram && r.ram !== '—'),
    storages: Array.from(storageSet).sort(),
    conditions: conditions.map((c) => c.condition),
  };
}

export async function wishlistIds(userId?: number | null) {
  if (!userId) return new Set<number>();
  const db = getDb();
  const rows = await db.prepare('SELECT product_id FROM wishlists WHERE user_id = ?').all(userId) as any[];
  return new Set(rows.map((r) => r.product_id as number));
}

export async function reviewsShowcase() {
  const db = getDb();
  return await db
    .prepare(
      `SELECT r.*, p.name AS product_name, p.slug AS product_slug,
              (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
         FROM reviews r JOIN products p ON p.id = r.product_id
        WHERE r.status = 'published' ORDER BY r.rating DESC, r.id DESC LIMIT 6`,
    )
    .all() as any[];
}

export async function recentOrderCountForProductBuyers(productId: number) {
  const db = getDb();
  return (await db.prepare('SELECT COUNT(DISTINCT order_id) c FROM order_items WHERE product_id = ?').get(productId) as any).c;
}
