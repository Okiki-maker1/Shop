import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ALLOWED = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml', 'image/gif']);
const MAX_BYTES = 1.5 * 1024 * 1024;

/**
 * Image upload storage.
 *
 *  • Self-hosted / development: writes into `public/uploads/...` and returns
 *    the public path — unchanged behaviour.
 *  • Netlify (read-only, ephemeral filesystem — `process.env.NETLIFY`): the
 *    file is returned as an inline data URI instead, which is persisted in
 *    the database with the image and rendered by `<img>` with no extra
 *    infrastructure. The URL contract stays identical: a string the <img>
 *    tag can always display.
 *
 * For Supabase Storage, swap the local branch for
 * `supabase.storage.from('products').upload(...)` — the returned public URL
 * contract stays identical.
 */
export async function saveUpload(file: File | null, folder = 'products'): Promise<string | null> {
  if (!file || typeof file === 'string' || !file.size) return null;
  if (!ALLOWED.has(file.type)) throw new Error('Upload a PNG, JPG, WEBP, GIF or SVG image.');
  if (file.size > MAX_BYTES) throw new Error('Image must be smaller than 1.5MB.');
  const ext = file.type === 'image/svg+xml' ? 'svg' : file.type.split('/')[1];
  const name = `${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
  const buf = Buffer.from(await file.arrayBuffer());

  const onNetlify = process.env.NETLIFY === 'true' || process.env.CONTEXT === 'netlify';
  if (!onNetlify) {
    try {
      const dir = path.join(process.cwd(), 'public', 'uploads', folder);
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, name), buf);
      return `/uploads/${folder}/${name}`;
    } catch {
      // read-only filesystem — fall through to the data URI below
    }
  }
  return `data:${file.type};base64,${buf.toString('base64')}`;
}
