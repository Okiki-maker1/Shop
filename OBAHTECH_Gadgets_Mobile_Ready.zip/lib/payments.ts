import { getDb, tx } from './db';
import { notifyOrder, notifyCustomer, queueEmail } from './notify';
import { txRef as genTxRef } from './format';
import { addOrderEvent } from './orders';

export function flwConfig() {
  const publicKey = process.env.FLW_PUBLIC_KEY || '';
  const secretKey = process.env.FLW_SECRET_KEY || '';
  const hash = process.env.FLW_SECRET_HASH || '';
  const configured = Boolean(publicKey && secretKey && !publicKey.includes('xxxxx') && !secretKey.includes('xxxxx'));
  return { publicKey, secretKey, hash, configured };
}

export function appUrl() {
  return process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
}

/**
 * Create a payment record and (when keys are configured) initialise a
 * Flutterwave Standard checkout session. The secret key never leaves the server.
 */
export async function startPayment(orderId: number) {
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) throw new Error('Order not found.');
  if (order.payment_status === 'paid') throw new Error('This order is already paid.');

  const existing = await db
    .prepare("SELECT * FROM payments WHERE order_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1")
    .get(orderId) as any;
  const txRef = existing?.tx_ref ?? genTxRef(order.order_number);
  if (!existing) {
    await db.prepare(
      "INSERT INTO payments (order_id, tx_ref, amount, currency, status) VALUES (?,?,?, 'NGN', 'pending')",
    ).run(orderId, txRef, order.total);
  }

  const cfg = flwConfig();
  if (!cfg.configured) {
    // SAFE SANDBOX MODE — no keys configured, so no real charge can be attempted.
    return { sandbox: true, txRef, link: `/payments/${order.order_number}/sandbox?tx_ref=${txRef}` };
  }

  const body = {
    tx_ref: txRef,
    amount: order.total,
    currency: 'NGN',
    redirect_url: `${appUrl()}/payments/callback`,
    customer: { email: order.email, phonenumber: order.phone, name: order.customer_name },
    customizations: {
      title: 'OBAHTECH Gadgets',
      description: `Payment for order ${order.order_number}`,
      logo: `${appUrl()}/brand/logo-mark.svg`,
    },
    meta: { order_number: order.order_number, order_id: order.id },
  };
  const res = await fetch('https://api.flutterwave.com/v3/payments', {
    method: 'POST',
    headers: { Authorization: `Bearer ${cfg.secretKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const json: any = await res.json().catch(() => ({}));
  if (!res.ok || json?.status !== 'success' || !json?.data?.link) {
    await db.prepare("UPDATE payments SET status = 'failed', raw_response = ? WHERE tx_ref = ?").run(JSON.stringify(json).slice(0, 4000), txRef);
    throw new Error(json?.message || 'Flutterwave could not initialise this payment. Please try again.');
  }
  await db.prepare('UPDATE payments SET raw_response = ? WHERE tx_ref = ?').run(JSON.stringify(json).slice(0, 4000), txRef);
  return { sandbox: false, txRef, link: json.data.link as string };
}

/** Backend verification against Flutterwave. Never trust a client "success" flag. */
export async function verifyTransaction(transactionId: string) {
  const cfg = flwConfig();
  if (!cfg.configured) throw new Error('Flutterwave is not configured.');
  const res = await fetch(`https://api.flutterwave.com/v3/transactions/${encodeURIComponent(transactionId)}/verify`, {
    headers: { Authorization: `Bearer ${cfg.secretKey}` },
    cache: 'no-store',
  });
  const json: any = await res.json().catch(() => ({}));
  if (!res.ok || json?.status !== 'success') throw new Error(json?.message || 'Could not verify this transaction.');
  return json.data;
}

/**
 * Settlement used by BOTH the browser callback and the webhook.
 * Validates reference, amount, currency and status before marking the order paid.
 * Idempotent — duplicate callbacks/webhooks cannot double-settle an order.
 */
export async function settlePayment(opts: {
  txRef?: string | null;
  transactionId?: string | null;
  sandbox?: boolean;
  outcome?: 'successful' | 'failed';
  raw?: any;
}) {
  const db = getDb();
  const payment = opts.txRef
    ? (await db.prepare('SELECT * FROM payments WHERE tx_ref = ?').get(opts.txRef) as any)
    : (await db.prepare('SELECT * FROM payments WHERE flw_ref = ? OR tx_ref = ?').get(opts.transactionId, opts.transactionId) as any);
  if (!payment) throw new Error('Unknown transaction reference.');
  if (payment.status === 'successful') return { already: true, orderId: payment.order_id };

  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(payment.order_id) as any;
  if (!order) throw new Error('Order not found.');

  const successful = opts.outcome === 'successful';
  await tx<void>(async (d) => {
    await d.prepare(
      "UPDATE payments SET status = ?, flw_ref = COALESCE(?, flw_ref), sandbox = ?, raw_response = ?, verified_at = datetime('now'), method = COALESCE(?, method) WHERE id = ?",
    ).run(
      successful ? 'successful' : 'failed',
      opts.transactionId ?? null,
      opts.sandbox ? 1 : 0,
      JSON.stringify(opts.raw ?? {}).slice(0, 4000),
      (opts.raw as any)?.payment_type ?? null,
      payment.id,
    );
    await d.prepare("INSERT INTO transactions (payment_id, order_id, reference, type, amount, status, meta) VALUES (?,?,?, 'charge', ?, ?, ?)").run(
      payment.id,
      order.id,
      payment.tx_ref,
      payment.amount,
      successful ? 'successful' : 'failed',
      JSON.stringify({ gateway: opts.sandbox ? 'sandbox' : 'flutterwave' }),
    );
    if (successful) {
      await d.prepare(
        "UPDATE orders SET payment_status = 'paid', status = CASE WHEN status = 'pending_payment' THEN 'payment_confirmed' ELSE status END, updated_at = datetime('now') WHERE id = ?",
      ).run(order.id);
      const items = await d.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id) as any[];
      for (const it of items) {
        if (!it.product_id) continue;
        await d.prepare('UPDATE products SET reserved = MAX(reserved - ?, 0), sold = sold + ? WHERE id = ?').run(it.qty, it.qty, it.product_id);
        await d.prepare('INSERT INTO stock_logs (product_id, change, reason, order_id) VALUES (?,?,?,?)').run(it.product_id, 0, 'sold_via_paid_order', order.id);
      }
    } else {
      await d.prepare("UPDATE orders SET payment_status = 'failed', updated_at = datetime('now') WHERE id = ?").run(order.id);
    }
  });

  await addOrderEvent(
    order.id,
    successful ? 'payment_confirmed' : 'pending_payment',
    successful
      ? `Payment verified (${opts.sandbox ? 'sandbox' : 'flutterwave'}) ref ${opts.transactionId ?? payment.tx_ref}`
      : 'Payment attempt failed',
    null,
  );

  if (successful) {
    await notifyOrder({
      orderId: order.id,
      type: 'payment_success',
      title: `Payment received for ${order.order_number} — ₦${payment.amount.toLocaleString()}`,
      body: `Flutterwave confirmation verified on the server. Reference ${opts.transactionId ?? payment.tx_ref}.`,
    });
    if (order.user_id)
      await notifyCustomer({
        userId: order.user_id,
        type: 'payment',
        title: `Payment confirmed for ${order.order_number}`,
        body: `We received ₦${payment.amount.toLocaleString()}. Your order is now being prepared.`,
        orderId: order.id,
        stateId: order.state_id,
      });
    await queueEmail(order.email, `Payment receipt — ${order.order_number}`, `Thank you. We received ₦${payment.amount.toLocaleString()} for order ${order.order_number}.`);
  } else {
    await notifyOrder({
      orderId: order.id,
      type: 'payment_failed',
      title: `Payment failed for ${order.order_number}`,
      body: `The customer's payment attempt failed. They may retry from their order page.`,
    });
  }
  return { already: false, orderId: order.id, successful };
}
