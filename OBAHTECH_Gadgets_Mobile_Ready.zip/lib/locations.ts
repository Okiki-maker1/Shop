import { NIGERIA, STATE_NAMES, lgasOf, isValidStateLga } from './nigeria';

export type StateRow = { id: number; name: string };
export type LgaRow = { id: number; state_id: number; name: string };

/** Insert reference data once. Called from the seeder. */
export async function seedLocations(db: any) {
  const count = ((await db.prepare('SELECT COUNT(*) c FROM states').get()) as any).c as number;
  if (count > 0) return;
  const insState = await db.prepare('INSERT INTO states (name) VALUES (?)');
  const insLga = await db.prepare('INSERT INTO lgas (state_id, name) VALUES (?, ?)');
  const run = db.transaction(async () => {
    for (const state of STATE_NAMES) {
      const { lastInsertRowid } = await insState.run(state);
      for (const lga of NIGERIA[state])await  insLga.run(lastInsertRowid, lga);
    }
  });
  await run();
}

export async function allStates(db: any): Promise<StateRow[]> {
  return await db.prepare('SELECT id, name FROM states ORDER BY name').all();
}

export async function stateById(db: any, id: number): Promise<StateRow | undefined> {
  return await db.prepare('SELECT id, name FROM states WHERE id = ?').get(id);
}

export async function stateByName(db: any, name: string): Promise<StateRow | undefined> {
  return await db.prepare('SELECT id, name FROM states WHERE name = ?').get(name);
}

export async function lgasForState(db: any, stateId: number): Promise<LgaRow[]> {
  return await db.prepare('SELECT id, state_id, name FROM lgas WHERE state_id = ? ORDER BY name').all(stateId);
}

export async function lgaByName(db: any, stateId: number, name: string): Promise<LgaRow | undefined> {
  return await db.prepare('SELECT id, state_id, name FROM lgas WHERE state_id = ? AND name = ?').get(stateId, name);
}

export async function lgaById(db: any, id: number): Promise<LgaRow | undefined> {
  return await db.prepare('SELECT id, state_id, name FROM lgas WHERE id = ?').get(id);
}

/**
 * Authoritative backend validation of a state↔LGA pair.
 * Never trust the two ids coming from the browser independently.
 */
export async function validatePair(db: any, stateId: number, lgaId: number): Promise<{ ok: boolean; state?: StateRow; lga?: LgaRow; error?: string }> {
  const state = await stateById(db, Number(stateId));
  const lga = await lgaById(db, Number(lgaId));
  if (!state) return { ok: false, error: 'Select a valid Nigerian state.' };
  if (!lga) return { ok: false, error: 'Select a valid Local Government Area.' };
  if (lga.state_id !== state.id) return { ok: false, error: 'That LGA does not belong to the selected state.' };
  if (!isValidStateLga(state.name, lga.name)) return { ok: false, error: 'Invalid state/LGA combination.' };
  return { ok: true, state, lga };
}

export function lgasOfStateName(name: string) {
  return lgasOf(name);
}
