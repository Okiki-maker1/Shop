import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { Empty } from '@/components/ui';
import { timeAgo } from '@/lib/format';
import { markNotificationsRead } from '@/lib/actions/customer';

export const metadata = { title: 'Notifications' };
export const dynamic = 'force-dynamic';

const TONE: Record<string, string> = {
  order_status: 'bg-sky-50 text-sky-700',
  payment: 'bg-emerald-50 text-emerald-700',
  announcement: 'bg-obah-50 text-obah-700',
  warranty: 'bg-violet-50 text-violet-700',
  return: 'bg-amber-50 text-amber-700',
  order_created: 'bg-gray-50 text-ink-600',
};

export default async function NotificationsPage() {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/notifications');
  const db = getDb();
  const rows = await db
    .prepare('SELECT * FROM notifications WHERE recipient_user_id = ? ORDER BY id DESC LIMIT 100')
    .all(user.id) as any[];
  const unread = rows.filter((r) => !r.is_read).length;

  return (
    <div className="container-obah max-w-3xl py-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-extrabold text-ink-800">Notifications</h1>
          <p className="text-[11px] text-ink-400">{unread} unread · persisted across sessions</p>
        </div>
        {unread > 0 && (
          <form action={markNotificationsRead}>
            <button className="btn-outline btn-sm">Mark all as read</button>
          </form>
        )}
      </div>
      {rows.length === 0 ? (
        <Empty title="No notifications yet" hint="Order updates, payment receipts and announcements will appear here." />
      ) : (
        <div className="space-y-2">
          {rows.map((n) => (
            <div key={n.id} className={`card p-3 ${n.is_read ? '' : 'ring-1 ring-obah-200'}`}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`chip ${TONE[n.type] ?? 'bg-gray-100 text-ink-600 ring-gray-200'} ring-transparent`}>{n.type.replace(/_/g, ' ')}</span>
                    {!n.is_read && <span className="h-1.5 w-1.5 rounded-full bg-obah-500" />}
                  </div>
                  <p className="mt-1 text-sm font-semibold text-ink-800">{n.title}</p>
                  {n.body && <p className="text-xs text-ink-500">{n.body}</p>}
                  <p className="mt-1 text-[10px] text-ink-300">{timeAgo(n.created_at)}</p>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  {n.order_id && <Link href={`/orders`} className="text-[10px] font-bold text-obah-600">View order</Link>}
                  {!n.is_read && (
                    <form action={markNotificationsRead}>
                      <input type="hidden" name="id" value={n.id} />
                      <button className="text-[10px] font-semibold text-ink-400 hover:text-obah-600">Mark read</button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
