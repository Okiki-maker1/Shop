import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Privacy policy' };

const SECTIONS: [string, string[]][] = [
  [
    'What we collect',
    [
      'Account details: your name, email address, phone number, password hash, and the state and LGA you register from.',
      'Delivery details: the recipient name, phone number, street address and any delivery instructions you save.',
      'Order and payment details: what you bought, the amount, the Flutterwave transaction reference and the gateway result. We never see or store your card number, CVV or bank credentials — those are entered on Flutterwave’s hosted page.',
      'Support content: messages, warranty claims and return requests, including any photos you upload as evidence.',
      'Technical data: session cookie, IP address used for rate limiting, and audit records of administrative actions.',
    ],
  ],
  [
    'Why we collect it',
    [
      'To create and secure your account, take payment, deliver your order and handle warranties, returns and complaints.',
      'To route each order to the administrator responsible for your delivery state — which is why the state and LGA are stored on the order itself, not just on your profile.',
      'To meet Nigerian consumer-protection and tax record-keeping obligations, and to detect fraud.',
    ],
  ],
  [
    'Who can see your data',
    [
      'The OBAHTECH super administrator (nationwide) and the administrator assigned to the state your order is delivered to. A state administrator cannot open orders or customer records belonging to another state — this is enforced in the database as well as in the application.',
      'Our payment partner Flutterwave receives the amount, currency and a reference for each transaction. Our email and SMS providers receive the address or phone number needed to send you that specific message.',
      'We do not sell personal data, and we do not share it with advertisers.',
    ],
  ],
  [
    'How long we keep it',
    [
      'Order, warranty and refund records are retained for seven years to satisfy accounting and consumer-law requirements. Audit logs of administrative actions are retained for two years.',
      'You may ask us to close your account; we will delete your profile details while keeping the anonymised order history we are legally required to retain.',
    ],
  ],
  [
    'Cookies',
    [
      'We use one essential cookie to keep you signed in. It is HTTP-only and cannot be read by JavaScript. We do not use advertising cookies or third-party trackers.',
    ],
  ],
  [
    'Security',
    [
      'Passwords are hashed with bcrypt. Sessions are signed with a server-side secret. All data access is authorised on the server and validated against the database, and database row-level security policies are provided for the production Postgres deployment.',
      'If we ever suffer a breach affecting your personal data, we will notify you and the Nigeria Data Protection Commission without undue delay.',
    ],
  ],
  [
    'Your rights',
    [
      'Under the Nigeria Data Protection Act 2023 you can request access to your data, correction of inaccurate data, deletion of data we no longer need, and a copy of your data in a portable format.',
      'Write to privacy@obahtech.ng and we will respond within 30 days. You may also complain to the Nigeria Data Protection Commission.',
    ],
  ],
];

export default function PrivacyPage() {
  return (
    <div className="container-obah py-8">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-2xl font-extrabold text-ink-900">Privacy policy</h1>
        <p className="mt-1 text-sm text-ink-500">Last updated 30 October 2026. Aligned with the Nigeria Data Protection Act 2023.</p>
        <div className="mt-6 space-y-6 rounded-xl border border-gray-200 bg-white p-6 shadow-card">
          {SECTIONS.map(([title, paras]) => (
            <section key={title}>
              <h2 className="text-sm font-extrabold uppercase tracking-wide text-ink-800">{title}</h2>
              {paras.map((p) => (
                <p key={p.slice(0, 24)} className="mt-2 text-sm leading-relaxed text-ink-600">
                  {p}
                </p>
              ))}
            </section>
          ))}
          <div className="rounded-lg bg-obah-50 p-4 text-sm text-ink-700">
            <p className="font-bold">Data requests</p>
            <p className="mt-1 text-[13px]">
              Email <a href="mailto:privacy@obahtech.ng" className="font-semibold text-obah-700 underline">privacy@obahtech.ng</a>. See also our{' '}
              <Link href="/terms" className="font-semibold text-obah-700 underline">terms of service</Link>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
