import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Page not found' };

export default function NotFound() {
  return (
    <div className="container-obah py-16">
      <div className="mx-auto max-w-lg rounded-xl border border-gray-200 bg-white p-8 text-center shadow-card">
        <p className="text-5xl font-black tracking-tight text-obah-500">404</p>
        <h1 className="mt-2 text-xl font-extrabold text-ink-900">We couldn&apos;t find that page</h1>
        <p className="mt-2 text-sm text-ink-500">
          The link may be broken, or the product might have sold out and been removed from the catalogue.
        </p>
        <form action="/search" className="mt-5 flex overflow-hidden rounded-lg border border-gray-300">
          <input
            name="q"
            placeholder="Search phones, tablets, accessories…"
            className="w-full px-3 py-2.5 text-sm outline-none"
            aria-label="Search products"
          />
          <button className="bg-obah-500 px-5 text-xs font-bold uppercase tracking-wide text-white hover:bg-obah-600">
            Search
          </button>
        </form>
        <div className="mt-5 flex flex-wrap justify-center gap-2 text-xs font-semibold">
          <Link href="/" className="rounded-lg bg-obah-50 px-3 py-2 text-obah-700 hover:bg-obah-100">Home</Link>
          <Link href="/category/all" className="rounded-lg bg-gray-100 px-3 py-2 text-ink-700 hover:bg-gray-200">All products</Link>
          <Link href="/track" className="rounded-lg bg-gray-100 px-3 py-2 text-ink-700 hover:bg-gray-200">Track an order</Link>
          <Link href="/support" className="rounded-lg bg-gray-100 px-3 py-2 text-ink-700 hover:bg-gray-200">Get help</Link>
        </div>
      </div>
    </div>
  );
}
