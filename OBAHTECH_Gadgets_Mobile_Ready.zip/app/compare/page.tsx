import Link from 'next/link';
import { cookies } from 'next/headers';
import { getDb } from '@/lib/db';
import { Empty } from '@/components/ui';
import { NGN } from '@/lib/format';
import { addToCartAction } from '@/lib/actions/cart';
import { clearCompare } from '@/lib/actions/compare';

export const dynamic = 'force-dynamic';

const ROWS: [string, (p: any) => string][] = [
  ['Price', (p) => NGN(p.is_flash_sale && p.flash_price ? p.flash_price : p.price)],
  ['Brand', (p) => p.brand],
  ['Model', (p) => p.model || '—'],
  ['RAM', (p) => p.ram || '—'],
  ['Storage', (p) => JSON.parse(p.storage_options || '[]').join(', ') || '—'],
  ['Battery', (p) => p.battery || '—'],
  ['Screen', (p) => p.screen_size || '—'],
  ['Network', (p) => p.network || '—'],
  ['Condition', (p) => p.condition],
  ['Warranty', (p) => `${p.warranty_months} months`],
  ['Rating', (p) => `${p.rating_avg} / 5 (${p.rating_count})`],
  ['Availability', (p) => (p.stock - p.reserved > 0 ? `${p.stock - p.reserved} in stock` : 'Out of stock')],
];

export default async function ComparePage() {
  const ids = (cookies().get('obah_compare')?.value || '')
    .split(',')
    .map((x) => Number(x))
    .filter(Boolean);
  const db = getDb();
  const products = ids.length
    ? (await db
        .prepare(
          `SELECT p.*, (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
             FROM products p WHERE p.id IN (${ids.map(() => '?').join(',')})`,
        )
        .all(...ids) as any[])
    : [];
  const ordered = ids.map((id) => products.find((p) => p.id === id)).filter(Boolean) as any[];

  return (
    <div className="container-obah py-4">
      <div className="mb-3 flex items-center justify-between">
        <h1 className="text-lg font-extrabold text-ink-800">Compare products</h1>
        {ordered.length > 0 && (
          <form action={clearCompare}>
            <button className="btn-outline btn-sm">Clear comparison</button>
          </form>
        )}
      </div>
      {ordered.length === 0 ? (
        <Empty
          title="Nothing to compare yet"
          hint="Open any product and tap “Compare” to place up to 4 products side by side."
          action={<Link href="/category/all" className="btn-primary mt-2">Browse products</Link>}
        />
      ) : (
        <div className="card overflow-x-auto p-3">
          <table className="w-full min-w-[640px] text-xs">
            <thead>
              <tr>
                <th className="w-32" />
                {ordered.map((p) => (
                  <th key={p.id} className="p-2 text-left align-top">
                    <img src={p.image} alt="" className="h-20 w-20 object-contain" />
                    <Link href={`/product/${p.slug}`} className="mt-1 block text-xs font-bold text-ink-800 hover:text-obah-600">{p.name}</Link>
                    <form action={addToCartAction} className="mt-1">
                      <input type="hidden" name="product_id" value={p.id} />
                      <input type="hidden" name="qty" value={1} />
                      <button className="btn-primary btn-sm" disabled={p.stock - p.reserved <= 0}>Add to cart</button>
                    </form>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ROWS.map(([label, fn]) => (
                <tr key={label} className="border-t border-gray-100">
                  <td className="py-2 pr-3 font-bold uppercase tracking-wide text-ink-400">{label}</td>
                  {ordered.map((p) => (
                    <td key={p.id} className="p-2 text-ink-700">{fn(p)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
