import Link from 'next/link';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { fmtDateTime, REASONS_RETURN } from '@/lib/format';
import { createTicket, replyTicket } from '@/lib/actions/customer';

export const metadata = { title: 'Help & support' };
export const dynamic = 'force-dynamic';

const FAQ = [
  ['How long does delivery take?', 'Lagos, Abuja, Rivers, Ogun, Oyo, Kano, Anambra and Delta typically receive standard delivery in 1–2 working days. Other states take 3–5 working days. Express options and the exact fee are shown at checkout based on your LGA.'],
  ['Which payment methods are supported?', 'Flutterwave processes cards (Visa, Mastercard, Verve), bank transfer and USSD in Nigerian Naira. Your order is marked paid only after OBAHTECH verifies the transaction on our server.'],
  ['Can I pay on delivery?', 'Pay on delivery is available in selected Lagos LGAs and for eligible orders. Otherwise payment is completed online before dispatch.'],
  ['What is the return window?', '7 days from delivery for damaged, defective, missing, wrong or misdescribed items. Returns must be approved by an administrator — refunds are never automatic.'],
  ['What does the warranty cover?', 'Manufacturing defects for the stated duration (7-day replacement, 30-day seller warranty, 3, 6 or 12 months depending on the product). Physical damage, liquid damage and unauthorised repairs are excluded.'],
  ['Who handles my delivery?', 'Every order is automatically routed to the OBAHTECH administrator for your delivery state. The super admin oversees all states from the national office.'],
  ['How do I track my order?', 'Open “My orders”, or use the tracking page with your order number and the email used at checkout.'],
  ['Can I change my delivery address after ordering?', 'The delivery state and LGA saved with an order never change. Contact support to request a modification; the state team will review it.'],
];

export default async function SupportPage({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  const db = getDb();
  const tickets = user
    ? (await db.prepare('SELECT * FROM support_tickets WHERE user_id = ? OR email = ? ORDER BY id DESC LIMIT 10').all(user.id, user.email) as any[])
    : [];
  const ticketRows = await Promise.all(
    tickets.map(async (t: any) => ({
      t,
      msgs: (await db.prepare('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY id').all(t.id)) as any[],
    })),
  );
  const orders = user ? (await db.prepare('SELECT order_number FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 10').all(user.id) as any[]) : [];

  return (
    <div className="container-obah py-6">
      <div className="rounded-2xl bg-gradient-to-r from-ink-800 to-slate-700 p-6 text-white">
        <h1 className="text-2xl font-extrabold">How can we help?</h1>
        <p className="mt-1 text-sm text-white/80">Real humans, Monday–Saturday 8am–8pm WAT. Average first reply under 2 hours.</p>
        <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
          <span className="rounded-full bg-white/15 px-3 py-1">📞 0800 OBAH TECH</span>
          <span className="rounded-full bg-white/15 px-3 py-1">✉️ support@obahtech.ng</span>
          <span className="rounded-full bg-white/15 px-3 py-1">💬 WhatsApp +234 800 000 0000</span>
        </div>
      </div>

      {searchParams.sent && (
        <div className="mt-4"><Alert tone="success">Ticket {searchParams.sent} created. The state administrator and super admin have been notified.</Alert></div>
      )}
      {searchParams.error && <div className="mt-4"><Alert>{searchParams.error}</Alert></div>}

      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          <section className="card p-4" id="faq">
            <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-800">Frequently asked questions</h2>
            <div className="divide-y divide-gray-100">
              {FAQ.map(([q, a]) => (
                <details key={q} className="group py-2">
                  <summary className="cursor-pointer list-none text-xs font-bold text-ink-800 marker:hidden">
                    <span className="mr-1 text-obah-500 group-open:hidden">+</span>
                    <span className="mr-1 hidden text-obah-500 group-open:inline">−</span>
                    {q}
                  </summary>
                  <p className="mt-1 pl-4 text-[11px] leading-relaxed text-ink-500">{a}</p>
                </details>
              ))}
            </div>
          </section>

          <section className="card p-4" id="returns">
            <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-800">Returns & refunds</h2>
            <p className="text-[11px] leading-relaxed text-ink-500">
              Request a return from the order page within 7 days of delivery. Eligible reasons:
            </p>
            <ul className="mt-1 grid gap-1 text-[11px] text-ink-500 sm:grid-cols-2">
              {REASONS_RETURN.map((r) => (
                <li key={r}>• {r}</li>
              ))}
            </ul>
            <p className="mt-2 text-[11px] leading-relaxed text-ink-500">
              Our state team reviews each request. If approved, we arrange pickup, inspect the item, and process a refund to your
              original payment method. Refunds are never issued automatically, and the return window is separate from the warranty.
            </p>
          </section>

          <section className="card p-4" id="warranty">
            <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-800">Warranty policy</h2>
            <div className="overflow-x-auto">
              <table className="table-obah">
                <thead>
                  <tr><th>Product type</th><th>Coverage</th><th>Starts</th></tr>
                </thead>
                <tbody>
                  <tr><td>Accessories (cases, glass)</td><td>7-day replacement</td><td>Delivery</td></tr>
                  <tr><td>Chargers, cables</td><td>30-day seller warranty</td><td>Delivery</td></tr>
                  <tr><td>Power banks, audio</td><td>6–12 months</td><td>Delivery</td></tr>
                  <tr><td>Smartphones & tablets</td><td>12 months</td><td>Delivery</td></tr>
                </tbody>
              </table>
            </div>
            <p className="mt-2 text-[11px] text-ink-500">Warranty periods are configurable per product by the super admin and are printed on every warranty record.</p>
          </section>

          {tickets.length > 0 && (
            <section className="card p-4">
              <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-800">My support tickets</h2>
              {ticketRows.map(({ t, msgs }) => (
                  <div key={t.id} className="mb-2 rounded-lg border border-gray-200 p-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-1">
                      <p className="text-xs font-bold text-ink-800">{t.reference} · {t.subject}</p>
                      <span className="chip bg-gray-100 text-ink-600 ring-gray-200">{t.status.replace(/_/g, ' ')}</span>
                    </div>
                    <p className="mt-0.5 text-[11px] text-ink-500">{t.message}</p>
                    <p className="text-[10px] text-ink-300">{t.category} · {fmtDateTime(t.created_at)}</p>
                    {msgs.map((m) => (
                      <p key={m.id} className={`mt-1 rounded p-1.5 text-[11px] ${m.author_role === 'customer' ? 'bg-gray-50 text-ink-600' : 'bg-obah-50 text-ink-700'}`}>
                        <span className="font-bold">{m.author_role === 'customer' ? 'You' : 'OBAHTECH support'}:</span> {m.body}
                      </p>
                    ))}
                    <details className="mt-1">
                      <summary className="cursor-pointer text-[10px] font-bold text-obah-600">Add a reply</summary>
                      <form action={replyTicket} className="mt-1 flex gap-1">
                        <input type="hidden" name="ticket_id" value={t.id} />
                        <input name="body" required className="input px-2 py-1 text-xs" placeholder="Type your message" />
                        <button className="btn-dark btn-sm">Send</button>
                      </form>
                    </details>
                  </div>
              ))}
            </section>
          )}
        </div>

        <div className="space-y-3" id="contact">
          <section className="card p-4">
            <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-800">Contact customer support</h2>
            <form action={createTicket} className="space-y-2">
              <div>
                <label className="label">Your name</label>
                <input name="name" defaultValue={user?.full_name || ''} required className="input" />
              </div>
              <div>
                <label className="label">Email</label>
                <input name="email" type="email" defaultValue={user?.email || ''} required className="input" />
              </div>
              <div>
                <label className="label">Phone</label>
                <input name="phone" defaultValue={user?.phone || ''} className="input" />
              </div>
              <div>
                <label className="label">Related order (optional)</label>
                <select name="order_number" className="input">
                  <option value="">Not order-related</option>
                  {orders.map((o) => (
                    <option key={o.order_number} value={o.order_number}>{o.order_number}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Category</label>
                <select name="category" className="input" defaultValue="order">
                  <option value="order">Order issue</option>
                  <option value="delivery">Delivery complaint</option>
                  <option value="warranty">Warranty support</option>
                  <option value="return">Return support</option>
                  <option value="product">Product question</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="label">Subject</label>
                <input name="subject" required className="input" />
              </div>
              <div>
                <label className="label">Message</label>
                <textarea name="message" rows={4} required className="input" />
              </div>
              <button className="btn-primary w-full">Submit ticket</button>
              {!user && <p className="text-[10px] text-ink-400">Tip: sign in first so the ticket is linked to your account and order history.</p>}
            </form>
          </section>
          <section className="card p-4">
            <h2 className="mb-1 text-xs font-bold uppercase tracking-wide text-ink-800">Other ways to reach us</h2>
            <ul className="space-y-1 text-[11px] text-ink-500">
              <li>📞 Phone: 0800 OBAH TECH (Mon–Sat, 8am–8pm)</li>
              <li>✉️ Email: support@obahtech.ng</li>
              <li>💬 WhatsApp: +234 800 000 0000</li>
              <li>🏢 Head office: Ikeja, Lagos State</li>
            </ul>
            <Link href="/track" className="mt-2 inline-block text-[11px] font-bold text-obah-600">Track an order →</Link>
          </section>
        </div>
      </div>
    </div>
  );
}
