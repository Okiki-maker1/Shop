import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { Alert, StatusBadge, PayBadge } from '@/components/ui';
import { NGN, fmtDateTime, fmtDate, STATUS_LABEL, TRACKING_STAGES, REASONS_RETURN } from '@/lib/format';
import { requestCancellation, requestReturn } from '@/lib/actions/customer';

export const dynamic = 'force-dynamic';

export default async function OrderDetailPage({ params, searchParams }: { params: { number: string }; searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=/orders/${params.number}`);
  const db = getDb();
  const order = await db
    .prepare(
      `SELECT o.*, s.name AS state_name, l.name AS lga_name, u.full_name AS admin_name
         FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id
         LEFT JOIN users u ON u.id = o.assigned_admin_id
        WHERE o.order_number = ?`,
    )
    .get(params.number) as any;
  if (!order) notFound();
  if (user.role === 'customer' && order.user_id !== user.id) notFound();

  const items = await db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id) as any[];
  const events = await db.prepare('SELECT * FROM order_events WHERE order_id = ? ORDER BY id').all(order.id) as any[];
  const delivery = await db.prepare('SELECT * FROM deliveries WHERE order_id = ?').get(order.id) as any;
  const payments = await db.prepare('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC').all(order.id) as any[];
  const returns = await db.prepare('SELECT * FROM return_requests WHERE order_id = ? ORDER BY id DESC').all(order.id) as any[];
  const warranties = await db.prepare('SELECT * FROM warranties WHERE order_id = ?').all(order.id) as any[];
  const claims = await db.prepare('SELECT * FROM warranty_claims WHERE order_id = ?').all(order.id) as any[];
  const cancellable = ['pending_payment', 'payment_confirmed', 'order_confirmed', 'processing'].includes(order.status);
  const deliveredAt = delivery?.delivered_at;
  const withinReturn = deliveredAt ? (Date.now() - new Date(deliveredAt.replace(' ', 'T') + 'Z').getTime()) / 864e5 <= 7 : false;
  const stageIdx = TRACKING_STAGES.indexOf(order.status);

  return (
    <div className="container-obah py-4">
      {searchParams.paid && (
        <div className="mb-3"><Alert tone="success">Payment confirmed{searchParams.sandbox ? ' (sandbox)' : ''}. Your order is now with the {order.state_name} team.</Alert></div>
      )}
      {searchParams.payment === 'failed' && <div className="mb-3"><Alert>That payment did not go through. You can retry below.</Alert></div>}
      {searchParams.payment && searchParams.payment !== 'failed' && (
        <div className="mb-3"><Alert tone="warn">Payment status: {searchParams.payment.replace(/_/g, ' ')}. If you were charged, contact support with your order number.</Alert></div>
      )}
      {searchParams.requested && <div className="mb-3"><Alert tone="warn">Cancellation request submitted. Our team will review it shortly.</Alert></div>}
      {searchParams.return && <div className="mb-3"><Alert tone="warn">Return request submitted. Our team will review it within 24 hours.</Alert></div>}
      {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}

      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <Link href="/orders" className="text-[11px] font-semibold text-obah-600">← All orders</Link>
          <h1 className="text-lg font-extrabold text-ink-800">Order {order.order_number}</h1>
          <p className="text-[11px] text-ink-400">Placed {fmtDateTime(order.created_at)}</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <StatusBadge status={order.status} />
          <PayBadge status={order.payment_status} />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="space-y-3">
          {/* Tracking */}
          <section className="card p-4">
            <h2 className="mb-3 text-xs font-bold uppercase tracking-wide text-ink-800">Delivery tracking</h2>
            <ol className="flex flex-wrap gap-1.5">
              {TRACKING_STAGES.map((s, i) => {
                const done = stageIdx >= i && stageIdx >= 0;
                const special = ['return_requested', 'cancelled', 'refund_pending', 'refunded', 'returned'].includes(order.status);
                return (
                  <li key={s} className={`flex-1 rounded-lg px-2 py-1.5 text-center text-[10px] font-bold ${done && !special ? 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200' : 'bg-gray-50 text-ink-400 ring-1 ring-gray-100'}`}>
                    {STATUS_LABEL[s]}
                  </li>
                );
              })}
            </ol>
            {['cancellation_requested', 'cancelled', 'return_requested', 'returned', 'refund_pending', 'refunded'].includes(order.status) && (
              <p className="mt-2 rounded bg-amber-50 px-2 py-1.5 text-[11px] font-semibold text-amber-800 ring-1 ring-amber-200">
                Current special status: {STATUS_LABEL[order.status]}
              </p>
            )}
            <div className="mt-3 grid gap-2 text-[11px] sm:grid-cols-2">
              <p><span className="text-ink-400">Tracking ref:</span> <span className="font-semibold">{delivery?.tracking_ref || order.tracking_ref}</span></p>
              <p><span className="text-ink-400">Courier:</span> <span className="font-semibold">{delivery?.courier || 'OBAHTECH Logistics'}</span></p>
              <p><span className="text-ink-400">Estimated delivery:</span> <span className="font-semibold">{fmtDate(delivery?.eta_date)}</span></p>
              <p><span className="text-ink-400">Shipped:</span> <span className="font-semibold">{fmtDate(delivery?.shipped_at)}</span></p>
              <p><span className="text-ink-400">Delivered:</span> <span className="font-semibold">{fmtDate(delivery?.delivered_at)}</span></p>
              <p><span className="text-ink-400">State team:</span> <span className="font-semibold">{order.admin_name || 'Unassigned — super admin handling'}</span></p>
            </div>
          </section>

          {/* Items */}
          <section className="card p-4">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Items</h2>
            <div className="space-y-2">
              {items.map((it) => (
                <div key={it.id} className="flex gap-3 rounded-lg border border-gray-100 p-2">
                  <img src={it.image || ''} alt="" className="h-14 w-14 rounded bg-[#f7f8fa] object-contain" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-ink-800">{it.name}</p>
                    <p className="text-[11px] text-ink-400">
                      {[it.brand, it.model, it.color, it.storage].filter(Boolean).join(' · ')} · Qty {it.qty}
                    </p>
                    {it.serial_no && <p className="text-[10px] text-ink-400">IMEI/Serial: {it.serial_no}</p>}
                  </div>
                  <p className="text-xs font-bold">{NGN(it.line_total)}</p>
                </div>
              ))}
            </div>
            <dl className="mt-3 space-y-1 border-t border-gray-100 pt-2 text-xs">
              <div className="flex justify-between"><dt className="text-ink-500">Subtotal</dt><dd>{NGN(order.subtotal)}</dd></div>
              {order.discount > 0 && <div className="flex justify-between text-emerald-600"><dt>Discount {order.promo_code}</dt><dd>−{NGN(order.discount)}</dd></div>}
              <div className="flex justify-between"><dt className="text-ink-500">Delivery</dt><dd>{order.delivery_fee === 0 ? 'Free' : NGN(order.delivery_fee)}</dd></div>
              <div className="flex justify-between text-sm font-extrabold"><dt>Total</dt><dd className="text-obah-600">{NGN(order.total)}</dd></div>
            </dl>
          </section>

          {/* Timeline */}
          <section className="card p-4">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Order timeline</h2>
            <ol className="space-y-2">
              {events.map((e) => (
                <li key={e.id} className="flex gap-2">
                  <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-obah-500" />
                  <div>
                    <p className="text-xs font-semibold text-ink-800">{STATUS_LABEL[e.status] || e.status}</p>
                    {e.note && <p className="text-[11px] text-ink-500">{e.note}</p>}
                    <p className="text-[10px] text-ink-300">{fmtDateTime(e.created_at)} · {e.actor_role}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>

          {/* Returns / warranty */}
          {(returns.length > 0 || warranties.length > 0) && (
            <section className="card p-4">
              <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Returns & warranty</h2>
              {returns.map((r) => (
                <div key={r.id} className="mb-2 rounded-lg bg-amber-50 p-2 text-[11px] text-amber-900 ring-1 ring-amber-200">
                  <p className="font-bold">Return #{r.id} — {r.status.replace(/_/g, ' ')}</p>
                  <p>Reason: {r.reason}</p>
                  {r.admin_note && <p>OBAHTECH: {r.admin_note}</p>}
                </div>
              ))}
              {warranties.map((w) => (
                <div key={w.id} className="mb-2 rounded-lg bg-emerald-50 p-2 text-[11px] text-emerald-900 ring-1 ring-emerald-200">
                  <p className="font-bold">{w.product_name} — {w.duration_months}-month warranty</p>
                  <p>Valid {fmtDate(w.start_date)} → {fmtDate(w.expiry_date)} · {w.status}</p>
                  {w.serial_no && <p>Serial: {w.serial_no}</p>}
                </div>
              ))}
              {claims.map((c) => (
                <div key={c.id} className="mb-2 rounded-lg bg-sky-50 p-2 text-[11px] text-sky-900 ring-1 ring-sky-200">
                  <p className="font-bold">Claim #{c.id} — {c.status.replace(/_/g, ' ')}</p>
                  <p>{c.issue}</p>
                  {c.admin_note && <p>OBAHTECH: {c.admin_note}</p>}
                </div>
              ))}
              <Link href="/account#warranties" className="text-[11px] font-bold text-obah-600">Manage warranties →</Link>
            </section>
          )}
        </div>

        {/* Sidebar actions */}
        <div className="space-y-3">
          <section className="card p-4">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Delivery address</h2>
            <p className="text-xs font-semibold text-ink-800">{order.customer_name}</p>
            <p className="text-[11px] text-ink-500">{order.address_text}</p>
            <p className="text-[11px] text-ink-500">{order.lga_name}, {order.state_name}</p>
            <p className="mt-1 text-[11px] text-ink-400">{order.phone} · {order.email}</p>
            {order.instructions && <p className="mt-1 rounded bg-gray-50 p-1.5 text-[10px] text-ink-500">Instruction: {order.instructions}</p>}
            <p className="mt-2 text-[10px] text-ink-300">The delivery state and LGA are locked to this order.</p>
          </section>

          <section className="card p-4">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Payment</h2>
            {payments.length === 0 && <p className="text-[11px] text-ink-400">No payment attempts yet.</p>}
            {payments.map((p) => (
              <div key={p.id} className="mb-2 rounded-lg bg-gray-50 p-2 text-[11px]">
                <p className="font-bold text-ink-800">{NGN(p.amount)} · {p.status}</p>
                <p className="text-ink-500">{p.gateway}{p.sandbox ? ' (sandbox)' : ''} · {p.method || 'card'}</p>
                <p className="break-all text-ink-400">Ref {p.tx_ref}</p>
                <p className="text-ink-400">{fmtDateTime(p.verified_at || p.created_at)}</p>
              </div>
            ))}
            {order.payment_status !== 'paid' && (
              <Link href={`/payments/${order.order_number}`} className="btn-primary mt-1 w-full">Pay {NGN(order.total)}</Link>
            )}
          </section>

          <section className="card p-4" id="help">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Need help?</h2>
            <div className="space-y-2">
              {cancellable && (
                <details>
                  <summary className="cursor-pointer text-[11px] font-bold text-rose-600">Request cancellation</summary>
                  <form action={requestCancellation} className="mt-2 space-y-2">
                    <input type="hidden" name="order_id" value={order.id} />
                    <textarea name="reason" rows={2} required placeholder="Why do you want to cancel?" className="input text-xs" />
                    <button className="btn-outline btn-sm w-full">Submit cancellation request</button>
                  </form>
                </details>
              )}
              {order.status === 'delivered' && withinReturn && (
                <details>
                  <summary className="cursor-pointer text-[11px] font-bold text-obah-600">Request a return (7-day window)</summary>
                  <form action={requestReturn} className="mt-2 space-y-2">
                    <input type="hidden" name="order_id" value={order.id} />
                    <select name="order_item_id" className="input text-xs">
                      {items.map((it) => (
                        <option key={it.id} value={it.id}>{it.name}</option>
                      ))}
                    </select>
                    <select name="reason" required className="input text-xs">
                      <option value="">Select a reason…</option>
                      {REASONS_RETURN.map((r) => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                    <textarea name="explanation" rows={2} placeholder="Explain the issue" className="input text-xs" />
                    <input name="photos" placeholder="Link to photos (optional)" className="input text-xs" />
                    <button className="btn-outline btn-sm w-full">Submit return request</button>
                  </form>
                </details>
              )}
              {order.status === 'delivered' && !withinReturn && (
                <p className="text-[11px] text-ink-400">The 7-day return window has closed. You can still request warranty service.</p>
              )}
              <Link href="/support#contact" className="btn-outline btn-sm w-full">Contact support</Link>
              <Link href="/account#warranties" className="btn-outline btn-sm w-full">Warranty & claims</Link>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
