import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { StatusBadge, PayBadge, Alert, Empty } from '@/components/ui';
import { NGN, fmtDate } from '@/lib/format';

export const metadata = { title: 'My orders' };
export const dynamic = 'force-dynamic';

export default async function OrdersPage({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/orders');
  const db = getDb();
  const orders = await db
    .prepare(
      `SELECT o.*, s.name AS state_name, l.name AS lga_name,
              (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS item_count,
              (SELECT image FROM order_items WHERE order_id = o.id LIMIT 1) AS image
         FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id
        WHERE o.user_id = ? ORDER BY o.id DESC`,
    )
    .all(user.id) as any[];

  return (
    <div className="container-obah py-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-lg font-extrabold text-ink-800">My orders</h1>
        <div className="flex gap-2">
          <Link href="/track" className="btn-outline btn-sm">Track an order</Link>
          <Link href="/account#warranties" className="btn-outline btn-sm">My warranties</Link>
        </div>
      </div>
      {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}

      {orders.length === 0 ? (
        <Empty title="You have no orders yet" hint="When you place an order it will appear here with live tracking." action={<Link href="/category/all" className="btn-primary mt-2">Start shopping</Link>} />
      ) : (
        <div className="space-y-2">
          {orders.map((o) => (
            <div key={o.id} className="card p-3">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-2">
                <div>
                  <p className="text-sm font-extrabold text-ink-800">{o.order_number}</p>
                  <p className="text-[11px] text-ink-400">Placed {fmtDate(o.created_at)} · {o.item_count} item(s) · Deliver to {o.lga_name}, {o.state_name}</p>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <StatusBadge status={o.status} />
                  <PayBadge status={o.payment_status} />
                </div>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                <div className="flex items-center gap-2">
                  {o.image && <img src={o.image} alt="" className="h-10 w-10 rounded bg-[#f7f8fa] object-contain" />}
                  <div>
                    <p className="text-[11px] text-ink-500">Total paid / due</p>
                    <p className="text-sm font-extrabold text-ink-800">{NGN(o.total)}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Link href={`/orders/${o.order_number}`} className="btn-outline btn-sm">View details</Link>
                  {o.payment_status !== 'paid' && o.status === 'pending_payment' && (
                    <Link href={`/payments/${o.order_number}`} className="btn-primary btn-sm">Pay now</Link>
                  )}
                  <Link href={`/orders/${o.order_number}#help`} className="btn-outline btn-sm">Get help</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
