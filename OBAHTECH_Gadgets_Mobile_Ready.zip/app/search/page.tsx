import Link from 'next/link';
import { listProducts, wishlistIds, facets } from '@/lib/queries';
import { getSessionUser } from '@/lib/auth';
import { ProductCard } from '@/components/ProductCard';
import { Empty } from '@/components/ui';

export const dynamic = 'force-dynamic';

export default async function SearchPage({ searchParams }: { searchParams: Record<string, string> }) {
  const q = (searchParams.q || '').trim();
  const res = await listProducts({ q, sort: searchParams.sort, page: Number(searchParams.page || 1), perPage: 24, brand: searchParams.brand });
  const user = await getSessionUser();
  const wished = await wishlistIds(user?.id);
  const fx = await facets();

  return (
    <div className="container-obah py-4">
      <div className="card mb-3 p-4">
        <h1 className="text-lg font-extrabold text-ink-800">
          {q ? <>Results for “{q}”</> : 'Search OBAHTECH Gadgets'}
        </h1>
        <p className="text-[11px] text-ink-400">{res.total} product{res.total === 1 ? '' : 's'} found</p>
        <form action="/search" className="mt-2 flex overflow-hidden rounded-lg border border-gray-300">
          <input name="q" defaultValue={q} placeholder="Search phones, tablets, accessories…" className="w-full px-3 py-2 text-sm outline-none" />
          <button className="bg-obah-500 px-4 text-xs font-bold uppercase text-white">Search</button>
        </form>
        <div className="mt-2 flex flex-wrap gap-1">
          {fx.brands.slice(0, 8).map((b) => (
            <Link key={b.brand} href={`/search?q=${encodeURIComponent(b.brand)}`} className="rounded-full bg-gray-100 px-2 py-1 text-[11px] font-semibold text-ink-600 hover:bg-obah-50 hover:text-obah-600">
              {b.brand}
            </Link>
          ))}
        </div>
      </div>

      {res.items.length === 0 ? (
        <Empty
          title="No products found"
          hint="Check your spelling, or browse a category instead."
          action={<Link href="/category/all" className="btn-primary mt-2">Browse all products</Link>}
        />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {res.items.map((p) => (
            <ProductCard key={p.id} p={p as any} wished={wished.has(p.id)} />
          ))}
        </div>
      )}
    </div>
  );
}
