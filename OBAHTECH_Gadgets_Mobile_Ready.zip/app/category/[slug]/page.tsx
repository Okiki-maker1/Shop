import Link from 'next/link';
import { notFound } from 'next/navigation';
import { categories, facets, listProducts, wishlistIds } from '@/lib/queries';
import { getSessionUser } from '@/lib/auth';
import { ProductCard } from '@/components/ProductCard';
import { Empty } from '@/components/ui';
import { NGN } from '@/lib/format';

export const dynamic = 'force-dynamic';

const SORTS = [
  ['popular', 'Most popular'],
  ['newest', 'Newest first'],
  ['price-asc', 'Price: low to high'],
  ['price-desc', 'Price: high to low'],
  ['rating', 'Highest rated'],
  ['discount', 'Biggest discount'],
];

export default async function CategoryPage({ params, searchParams }: { params: { slug: string }; searchParams: Record<string, string> }) {
  const cats = await categories();
  const cat = params.slug === 'all' ? null : cats.find((c) => c.slug === params.slug);
  if (params.slug !== 'all' && !cat) notFound();

  const page = Number(searchParams.page || 1);
  const f = {
    category: params.slug,
    q: searchParams.q,
    brand: searchParams.brand,
    ram: searchParams.ram,
    storage: searchParams.storage,
    condition: searchParams.condition,
    minPrice: searchParams.min ? Number(searchParams.min) : undefined,
    maxPrice: searchParams.max ? Number(searchParams.max) : undefined,
    sort: searchParams.sort,
    page,
    perPage: 24,
    flash: searchParams.flash === '1',
    featured: searchParams.featured === '1',
    inStock: searchParams.stock === '1',
  };
  const res = await listProducts(f);
  const fx = await facets(params.slug);
  const user = await getSessionUser();
  const wished = await wishlistIds(user?.id);

  const qs = (patch: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...searchParams, ...patch })) if (v) p.set(k, String(v));
    return `?${p.toString()}`;
  };

  return (
    <div className="container-obah py-4">
      <nav className="mb-3 flex flex-wrap items-center gap-1 text-[11px] text-ink-400">
        <Link href="/" className="hover:text-obah-600">Home</Link>
        <span>/</span>
        <Link href="/category/all" className="hover:text-obah-600">All categories</Link>
        {cat && (
          <>
            <span>/</span>
            <span className="font-semibold text-ink-700">{cat.name}</span>
          </>
        )}
      </nav>

      <div className="grid gap-4 lg:grid-cols-[240px_1fr]">
        {/* FILTERS */}
        <aside className="space-y-3">
          <form method="GET" className="card p-3">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Filter</p>
            <div className="space-y-3">
              <div>
                <label className="label">Brand</label>
                <select name="brand" defaultValue={searchParams.brand || ''} className="input">
                  <option value="">All brands</option>
                  {fx.brands.map((b) => (
                    <option key={b.brand} value={b.brand}>{b.brand} ({b.c})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">RAM</label>
                <select name="ram" defaultValue={searchParams.ram || ''} className="input">
                  <option value="">Any RAM</option>
                  {fx.rams.map((r) => (
                    <option key={r.ram} value={r.ram}>{r.ram}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Storage</label>
                <select name="storage" defaultValue={searchParams.storage || ''} className="input">
                  <option value="">Any storage</option>
                  {fx.storages.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Condition</label>
                <select name="condition" defaultValue={searchParams.condition || ''} className="input">
                  <option value="">Any condition</option>
                  {fx.conditions.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Price range (₦)</label>
                <div className="flex items-center gap-1.5">
                  <input name="min" type="number" min="0" placeholder="Min" defaultValue={searchParams.min} className="input px-2 py-1.5 text-xs" />
                  <span className="text-ink-300">–</span>
                  <input name="max" type="number" min="0" placeholder="Max" defaultValue={searchParams.max} className="input px-2 py-1.5 text-xs" />
                </div>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {[100000, 300000, 700000, 1500000].map((v) => (
                    <Link key={v} href={`${params.slug ? `/category/${params.slug}` : '/category/all'}${qs({ max: String(v) })}`} className="rounded bg-gray-100 px-1.5 py-0.5 text-[10px] font-semibold text-ink-500 hover:bg-obah-50 hover:text-obah-600">
                      under {NGN(v)}
                    </Link>
                  ))}
                </div>
              </div>
              <label className="flex items-center gap-2 text-xs font-semibold text-ink-600">
                <input type="checkbox" name="stock" value="1" defaultChecked={searchParams.stock === '1'} className="h-4 w-4 rounded border-gray-300" />
                In stock only
              </label>
              <input type="hidden" name="sort" value={searchParams.sort || 'popular'} />
              <button className="btn-primary w-full">Apply filters</button>
              <Link href={params.slug === 'all' ? '/category/all' : `/category/${params.slug}`} className="block text-center text-[11px] font-semibold text-ink-400 hover:text-obah-600">
                Clear all
              </Link>
            </div>
          </form>

          <div className="card p-3">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Categories</p>
            <ul className="space-y-0.5 text-xs">
              <li>
                <Link href="/category/all" className={`block rounded px-2 py-1.5 ${params.slug === 'all' ? 'bg-obah-50 font-bold text-obah-700' : 'text-ink-600 hover:bg-gray-50'}`}>
                  All products
                </Link>
              </li>
              {cats.map((c) => (
                <li key={c.slug}>
                  <Link href={`/category/${c.slug}`} className={`block rounded px-2 py-1.5 ${params.slug === c.slug ? 'bg-obah-50 font-bold text-obah-700' : 'text-ink-600 hover:bg-gray-50'}`}>
                    {c.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* RESULTS */}
        <div>
          <div className="card mb-3 flex flex-wrap items-center justify-between gap-2 p-3">
            <div>
              <h1 className="text-lg font-extrabold text-ink-800">
                {searchParams.flash === '1' ? 'Flash sales' : searchParams.featured === '1' ? 'Featured products' : cat ? cat.name : 'All products'}
              </h1>
              <p className="text-[11px] text-ink-400">{res.total} product{res.total === 1 ? '' : 's'} available</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="hidden text-[11px] font-semibold uppercase text-ink-400 sm:inline">Sort by</span>
              <div className="flex flex-wrap gap-1">
                {SORTS.slice(0, 3).map(([v, l]) => (
                  <Link
                    key={v}
                    href={`/category/${params.slug}${qs({ sort: v, page: undefined })}`}
                    className={`rounded border px-2 py-1 text-[11px] font-semibold ${(searchParams.sort || 'popular') === v ? 'border-obah-500 bg-obah-50 text-obah-700' : 'border-gray-200 text-ink-500 hover:border-obah-300'}`}
                  >
                    {l}
                  </Link>
                ))}
                <details className="relative">
                  <summary className="cursor-pointer list-none rounded border border-gray-200 px-2 py-1 text-[11px] font-semibold text-ink-600">More ▾</summary>
                  <div className="absolute right-0 z-20 mt-1 w-44 rounded-lg bg-white p-1 shadow-pop ring-1 ring-gray-200">
                    {SORTS.slice(3).map(([v, l]) => (
                      <Link key={v} href={`/category/${params.slug}${qs({ sort: v, page: undefined })}`} className="block rounded px-2 py-1.5 text-[11px] text-ink-600 hover:bg-obah-50">
                        {l}
                      </Link>
                    ))}
                  </div>
                </details>
              </div>
            </div>
          </div>

          {res.items.length === 0 ? (
            <Empty
              title="No products matched your filters"
              hint="Try widening your price range or clearing some filters."
              action={<Link href={`/category/${params.slug}`} className="btn-primary mt-2">Clear filters</Link>}
            />
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
              {res.items.map((p) => (
                <ProductCard key={p.id} p={p as any} wished={wished.has(p.id)} />
              ))}
            </div>
          )}

          {res.pages > 1 && (
            <div className="mt-4 flex items-center justify-center gap-1">
              {Array.from({ length: Math.min(res.pages, 8) }).map((_, i) => {
                const n = i + 1;
                return (
                  <Link
                    key={n}
                    href={`/category/${params.slug}${qs({ page: String(n) })}`}
                    className={`grid h-8 w-8 place-items-center rounded text-xs font-bold ${n === res.page ? 'bg-obah-500 text-white' : 'bg-white text-ink-600 ring-1 ring-gray-200 hover:ring-obah-300'}`}
                  >
                    {n}
                  </Link>
                );
              })}
              {res.page < res.pages && (
                <Link href={`/category/${params.slug}${qs({ page: String(res.page + 1) })}`} className="btn-outline btn-sm ml-1">Next →</Link>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
