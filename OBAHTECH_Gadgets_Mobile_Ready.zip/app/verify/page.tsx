import Link from 'next/link';
import type { Metadata } from 'next';
import { consumeVerificationToken } from '@/lib/verification';
import { getSessionUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'Verify your email' };

const COPY: Record<string, { tone: string; title: string; body: string }> = {
  verified: {
    tone: 'emerald',
    title: 'Email verified',
    body: 'Thank you — your email address is now confirmed. Order updates, warranty reminders and receipts will reach this inbox.',
  },
  already: {
    tone: 'sky',
    title: 'Already verified',
    body: 'This link has been used before, so there is nothing else to do.',
  },
  invalid: {
    tone: 'rose',
    title: 'Link is invalid or expired',
    body: 'Verification links work for 48 hours. Sign in and request a fresh one from your account page.',
  },
};

export default async function VerifyPage({ searchParams }: { searchParams: Record<string, string> }) {
  const result = await consumeVerificationToken(searchParams.token || '');
  const copy = COPY[result];
  const user = await getSessionUser();
  const tone =
    copy.tone === 'emerald'
      ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
      : copy.tone === 'sky'
        ? 'border-sky-200 bg-sky-50 text-sky-900'
        : 'border-rose-200 bg-rose-50 text-rose-900';

  return (
    <div className="container-obah py-14">
      <div className="mx-auto max-w-md rounded-xl border border-gray-200 bg-white p-7 text-center shadow-card">
        <img src="/brand/logo-mark.svg" alt="" width={44} height={44} className="mx-auto rounded-xl" />
        <h1 className="mt-3 text-xl font-extrabold text-ink-900">OBAHTECH Gadgets</h1>
        <div className={`mt-4 rounded-lg border p-4 text-left text-sm ${tone}`}>
          <p className="font-bold">{copy.title}</p>
          <p className="mt-1 text-[13px] leading-relaxed">{copy.body}</p>
        </div>
        <div className="mt-5 flex flex-wrap justify-center gap-2 text-xs font-semibold">
          {user ? (
            <>
              <Link href="/account" className="rounded-lg bg-obah-500 px-4 py-2 text-white hover:bg-obah-600">Go to my account</Link>
              <Link href="/orders" className="rounded-lg bg-gray-100 px-4 py-2 text-ink-700 hover:bg-gray-200">My orders</Link>
            </>
          ) : (
            <>
              <Link href="/login" className="rounded-lg bg-obah-500 px-4 py-2 text-white hover:bg-obah-600">Sign in</Link>
              <Link href="/support" className="rounded-lg bg-gray-100 px-4 py-2 text-ink-700 hover:bg-gray-200">Contact support</Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
