import type { Metadata, Viewport } from 'next';
import { headers } from 'next/headers';
import './globals.css';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { MobileBottomNav } from '@/components/MobileBottomNav';
import { getSessionUser } from '@/lib/auth';
import { cartCount } from '@/lib/cart';

export const metadata: Metadata = {
  title: {
    default: 'OBAHTECH Gadgets — Smartphones, tablets & accessories in Nigeria',
    template: '%s · OBAHTECH Gadgets',
  },
  description:
    'Buy genuine iPhones, Samsung, Tecno, Infinix and Xiaomi phones, tablets and accessories at OBAHTECH Gadgets. Nationwide delivery across all 36 states and FCT, verified warranties, 7-day returns and secure Flutterwave payments.',
  keywords: ['OBAHTECH Gadgets', 'buy phones Nigeria', 'iPhone Nigeria', 'Samsung Nigeria', 'Tecno', 'Infinix', 'power bank Nigeria'],
  icons: { icon: '/favicon.svg' },
  openGraph: {
    title: 'OBAHTECH Gadgets',
    description: 'Genuine smartphones and accessories, delivered anywhere in Nigeria.',
    type: 'website',
  },
};

export const viewport: Viewport = {
  themeColor: '#ff7d0f',
  width: 'device-width',
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // The admin console renders its own chrome, so the storefront header/footer
  // are skipped for /admin routes (pathname injected by middleware).
  const pathname = (() => {
    try {
      return headers().get('x-pathname') || '';
    } catch {
      return '';
    }
  })();
  const isAdmin = pathname.startsWith('/admin');
  let cart = 0;
  let signedIn = false;
  if (!isAdmin) {
    try {
      const user = await getSessionUser();
      signedIn = !!user;
      cart = await cartCount(user?.id);
    } catch {
      /* unauthenticated / first render */
    }
  }
  return (
    <html lang="en-NG">
      <body>
        {!isAdmin && <Header />}
        <main className={isAdmin ? '' : 'min-h-[60vh]'}>{children}</main>
        {!isAdmin && <Footer />}
        {!isAdmin && (
          <>
            <div className="h-14 lg:hidden" aria-hidden />
            <MobileBottomNav cartCount={cart} signedIn={signedIn} />
          </>
        )}
      </body>
    </html>
  );
}
