import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { ProductCard } from '@/components/ProductCard';
import { Empty } from '@/components/ui';
import { toggleWishlist } from '@/lib/actions/customer';
import { addToCartAction } from '@/lib/actions/cart';

export const metadata = { title: 'My wishlist' };
export const dynamic = 'force-dynamic';

export default async function WishlistPage() {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/wishlist');
  const db = getDb();
  const items = await db
    .prepare(
      `SELECT p.id, p.name, p.slug, p.brand, p.price, p.compare_price, p.is_flash_sale, p.flash_price, p.rating_avg,
              p.rating_count, p.stock, p.reserved, p.ram, p.storage_options, p.warranty_months,
              (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
         FROM wishlists w JOIN products p ON p.id = w.product_id
        WHERE w.user_id = ? ORDER BY w.id DESC`,
    )
    .all(user.id) as any[];

  return (
    <div className="container-obah py-4">
      <h1 className="mb-3 text-lg font-extrabold text-ink-800">My wishlist ({items.length})</h1>
      {items.length === 0 ? (
        <Empty title="Your wishlist is empty" hint="Tap the ♡ on any product to save it for later." action={<Link href="/category/all" className="btn-primary mt-2">Browse products</Link>} />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {items.map((p) => (
            <div key={p.id} className="flex flex-col">
              <ProductCard p={p} wished compact />
              <div className="mt-1 flex gap-1">
                <form action={addToCartAction} className="flex-1">
                  <input type="hidden" name="product_id" value={p.id} />
                  <input type="hidden" name="qty" value={1} />
                  <button className="btn-primary btn-sm w-full" disabled={p.stock - p.reserved <= 0}>Add to cart</button>
                </form>
                <form action={toggleWishlist}>
                  <input type="hidden" name="product_id" value={p.id} />
                  <button className="btn-outline btn-sm" aria-label="Remove">✕</button>
                </form>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
