import Link from 'next/link';
import { redirect, notFound } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { flwConfig } from '@/lib/payments';
import { Alert, StatusBadge, PayBadge } from '@/components/ui';
import { NGN } from '@/lib/format';
import { startPaymentAction } from '@/lib/actions/checkout';

export const dynamic = 'force-dynamic';

export default async function PaymentPage({ params, searchParams }: { params: { orderNumber: string }; searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=/payments/${params.orderNumber}`);
  const db = getDb();
  const order = await db.prepare('SELECT o.*, s.name AS state_name, l.name AS lga_name FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id WHERE o.order_number = ?').get(params.orderNumber) as any;
  if (!order) notFound();
  if (user.role === 'customer' && order.user_id !== user.id) notFound();
  const cfg = flwConfig();
  const items = await db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id) as any[];

  return (
    <div className="container-obah max-w-2xl py-6">
      <div className="card p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h1 className="text-lg font-extrabold text-ink-800">Complete payment</h1>
            <p className="text-xs text-ink-400">Order {order.order_number}</p>
          </div>
          <div className="flex gap-1.5">
            <StatusBadge status={order.status} />
            <PayBadge status={order.payment_status} />
          </div>
        </div>

        {searchParams.error && <div className="mt-3"><Alert>{searchParams.error}</Alert></div>}
        {order.payment_status === 'paid' && (
          <div className="mt-3">
            <Alert tone="success">This order is already paid. <Link className="link" href={`/orders/${order.order_number}`}>View your order</Link>.</Alert>
          </div>
        )}

        <div className="mt-4 rounded-lg bg-gray-50 p-3">
          <p className="text-[11px] font-bold uppercase tracking-wide text-ink-500">Amount due</p>
          <p className="text-2xl font-extrabold text-obah-600">{NGN(order.total)}</p>
          <p className="text-[11px] text-ink-400">Currency: NGN · {items.length} item(s) · Deliver to {order.lga_name}, {order.state_name}</p>
        </div>

        <div className="mt-4 space-y-1.5">
          {items.map((it) => (
            <div key={it.id} className="flex items-center gap-2 text-xs">
              <img src={it.image} alt="" className="h-9 w-9 rounded bg-white object-contain ring-1 ring-gray-100" />
              <span className="min-w-0 flex-1 truncate">{it.name} × {it.qty}</span>
              <span className="font-semibold">{NGN(it.line_total)}</span>
            </div>
          ))}
        </div>

        {order.payment_status !== 'paid' ? (
          <>
            <form action={startPaymentAction} className="mt-4">
              <input type="hidden" name="order_number" value={order.order_number} />
              <button className="btn-primary w-full">
                {cfg.configured ? 'Pay now with Flutterwave' : 'Continue to sandbox checkout'}
              </button>
            </form>
            {!cfg.configured && (
              <div className="mt-3">
                <Alert tone="warn">
                  <strong>Sandbox mode.</strong> FLW_PUBLIC_KEY / FLW_SECRET_KEY are not configured, so no real charge can be made.
                  The checkout is simulated locally and every receipt is tagged “sandbox”. Add your Flutterwave test keys in
                  <code className="mx-1 rounded bg-white px-1">.env.local</code> to use the real hosted checkout.
                </Alert>
              </div>
            )}
            <p className="mt-3 text-center text-[10px] text-ink-400">
              You will be redirected to Flutterwave. Card details are never handled by OBAHTECH.
            </p>
          </>
        ) : (
          <Link href={`/orders/${order.order_number}`} className="btn-primary mt-4 w-full">View order</Link>
        )}
      </div>
    </div>
  );
}
