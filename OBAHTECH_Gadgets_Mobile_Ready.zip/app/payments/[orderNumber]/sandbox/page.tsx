import { redirect, notFound } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { flwConfig } from '@/lib/payments';
import { Alert } from '@/components/ui';
import { NGN } from '@/lib/format';

export const dynamic = 'force-dynamic';

/**
 * Local Flutterwave-style sandbox screen used ONLY when no live keys exist.
 * It posts to /api/payment/sandbox, which runs the exact same server-side
 * settlement path as a verified Flutterwave transaction.
 */
export default async function SandboxCheckout({ params, searchParams }: { params: { orderNumber: string }; searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (!user) redirect('/login');
  const cfg = flwConfig();
  const db = getDb();
  const order = await db.prepare('SELECT * FROM orders WHERE order_number = ?').get(params.orderNumber) as any;
  if (!order) notFound();
  if (cfg.configured && process.env.NODE_ENV === 'production') redirect(`/payments/${params.orderNumber}`);
  const txRef = searchParams.tx_ref || (await db.prepare("SELECT tx_ref FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1").get(order.id) as any)?.tx_ref;

  return (
    <div className="container-obah max-w-md py-8">
      <div className="overflow-hidden rounded-xl bg-white shadow-pop">
        <div className="flex items-center justify-between bg-[#f5a623] px-4 py-3">
          <p className="text-sm font-extrabold text-white">flutterwave <span className="font-normal">sandbox</span></p>
          <span className="rounded bg-white/25 px-2 py-0.5 text-[10px] font-bold uppercase text-white">Test mode</span>
        </div>
        <div className="p-4">
          <p className="text-[11px] uppercase tracking-wide text-ink-400">Paying OBAHTECH Gadgets</p>
          <p className="text-2xl font-extrabold text-ink-800">{NGN(order.total)}</p>
          <p className="text-[11px] text-ink-400">Ref: {txRef} · {order.email}</p>
          <div className="mt-3">
            <Alert tone="info">
              No real money moves here. Use the buttons below to simulate the gateway result — the server verifies and settles the
              order exactly as it would with live Flutterwave keys.
            </Alert>
          </div>
          <div className="mt-3 space-y-2 rounded-lg border border-gray-200 p-3">
            <p className="text-[11px] font-bold uppercase tracking-wide text-ink-500">Simulated card</p>
            <div className="flex items-center gap-2 text-xs text-ink-600">
              <span className="rounded bg-gray-100 px-2 py-0.5 font-bold">VISA</span>
              5531 •••• •••• 2950
            </div>
          </div>
          <form action="/api/payment/sandbox" method="post" className="mt-4 space-y-2">
            <input type="hidden" name="tx_ref" value={txRef} />
            <button name="outcome" value="successful" className="btn-primary w-full">Pay {NGN(order.total)}</button>
            <button name="outcome" value="failed" className="btn-outline w-full">Simulate a failed payment</button>
          </form>
          <p className="mt-3 text-center text-[10px] text-ink-400">
            Production requires FLW_SECRET_KEY; this screen disables itself automatically once keys are configured.
          </p>
        </div>
      </div>
    </div>
  );
}
