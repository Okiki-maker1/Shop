import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getSessionUser } from '@/lib/auth';
import { locationOptions } from '@/lib/locations.server';
import { LgaStateSelect } from '@/components/LgaStateSelect';
import { PasswordStrength } from '@/components/PasswordStrength';
import { Alert, Logo } from '@/components/ui';
import { registerAction } from '@/lib/actions/auth';

export const metadata = { title: 'Create your account' };
export const dynamic = 'force-dynamic';

export default async function RegisterPage({ searchParams }: { searchParams: Record<string, string> }) {
  if (await getSessionUser()) redirect('/account');
  const { states, lgas } = await locationOptions();
  return (
    <div className="container-obah grid gap-6 py-6 lg:grid-cols-[1fr_420px]">
      <div className="hidden flex-col justify-center rounded-2xl bg-gradient-to-br from-obah-500 to-obah-600 p-8 text-white lg:flex">
        <Logo size="lg" light />
        <h1 className="mt-6 text-3xl font-extrabold leading-tight">Create your OBAHTECH account</h1>
        <p className="mt-2 text-sm text-white/85">
          Shop genuine phones and accessories with nationwide delivery, order tracking, warranties and easy returns.
        </p>
        <ul className="mt-6 space-y-2 text-sm text-white/90">
          {[
            'Delivery to all 36 states + FCT',
            'Automatic hand-over to your state administrator',
            'Warranty records stored on your account',
            'Pay securely with Flutterwave in Naira',
          ].map((t) => (
            <li key={t} className="flex items-start gap-2"><span className="mt-0.5">✓</span>{t}</li>
          ))}
        </ul>
      </div>

      <div className="card p-5">
        <h2 className="text-xl font-extrabold text-ink-800">Register</h2>
        <p className="mb-4 text-xs text-ink-400">Already have an account? <Link href="/login" className="link">Sign in</Link></p>
        {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}
        <form action={registerAction} className="space-y-3">
          <div>
            <label className="label" htmlFor="full_name">Full name</label>
            <input id="full_name" name="full_name" required defaultValue={searchParams.full_name} className="input" placeholder="e.g. Ada Obi" autoComplete="name" />
          </div>
          <div>
            <label className="label" htmlFor="email">Email address</label>
            <input id="email" name="email" type="email" required defaultValue={searchParams.email} className="input" placeholder="you@example.com" autoComplete="email" />
          </div>
          <div>
            <label className="label" htmlFor="phone">Phone number</label>
            <input id="phone" name="phone" required defaultValue={searchParams.phone} className="input" placeholder="08031234567" inputMode="tel" autoComplete="tel" />
          </div>
          <LgaStateSelect states={states} lgas={lgas} />
          <p className="text-[11px] text-ink-400">Your state determines which OBAHTECH administrator handles your deliveries. Delivery addresses outside Nigeria are not supported.</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="password">Password</label>
              <PasswordStrength name="password" />
            </div>
            <div>
              <label className="label" htmlFor="confirm_password">Confirm password</label>
              <input id="confirm_password" name="confirm_password" type="password" required minLength={8} className="input" placeholder="Repeat password" autoComplete="new-password" />
            </div>
          </div>
          <button className="btn-primary w-full">Create account</button>
          <p className="text-center text-[11px] text-ink-400">
            By registering you accept our warranty, returns and privacy policies.
          </p>
        </form>
      </div>
    </div>
  );
}
