import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { getSessionUser, assertSameOrigin, rateLimit, clientIp } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ items: [], unread: 0 }, { status: 200 });
  if (!rateLimit(`notif:${user.id}:${clientIp()}`, 120, 60_000).ok)
    return NextResponse.json({ error: 'Too many requests' }, { status: 429 });

  const db = getDb();
  const limit = Math.min(50, Number(new URL(req.url).searchParams.get('limit') || 8));
  const items = await db
    .prepare(
      `SELECT id, type, title, body, order_id, is_read, created_at
         FROM notifications WHERE recipient_user_id = ?
        ORDER BY is_read ASC, id DESC LIMIT ?`,
    )
    .all(user.id, limit);
  const unread = (await db.prepare('SELECT COUNT(*) c FROM notifications WHERE recipient_user_id = ? AND is_read = 0').get(user.id) as any).c;
  return NextResponse.json({ items, unread });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
  if (!assertSameOrigin(req)) return NextResponse.json({ error: 'Bad origin' }, { status: 403 });
  const body = await req.json().catch(() => ({} as any));
  const db = getDb();
  if (body.action === 'read_all') {
    await db.prepare("UPDATE notifications SET is_read = 1, read_at = datetime('now') WHERE recipient_user_id = ? AND is_read = 0").run(user.id);
    await db.prepare("UPDATE notification_recipients SET read_at = datetime('now') WHERE user_id = ? AND read_at IS NULL").run(user.id);
  } else if (body.action === 'read' && body.id) {
    await db.prepare("UPDATE notifications SET is_read = 1, read_at = datetime('now') WHERE id = ? AND recipient_user_id = ?").run(Number(body.id), user.id);
  }
  return NextResponse.json({ ok: true });
}
