import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { logAdmin } from '@/lib/notify';

export const dynamic = 'force-dynamic';

function csv(rows: Record<string, any>[]): string {
  if (!rows.length) return 'no data\n';
  const headers = Object.keys(rows[0]);
  const escape = (v: any) => {
    const s = v == null ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(','), ...rows.map((r) => headers.map((h) => escape(r[h])).join(','))].join('\n');
}

/** Downloadable reports. State administrators are automatically scoped to their state. */
export async function GET(req: Request) {
  const user = await getSessionUser();
  if (!user || user.role === 'customer') return new Response('Forbidden', { status: 403 });
  const db = getDb();
  const url = new URL(req.url);
  const type = url.searchParams.get('type') || 'orders';
  const from = url.searchParams.get('from') || '';
  const to = url.searchParams.get('to') || '';
  const status = url.searchParams.get('status') || '';
  const scope = user.role === 'super_admin' ? '' : `AND o.state_id = ${Number(user.admin_state_id ?? 0)}`;
  const dateSql = `${from ? `AND o.created_at >= '${from} 00:00:00'` : ''}${to ? `AND o.created_at <= '${to} 23:59:59'` : ''}`;

  let rows: any[] = [];
  if (type === 'orders') {
    rows = await db
      .prepare(
        `SELECT o.order_number, o.created_at, o.customer_name, o.phone, o.email, s.name AS state, l.name AS lga,
                o.address_text, o.status, o.payment_status, o.subtotal, o.discount, o.delivery_fee, o.total,
                u.full_name AS assigned_admin
           FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id
           LEFT JOIN users u ON u.id=o.assigned_admin_id
          WHERE 1=1 ${scope} ${dateSql} ${status ? `AND o.status = '${status.replace(/[^a-z_]/g, '')}'` : ''}
          ORDER BY o.id DESC`,
      )
      .all();
  } else if (type === 'sales') {
    rows = await db
      .prepare(
        `SELECT substr(o.created_at,1,10) AS day, COUNT(*) AS orders,
                COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.total ELSE 0 END),0) AS revenue,
                COALESCE(SUM(CASE WHEN o.payment_status='failed' THEN 1 ELSE 0 END),0) AS failed_payments
           FROM orders o WHERE 1=1 ${scope} ${dateSql} GROUP BY day ORDER BY day DESC`,
      )
      .all();
  } else if (type === 'products') {
    rows = await db
      .prepare(
        `SELECT p.name, p.sku, p.brand, c.name AS category, p.price, p.stock, p.reserved, p.sold, p.warranty_months,
                (SELECT COUNT(*) FROM order_items WHERE product_id = p.id) AS times_ordered
           FROM products p JOIN categories c ON c.id = p.category_id ORDER BY p.sold DESC`,
      )
      .all();
  } else {
    rows = await db
      .prepare(
        `SELECT u.full_name, s.name AS state, COUNT(o.id) AS orders,
                COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.total ELSE 0 END),0) AS revenue
           FROM users u LEFT JOIN orders o ON o.assigned_admin_id = u.id LEFT JOIN states s ON s.id = u.admin_state_id
          WHERE u.role = 'state_admin' GROUP BY u.id, s.name`,
      )
      .all();
  }

  await logAdmin(user, 'report.download', type, undefined, { from, to });
  return new Response(csv(rows), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="obahtech-${type}-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
