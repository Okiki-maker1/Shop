import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { flwConfig, settlePayment } from '@/lib/payments';
import { getSessionUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

/**
 * SANDBOX SETTLEMENT — only reachable when Flutterwave keys are NOT configured
 * (or outside production). It mimics the gateway callback so the full order →
 * payment → fulfilment pipeline can be exercised end-to-end without charging.
 */
export async function POST(req: Request) {
  const cfg = flwConfig();
  if (cfg.configured && process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'Sandbox disabled: live Flutterwave keys are configured.' }, { status: 403 });
  }
  const user = await getSessionUser();
  if (!user) return NextResponse.redirect(new URL('/login', req.url));

  const form = await req.formData();
  const txRef = String(form.get('tx_ref') || '');
  const outcome = String(form.get('outcome') || 'successful') === 'failed' ? 'failed' : 'successful';
  const db = getDb();
  const payment = await db.prepare('SELECT * FROM payments WHERE tx_ref = ?').get(txRef) as any;
  if (!payment) return NextResponse.redirect(new URL('/orders?error=unknown_reference', req.url));
  const order = await db.prepare('SELECT * FROM orders WHERE id = ?').get(payment.order_id) as any;
  if (!order || (order.user_id !== user.id && user.role === 'customer')) {
    return NextResponse.redirect(new URL('/orders?error=forbidden', req.url));
  }

  if (outcome === 'failed') {
    await settlePayment({ txRef, outcome: 'failed', sandbox: true, raw: { note: 'sandbox declined by user' } });
    return NextResponse.redirect(new URL(`/orders/${order.order_number}?payment=failed`, req.url));
  }
  await settlePayment({ txRef, transactionId: `SANDBOX-${Date.now()}`, outcome: 'successful', sandbox: true, raw: { gateway: 'sandbox', amount: payment.amount } });
  return NextResponse.redirect(new URL(`/orders/${order.order_number}?paid=1&sandbox=1`, req.url));
}
