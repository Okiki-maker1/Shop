import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { flwConfig, verifyTransaction, settlePayment } from '@/lib/payments';

export const dynamic = 'force-dynamic';

/**
 * Flutterwave webhook. Rejects any request whose `verif-hash` header does not
 * equal FLW_SECRET_HASH, then re-verifies the transaction server-side.
 */
export async function POST(req: Request) {
  const cfg = flwConfig();
  const signature = req.headers.get('verif-hash') || '';
  if (!cfg.hash || signature !== cfg.hash) {
    return NextResponse.json({ status: 'ignored', reason: 'invalid signature' }, { status: 401 });
  }
  const payload: any = await req.json().catch(() => ({}));
  const data = payload?.data ?? {};
  if (payload?.event !== 'charge.completed' || !data?.tx_ref) {
    return NextResponse.json({ status: 'ignored' });
  }
  const db = getDb();
  const payment = await db.prepare('SELECT * FROM payments WHERE tx_ref = ?').get(data.tx_ref) as any;
  if (!payment) return NextResponse.json({ status: 'ignored', reason: 'unknown reference' }, { status: 200 });
  if (payment.status === 'successful') return NextResponse.json({ status: 'already_processed' });

  try {
    const verified = await verifyTransaction(String(data.id));
    const ok =
      verified?.status === 'successful' &&
      verified?.currency === payment.currency &&
      Number(verified?.amount) >= Number(payment.amount);
    await settlePayment({
      txRef: payment.tx_ref,
      transactionId: String(verified.id ?? data.id),
      outcome: ok ? 'successful' : 'failed',
      raw: verified,
    });
    return NextResponse.json({ status: 'ok' });
  } catch {
    return NextResponse.json({ status: 'verification_failed' }, { status: 500 });
  }
}
