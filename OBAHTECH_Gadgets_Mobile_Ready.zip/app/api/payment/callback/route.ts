import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { verifyTransaction, settlePayment } from '@/lib/payments';

export const dynamic = 'force-dynamic';

/**
 * Flutterwave browser redirect target.
 * The query string is treated as untrusted: the transaction is re-verified
 * against the Flutterwave API before anything is marked as paid.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const txRef = url.searchParams.get('tx_ref');
  const transactionId = url.searchParams.get('transaction_id');
  const flwStatus = url.searchParams.get('status');
  const db = getDb();
  const payment = txRef ? (await db.prepare('SELECT * FROM payments WHERE tx_ref = ?').get(txRef) as any) : null;
  const order = payment ? (await db.prepare('SELECT * FROM orders WHERE id = ?').get(payment.order_id) as any) : null;

  if (!payment || !order) return NextResponse.redirect(new URL('/orders?error=unknown_reference', req.url));

  if (flwStatus === 'cancelled') {
    return NextResponse.redirect(new URL(`/orders/${order.order_number}?payment=cancelled`, req.url));
  }

  try {
    const data = await verifyTransaction(String(transactionId));
    const ok =
      data?.status === 'successful' &&
      data?.currency === payment.currency &&
      Number(data?.amount) >= Number(payment.amount) &&
      data?.tx_ref === payment.tx_ref;
    if (!ok) {
      return NextResponse.redirect(new URL(`/orders/${order.order_number}?payment=unverified`, req.url));
    }
    await settlePayment({ txRef: payment.tx_ref, transactionId: String(data.id), outcome: 'successful', raw: data, sandbox: false });
    return NextResponse.redirect(new URL(`/orders/${order.order_number}?paid=1`, req.url));
  } catch {
    return NextResponse.redirect(new URL(`/orders/${order.order_number}?payment=verify_failed`, req.url));
  }
}
