import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { queueEmail } from '@/lib/notify';
import { rateLimit, clientIp } from '@/lib/auth';

export async function POST(req: Request) {
  const form = await req.formData().catch(() => null);
  const email = String(form?.get('email') || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) {
    return NextResponse.redirect(new URL('/?newsletter=invalid', req.url));
  }
  if (!rateLimit(`news:${clientIp()}`, 10, 60_000)) {
    return NextResponse.redirect(new URL('/?newsletter=slow', req.url));
  }
  const db = getDb();
  const exists = await db.prepare('SELECT id FROM email_outbox WHERE to_email = ? AND subject = ?').get(email, 'Newsletter subscription');
  if (!exists) {
    await queueEmail(email, 'Newsletter subscription', 'Thanks for subscribing to OBAHTECH Gadgets deals.');
  }
  return NextResponse.redirect(new URL('/?newsletter=ok', req.url));
}
