import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { fmtDateTime } from '@/lib/format';
import { adminReplyTicket } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminTickets({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const scope = user.role === 'super_admin' ? '' : `AND (t.state_id IS NULL OR t.state_id = ${Number(user.admin_state_id ?? 0)})`;
  const tickets = await db
    .prepare(
      `SELECT t.*, s.name AS state_name, o.order_number, a.full_name AS assignee
         FROM support_tickets t LEFT JOIN states s ON s.id = t.state_id
         LEFT JOIN orders o ON o.id = t.order_id LEFT JOIN users a ON a.id = t.assigned_admin_id
        WHERE 1=1 ${scope} ${searchParams.status ? `AND t.status = '${searchParams.status.replace(/[^a-z_]/g, '')}'` : ''}
        ORDER BY t.id DESC`,
    )
    .all() as any[];

  const ticketRows = await Promise.all(
    tickets.map(async (t) => ({
      t,
      msgs: (await db.prepare('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY id').all(t.id)) as any[],
    })),
  );

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Support tickets</h1>
        <p className="text-[11px] text-ink-400">
          {user.role === 'super_admin' ? 'All tickets nationwide' : `Tickets linked to ${user.state_name} orders`}
        </p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <div className="flex flex-wrap gap-1.5">
        {['', 'open', 'in_progress', 'resolved', 'closed'].map((s) => (
          <Link key={s || 'all'} href={s ? `/admin/tickets?status=${s}` : '/admin/tickets'} className={`rounded border px-2 py-1 text-[11px] font-semibold ${(searchParams.status || '') === s ? 'border-obah-500 bg-obah-50 text-obah-700' : 'border-gray-200 text-ink-500'}`}>
            {s ? s.replace(/_/g, ' ') : 'All'}
          </Link>
        ))}
      </div>

      <div className="space-y-2">
        {tickets.length === 0 && <div className="admin-card text-[11px] text-ink-400">No tickets.</div>}
        {ticketRows.map(({ t, msgs }) => (
            <div key={t.id} className="admin-card">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="text-[12px] font-bold text-ink-800">{t.reference} · {t.subject}</p>
                  <p className="text-[11px] text-ink-500">{t.name} · {t.email} {t.phone ? `· ${t.phone}` : ''}</p>
                  <p className="text-[10px] text-ink-400">
                    {t.category} · {t.state_name || 'No state'} {t.order_number ? <>· <Link href={`/admin/orders/${t.order_id}`} className="text-obah-600">{t.order_number}</Link></> : '· not order-linked'} · {fmtDateTime(t.created_at)}
                  </p>
                  <p className="mt-1 max-w-2xl rounded bg-gray-50 p-1.5 text-[11px] text-ink-600">{t.message}</p>
                  {msgs.map((m) => (
                    <p key={m.id} className={`mt-1 max-w-2xl rounded p-1.5 text-[11px] ${m.author_role === 'customer' ? 'bg-gray-50 text-ink-600' : 'bg-obah-50 text-ink-700'}`}>
                      <span className="font-bold">{m.author_role === 'customer' ? 'Customer' : 'OBAHTECH'}:</span> {m.body}
                    </p>
                  ))}
                </div>
                <span className={`chip ${t.status === 'open' ? 'bg-amber-50 text-amber-700 ring-amber-200' : t.status === 'resolved' ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-gray-100 text-gray-600 ring-gray-200'}`}>{t.status.replace(/_/g, ' ')}</span>
              </div>
              <form action={adminReplyTicket} className="mt-2 flex flex-wrap items-end gap-1.5 border-t border-gray-100 pt-2">
                <input type="hidden" name="ticket_id" value={t.id} />
                <input name="body" required placeholder="Reply to the customer…" className="input flex-1 py-1.5 text-xs" />
                <select name="status" className="input w-auto py-1.5 text-xs" defaultValue="">
                  <option value="">Keep status</option>
                  <option value="in_progress">In progress</option>
                  <option value="resolved">Resolved</option>
                  <option value="closed">Closed</option>
                </select>
                <button className="btn-primary btn-sm">Send reply</button>
              </form>
            </div>
        ))}
      </div>
    </div>
  );
}
