import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { StatusBadge, PayBadge, Alert } from '@/components/ui';
import { NGN, fmtDateTime, ORDER_STATUSES, STATUS_LABEL } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function AdminOrders({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const isSuper = user.role === 'super_admin';
  const where: string[] = [];
  const params: any[] = [];
  if (!isSuper) {
    where.push('o.state_id = ?');
    params.push(user.admin_state_id ?? 0);
  }
  if (searchParams.status) {
    where.push('o.status = ?');
    params.push(searchParams.status);
  }
  if (searchParams.state && isSuper) {
    where.push('o.state_id = ?');
    params.push(Number(searchParams.state));
  }
  if (searchParams.q) {
    where.push('(o.order_number LIKE ? OR o.customer_name LIKE ? OR o.email LIKE ? OR o.phone LIKE ?)');
    const like = `%${searchParams.q}%`;
    params.push(like, like, like, like);
  }
  if (searchParams.unassigned === '1') where.push('o.assigned_admin_id IS NULL');
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const page = Math.max(1, Number(searchParams.page || 1));
  const perPage = 25;
  const total = (await db.prepare(`SELECT COUNT(*) c FROM orders o ${whereSql}`).get(...params) as any).c;
  const rows = await db
    .prepare(
      `SELECT o.*, s.name AS state_name, l.name AS lga_name, u.full_name AS admin_name,
              (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS items,
              (SELECT image FROM order_items WHERE order_id = o.id LIMIT 1) AS image
         FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id
         LEFT JOIN users u ON u.id=o.assigned_admin_id
         ${whereSql} ORDER BY o.id DESC LIMIT ? OFFSET ?`,
    )
    .all(...params, perPage, (page - 1) * perPage) as any[];
  const states = await db.prepare('SELECT id, name FROM states ORDER BY name').all() as any[];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-xl font-extrabold text-ink-800">{isSuper ? 'All orders (nationwide)' : `${user.state_name} orders`}</h1>
          <p className="text-[11px] text-ink-400">{total} order(s) · {isSuper ? 'all states' : 'your assigned state only'}</p>
        </div>
        <Link href={`/api/admin/report?type=orders${searchParams.status ? `&status=${searchParams.status}` : ''}`} className="btn-outline btn-sm">⬇ Export CSV</Link>
      </div>

      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}
      {isSuper && searchParams.unassigned === '1' && <Alert tone="warn">Showing the unassigned queue — assign these orders to the correct state administrator.</Alert>}

      <form method="GET" className="admin-card flex flex-wrap items-end gap-2">
        <div className="min-w-[180px] flex-1">
          <label className="label">Search</label>
          <input name="q" defaultValue={searchParams.q} placeholder="Order number, customer, email, phone" className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Status</label>
          <select name="status" defaultValue={searchParams.status || ''} className="input py-1.5 text-xs">
            <option value="">All statuses</option>
            {ORDER_STATUSES.map((s) => (
              <option key={s} value={s}>{STATUS_LABEL[s]}</option>
            ))}
          </select>
        </div>
        {isSuper && (
          <div>
            <label className="label">State</label>
            <select name="state" defaultValue={searchParams.state || ''} className="input py-1.5 text-xs">
              <option value="">All states</option>
              {states.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
        )}
        <label className="flex items-center gap-1.5 pb-1.5 text-[11px] font-semibold text-ink-600">
          <input type="checkbox" name="unassigned" value="1" defaultChecked={searchParams.unassigned === '1'} /> Unassigned only
        </label>
        <button className="btn-dark btn-sm">Filter</button>
        <Link href="/admin/orders" className="btn-outline btn-sm">Reset</Link>
      </form>

      <div className="admin-card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="table-obah">
            <thead>
              <tr>
                <th>Order</th><th>Customer</th><th>Destination</th><th>Assigned to</th><th>Total</th><th>Payment</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((o) => (
                <tr key={o.id} className="hover:bg-gray-50">
                  <td>
                    <div className="flex items-center gap-2">
                      {o.image && <img src={o.image} alt="" className="h-8 w-8 rounded bg-[#f7f8fa] object-contain" />}
                      <div>
                        <Link href={`/admin/orders/${o.id}`} className="font-bold text-obah-600">{o.order_number}</Link>
                        <div className="text-[10px] text-ink-400">{fmtDateTime(o.created_at)} · {o.items} item(s)</div>
                      </div>
                    </div>
                  </td>
                  <td className="text-[11px]">
                    <p className="font-semibold text-ink-800">{o.customer_name}</p>
                    <p className="text-ink-400">{o.phone}</p>
                  </td>
                  <td className="text-[11px]">{o.lga_name}<div className="text-ink-400">{o.state_name}</div></td>
                  <td className="text-[11px]">
                    {o.admin_name ? (
                      <span className="font-semibold text-ink-700">{o.admin_name}</span>
                    ) : (
                      <span className="rounded bg-amber-50 px-1.5 py-0.5 font-bold text-amber-700">Unassigned</span>
                    )}
                  </td>
                  <td className="whitespace-nowrap text-[11px] font-bold">{NGN(o.total)}</td>
                  <td><PayBadge status={o.payment_status} /></td>
                  <td><StatusBadge status={o.status} /></td>
                  <td><Link href={`/admin/orders/${o.id}`} className="btn-outline btn-sm">Open</Link></td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr><td colSpan={8} className="py-8 text-center text-[11px] text-ink-400">No orders match these filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {Math.ceil(total / perPage) > 1 && (
        <div className="flex justify-center gap-1">
          {Array.from({ length: Math.ceil(total / perPage) }).slice(0, 10).map((_, i) => (
            <Link
              key={i}
              href={`/admin/orders?${new URLSearchParams({ ...searchParams, page: String(i + 1) }).toString()}`}
              className={`grid h-7 w-7 place-items-center rounded text-[11px] font-bold ${page === i + 1 ? 'bg-obah-500 text-white' : 'bg-white text-ink-600 ring-1 ring-gray-200'}`}
            >
              {i + 1}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
