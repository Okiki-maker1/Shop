import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { allowedNextStatuses } from '@/lib/orders';
import { Alert, StatusBadge, PayBadge } from '@/components/ui';
import { NGN, fmtDateTime, fmtDate, STATUS_LABEL } from '@/lib/format';
import { adminChangeStatus, adminAssignOrder, adminSetSerial, adminNotifyStateCustomer } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

const ACTION_LABEL: Record<string, string> = {
  order_confirmed: '✓ Confirm order',
  processing: '▶ Start processing',
  packed: '📦 Mark packed',
  shipped: '🚚 Update shipping',
  out_for_delivery: '🛵 Mark out for delivery',
  delivered: '✔️ Confirm delivery',
  cancelled: '✕ Cancel order',
  returned: '↩️ Mark item returned',
  refund_pending: '💸 Move to refund pending',
  refunded: '💸 Mark refunded',
};

export default async function AdminOrderDetail({ params, searchParams }: { params: { id: string }; searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const order = await db
    .prepare(
      `SELECT o.*, s.name AS state_name, l.name AS lga_name, u.full_name AS admin_name, u.email AS admin_email, c.full_name AS customer_account
         FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id
         LEFT JOIN users u ON u.id=o.assigned_admin_id LEFT JOIN users c ON c.id=o.user_id
        WHERE o.id = ?`,
    )
    .get(Number(params.id)) as any;
  if (!order) notFound();
  if (user.role === 'state_admin' && order.state_id !== user.admin_state_id) {
    redirect('/admin/orders?error=' + encodeURIComponent('Access denied: this order belongs to another state.'));
  }

  const items = await db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id) as any[];
  const events = await db.prepare('SELECT * FROM order_events WHERE order_id = ? ORDER BY id').all(order.id) as any[];
  const delivery = await db.prepare('SELECT * FROM deliveries WHERE order_id = ?').get(order.id) as any;
  const payments = await db.prepare('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC').all(order.id) as any[];
  const returns = await db.prepare('SELECT * FROM return_requests WHERE order_id = ? ORDER BY id DESC').all(order.id) as any[];
  const claims = await db.prepare('SELECT wc.*, w.product_name FROM warranty_claims wc JOIN warranties w ON w.id = wc.warranty_id WHERE wc.order_id = ?').all(order.id) as any[];
  const assignments = await db.prepare('SELECT * FROM order_assignments WHERE order_id = ? ORDER BY id DESC').all(order.id) as any[];
  const stateAdmins = await db
    .prepare("SELECT id, full_name, email FROM users WHERE role='state_admin' AND admin_state_id = ? AND is_active = 1")
    .all(order.state_id) as any[];
  const nextStatuses = allowedNextStatuses(order, user);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <Link href="/admin/orders" className="text-[11px] font-semibold text-obah-600">← Back to orders</Link>
          <h1 className="text-xl font-extrabold text-ink-800">{order.order_number}</h1>
          <p className="text-[11px] text-ink-400">{fmtDateTime(order.created_at)} · {order.lga_name}, {order.state_name}</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <StatusBadge status={order.status} />
          <PayBadge status={order.payment_status} />
        </div>
      </div>

      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      {/* Notification-style card (section 15) */}
      <div className="admin-card border-l-4 border-l-obah-500">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-obah-50 text-sm font-bold text-obah-700">
              {order.customer_name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <p className="text-sm font-bold text-ink-800">{order.customer_name}</p>
              <p className="text-[11px] text-ink-400">{order.email} · {order.phone}</p>
            </div>
          </div>
          <div className="text-right text-[11px] text-ink-500">
            <p>Delivery state: <span className="font-bold text-ink-800">{order.state_name}</span></p>
            <p>LGA: <span className="font-bold text-ink-800">{order.lga_name}</span></p>
            <p>Assigned: <span className="font-bold text-ink-800">{order.admin_name || 'Unassigned'}</span></p>
          </div>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {items.map((it) => (
            <div key={it.id} className="flex gap-2 rounded-lg border border-gray-100 p-2">
              <img src={it.image || ''} alt="" className="h-16 w-16 rounded bg-[#f7f8fa] object-contain" />
              <div className="min-w-0">
                <p className="text-[11px] font-bold text-ink-800">{it.name}</p>
                <p className="text-[10px] text-ink-500">{[it.brand, it.model].filter(Boolean).join(' · ')}</p>
                <p className="text-[10px] text-ink-500">{[it.color, it.storage].filter(Boolean).join(' · ')} · Qty {it.qty}</p>
                <p className="text-[11px] font-bold text-obah-600">{NGN(it.unit_price)}</p>
                {it.serial_no && <p className="text-[9px] text-ink-400">IMEI {it.serial_no}</p>}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-2 rounded-lg bg-gray-50 p-2 text-[11px] text-ink-600">
          <span className="font-bold text-ink-800">Deliver to:</span> {order.address_text}, {order.lga_name}, {order.state_name}
          {order.instructions && <span className="block text-ink-400">Instruction: {order.instructions}</span>}
        </div>
      </div>

      {/* Actions */}
      <div className="admin-card">
        <h2 className="mb-2 text-sm font-bold text-ink-800">Order actions</h2>
        <div className="flex flex-wrap gap-1.5">
          {nextStatuses.map((st) => (
            <form key={st} action={adminChangeStatus}>
              <input type="hidden" name="order_id" value={order.id} />
              <input type="hidden" name="status" value={st} />
              <button className={`btn-sm ${st === 'cancelled' ? 'btn-outline text-rose-600' : st === 'delivered' ? 'btn-dark' : 'btn-primary'}`}>
                {ACTION_LABEL[st] || STATUS_LABEL[st]}
              </button>
            </form>
          ))}
          {nextStatuses.length === 0 && <p className="text-[11px] text-ink-400">No further transitions are available for this status.</p>}
        </div>
        <form action={adminChangeStatus} className="mt-2 flex flex-wrap gap-1.5">
          <input type="hidden" name="order_id" value={order.id} />
          <select name="status" className="input w-auto py-1.5 text-xs">
            {['order_confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered', 'cancelled', 'returned', 'refund_pending', 'refunded']
              .filter((s) => s !== order.status)
              .map((s) => (
                <option key={s} value={s}>{STATUS_LABEL[s]}</option>
              ))}
          </select>
          <input name="note" placeholder="Internal note / reason (optional)" className="input flex-1 py-1.5 text-xs" />
          {user.role === 'super_admin' && (
            <label className="flex items-center gap-1 text-[10px] font-semibold text-ink-500">
              <input type="checkbox" name="force" value="1" /> override
            </label>
          )}
          <button className="btn-outline btn-sm">Apply with note</button>
        </form>

        {user.role === 'super_admin' && (
          <form action={adminAssignOrder} className="mt-2 flex flex-wrap items-end gap-1.5 border-t border-gray-100 pt-2">
            <input type="hidden" name="order_id" value={order.id} />
            <div>
              <label className="label">Reassign to {order.state_name} administrator</label>
              <select name="admin_id" className="input w-auto py-1.5 text-xs" defaultValue={order.assigned_admin_id ?? ''}>
                <option value="">Unassigned queue (super admin only)</option>
                {stateAdmins.map((a) => (
                  <option key={a.id} value={a.id}>{a.full_name}</option>
                ))}
              </select>
            </div>
            <input name="reason" placeholder="Reason" className="input w-40 py-1.5 text-xs" />
            <button className="btn-dark btn-sm">Save assignment</button>
            <p className="w-full text-[10px] text-ink-400">Only administrators of {order.state_name} can be assigned; future notifications follow the new assignment.</p>
          </form>
        )}

        <form action={adminNotifyStateCustomer} className="mt-2 flex flex-wrap gap-1.5 border-t border-gray-100 pt-2">
          <input type="hidden" name="order_id" value={order.id} />
          <input name="body" placeholder={`Message the customer about ${order.order_number}`} className="input flex-1 py-1.5 text-xs" required />
          <button className="btn-outline btn-sm">Notify customer</button>
        </form>
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <div className="admin-card">
          <h2 className="mb-2 text-sm font-bold text-ink-800">Payment records</h2>
          {payments.length === 0 && <p className="text-[11px] text-ink-400">No payment attempts.</p>}
          {payments.map((p) => (
            <div key={p.id} className="mb-2 rounded-lg bg-gray-50 p-2 text-[11px]">
              <div className="flex items-center justify-between">
                <span className="font-bold">{NGN(p.amount)} {p.currency}</span>
                <span className={`chip ${p.status === 'successful' ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : p.status === 'failed' ? 'bg-rose-50 text-rose-700 ring-rose-200' : 'bg-amber-50 text-amber-700 ring-amber-200'}`}>{p.status}</span>
              </div>
              <p className="break-all text-ink-500">ref {p.tx_ref}</p>
              {p.flw_ref && <p className="break-all text-ink-400">gateway {p.flw_ref}</p>}
              <p className="text-ink-400">{p.method || 'card'} · {p.sandbox ? 'sandbox' : 'flutterwave'} · verified {fmtDateTime(p.verified_at)}</p>
            </div>
          ))}
        </div>

        <div className="admin-card">
          <h2 className="mb-2 text-sm font-bold text-ink-800">Delivery & fulfilment</h2>
          <dl className="grid grid-cols-2 gap-1 text-[11px]">
            <dt className="text-ink-400">Tracking ref</dt><dd className="font-semibold">{delivery?.tracking_ref}</dd>
            <dt className="text-ink-400">Courier</dt><dd className="font-semibold">{delivery?.courier || 'OBAHTECH Logistics'}</dd>
            <dt className="text-ink-400">ETA</dt><dd className="font-semibold">{fmtDate(delivery?.eta_date)}</dd>
            <dt className="text-ink-400">Shipped</dt><dd className="font-semibold">{fmtDate(delivery?.shipped_at)}</dd>
            <dt className="text-ink-400">Out for delivery</dt><dd className="font-semibold">{fmtDate(delivery?.out_for_delivery_at)}</dd>
            <dt className="text-ink-400">Delivered</dt><dd className="font-semibold">{fmtDate(delivery?.delivered_at)}</dd>
            <dt className="text-ink-400">Order total</dt><dd className="font-semibold">{NGN(order.total)}</dd>
            <dt className="text-ink-400">Discount</dt><dd className="font-semibold">{NGN(order.discount)} {order.promo_code ? `(${order.promo_code})` : ''}</dd>
            <dt className="text-ink-400">Delivery fee</dt><dd className="font-semibold">{NGN(order.delivery_fee)}</dd>
          </dl>
          <div className="mt-2 border-t border-gray-100 pt-2">
            <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-ink-500">IMEI / serial numbers</p>
            {items.map((it) => (
              <form key={it.id} action={adminSetSerial} className="mb-1 flex gap-1">
                <input type="hidden" name="item_id" value={it.id} />
                <input name="serial_no" defaultValue={it.serial_no || ''} placeholder={`Serial for ${it.name.slice(0, 22)}`} className="input py-1 text-[11px]" />
                <button className="btn-outline btn-sm">Save</button>
              </form>
            ))}
          </div>
        </div>
      </div>

      {(returns.length > 0 || claims.length > 0) && (
        <div className="admin-card">
          <h2 className="mb-2 text-sm font-bold text-ink-800">Returns & warranty claims on this order</h2>
          {returns.map((r) => (
            <div key={r.id} className="mb-1 rounded bg-amber-50 p-2 text-[11px] text-amber-900">
              <p className="font-bold">Return #{r.id} — {r.status}</p>
              <p>{r.reason}: {r.explanation}</p>
              {r.admin_note && <p>Note: {r.admin_note}</p>}
            </div>
          ))}
          {claims.map((c) => (
            <div key={c.id} className="mb-1 rounded bg-sky-50 p-2 text-[11px] text-sky-900">
              <p className="font-bold">Claim #{c.id} — {c.status} ({c.product_name})</p>
              <p>{c.issue}</p>
              {c.admin_note && <p>Note: {c.admin_note}</p>}
            </div>
          ))}
          <div className="mt-1 flex gap-2 text-[11px] font-bold">
            <Link href="/admin/returns" className="text-obah-600">Review returns →</Link>
            <Link href="/admin/warranties" className="text-obah-600">Review claims →</Link>
          </div>
        </div>
      )}

      <div className="admin-card">
        <h2 className="mb-2 text-sm font-bold text-ink-800">Timeline & assignment history</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <ol className="space-y-1.5">
            {events.map((e) => (
              <li key={e.id} className="flex gap-2 text-[11px]">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-obah-500" />
                <div>
                  <p className="font-semibold text-ink-700">{STATUS_LABEL[e.status] || e.status}</p>
                  {e.note && <p className="text-ink-500">{e.note}</p>}
                  <p className="text-[10px] text-ink-300">{fmtDateTime(e.created_at)} · {e.actor_role}</p>
                </div>
              </li>
            ))}
          </ol>
          <ol className="space-y-1.5">
            {assignments.map((a) => (
              <li key={a.id} className="rounded bg-gray-50 p-1.5 text-[11px]">
                <p className="font-semibold text-ink-700">{a.admin_name || 'Unassigned queue'}</p>
                <p className="text-ink-400">{a.reason} · {fmtDateTime(a.created_at)}</p>
              </li>
            ))}
            {assignments.length === 0 && <li className="text-[11px] text-ink-400">No assignment history.</li>}
          </ol>
        </div>
      </div>
    </div>
  );
}
