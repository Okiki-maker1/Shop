import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { NGN } from '@/lib/format';
import { locationOptions } from '@/lib/locations.server';
import { LgaStateSelect } from '@/components/LgaStateSelect';
import { adminSaveDeliveryFee, adminDeleteDeliveryFee } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminDelivery({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const { states, lgas } = await locationOptions();
  const rules = await db
    .prepare(
      `SELECT d.*, s.name AS state_name, l.name AS lga_name FROM delivery_fees d
         JOIN states s ON s.id = d.state_id LEFT JOIN lgas l ON l.id = d.lga_id
        ORDER BY s.name, l.name IS NULL DESC LIMIT 200`,
    )
    .all() as any[];

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Delivery configuration</h1>
        <p className="text-[11px] text-ink-400">
          Fees and estimates per state, LGA, method and order value. LGA rules override state rules; national fallbacks apply when
          nothing matches.
        </p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <form action={adminSaveDeliveryFee} className="admin-card space-y-2">
        <p className="text-sm font-bold text-obah-600">Add a delivery rule</p>
        <LgaStateSelect states={states} lgas={lgas} />
        <div className="grid gap-2 sm:grid-cols-4">
          <div>
            <label className="label">Method</label>
            <select name="method" className="input py-1.5 text-xs">
              <option value="standard">Standard</option>
              <option value="express">Express</option>
            </select>
          </div>
          <div>
            <label className="label">Fee (₦)</label>
            <input name="fee" type="number" min="0" required className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">ETA (days)</label>
            <input name="eta_days" type="number" min="1" defaultValue={3} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Min order value (₦)</label>
            <input name="min_order" type="number" min="0" defaultValue={0} className="input py-1.5 text-xs" />
          </div>
        </div>
        <button className="btn-primary btn-sm">Save rule</button>
      </form>

      <div className="admin-card overflow-hidden p-0">
        <div className="max-h-[520px] overflow-auto">
          <table className="table-obah">
            <thead><tr><th>State</th><th>LGA</th><th>Method</th><th>Fee</th><th>ETA</th><th>Min order</th><th></th></tr></thead>
            <tbody>
              {rules.map((r) => (
                <tr key={r.id}>
                  <td className="text-[11px] font-semibold">{r.state_name}</td>
                  <td className="text-[11px]">{r.lga_name || <span className="rounded bg-gray-100 px-1.5 text-[10px] font-bold">State-wide</span>}</td>
                  <td className="text-[11px]">{r.method}</td>
                  <td className="text-[11px] font-bold">{NGN(r.fee)}</td>
                  <td className="text-[11px]">{r.eta_days}d</td>
                  <td className="text-[11px]">{r.min_order ? NGN(r.min_order) : '—'}</td>
                  <td>
                    <form action={adminDeleteDeliveryFee}>
                      <input type="hidden" name="id" value={r.id} />
                      <button className="btn-outline btn-sm text-rose-600">Delete</button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
