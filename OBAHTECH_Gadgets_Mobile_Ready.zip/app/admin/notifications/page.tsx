import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { fmtDateTime, timeAgo } from '@/lib/format';
import { adminSendAnnouncement, adminSendScheduledAnnouncement, adminDeleteAnnouncement } from '@/lib/actions/admin';
import { markNotificationsRead } from '@/lib/actions/customer';

export const dynamic = 'force-dynamic';

export default async function AdminNotifications({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const isSuper = user.role === 'super_admin';
  const alerts = await db
    .prepare(
      `SELECT n.*, o.order_number FROM notifications n LEFT JOIN orders o ON o.id = n.order_id
        WHERE n.recipient_user_id = ? AND n.audience = 'admin' ORDER BY n.id DESC LIMIT 60`,
    )
    .all(user.id) as any[];
  const announcements = isSuper ? (await db.prepare('SELECT a.*, s.name AS state_name, p.name AS product_name FROM announcements a LEFT JOIN states s ON s.id=a.state_id LEFT JOIN products p ON p.id=a.product_id ORDER BY a.id DESC').all() as any[]) : [];
  const customers = isSuper ? (await db.prepare("SELECT COUNT(*) c FROM users WHERE role='customer'").get() as any).c : 0;
  const states = isSuper ? (await db.prepare('SELECT id, name FROM states ORDER BY name').all() as any[]) : [];
  const products = isSuper ? (await db.prepare('SELECT id, name FROM products ORDER BY name LIMIT 200').all() as any[]) : [];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-xl font-extrabold text-ink-800">Notifications</h1>
          <p className="text-[11px] text-ink-400">
            Private order alerts are restricted to the super admin and the administrator of the order&apos;s delivery state. Customer
            marketing messages are managed separately below.
          </p>
        </div>
        <form action={markNotificationsRead}>
          <button className="btn-outline btn-sm">Mark all my alerts read</button>
        </form>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <div className="admin-card overflow-hidden p-0">
        <div className="border-b border-gray-100 px-3 py-2">
          <h2 className="text-sm font-bold text-ink-800">My order alerts ({alerts.filter((a) => !a.is_read).length} unread)</h2>
          <p className="text-[10px] text-ink-400">New orders, payments, cancellations, returns, warranty claims and delivery updates routed to you.</p>
        </div>
        <div className="max-h-[420px] divide-y divide-gray-50 overflow-y-auto">
          {alerts.length === 0 && <p className="px-3 py-6 text-center text-[11px] text-ink-400">No alerts for you yet.</p>}
          {alerts.map((n) => (
            <div key={n.id} className={`px-3 py-2 ${n.is_read ? '' : 'bg-obah-50/40'}`}>
              <div className="flex flex-wrap items-start justify-between gap-1">
                <div>
                  <p className="text-[12px] font-bold text-ink-800">{n.title}</p>
                  {n.body && <p className="text-[11px] text-ink-500">{n.body}</p>}
                  <p className="text-[10px] text-ink-300">
                    {n.type.replace(/_/g, ' ')} · {timeAgo(n.created_at)}
                    {n.state_id ? ` · state #${n.state_id}` : ''}
                  </p>
                </div>
                <div className="flex gap-1.5">
                  {n.order_id && <Link href={`/admin/orders/${n.order_id}`} className="btn-outline btn-sm">Open order</Link>}
                  {!n.is_read && (
                    <form action={markNotificationsRead}>
                      <input type="hidden" name="id" value={n.id} />
                      <button className="btn-outline btn-sm">Mark read</button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {isSuper && (
        <>
          <form action={adminSendAnnouncement} className="admin-card space-y-2">
            <div>
              <h2 className="text-sm font-bold text-ink-800">Send a customer announcement</h2>
              <p className="text-[10px] text-ink-400">In-app notification reaches {customers} customers instantly. A copy is also emailed when EMAIL_API_KEY is set and texted when SMS_API_KEY is set; otherwise both are logged to the outbox for review.</p>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <div>
                <label className="label">Title *</label>
                <input name="title" required className="input py-1.5 text-xs" placeholder="e.g. New Tecno arrivals this week" />
              </div>
              <div>
                <label className="label">Audience</label>
                <select name="audience" className="input py-1.5 text-xs">
                  <option value="all">All customers</option>
                  <option value="state">Customers in one state</option>
                  <option value="product_buyers">Buyers of a particular product</option>
                </select>
              </div>
              <div>
                <label className="label">State (for state audience)</label>
                <select name="state_id" className="input py-1.5 text-xs">
                  <option value="">—</option>
                  {states.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Product (for buyer audience)</label>
                <select name="product_id" className="input py-1.5 text-xs">
                  <option value="">—</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="label">Message *</label>
              <textarea name="body" rows={3} required className="input py-1.5 text-xs" />
            </div>
            <div className="flex flex-wrap items-end gap-3">
              <div>
                <label className="label">Schedule (leave blank to send now)</label>
                <input type="datetime-local" name="scheduled_at" className="input py-1.5 text-xs" />
              </div>
              <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="email" defaultChecked /> Email copy</label>
              <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="sms" /> SMS copy</label>
              <button className="btn-primary btn-sm">Send / schedule</button>
            </div>
          </form>

          <div className="admin-card overflow-hidden p-0">
            <div className="border-b border-gray-100 px-3 py-2">
              <h2 className="text-sm font-bold text-ink-800">Announcement history</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="table-obah">
                <thead><tr><th>Title</th><th>Audience</th><th>Channels</th><th>Recipients</th><th>Sent / scheduled</th><th></th></tr></thead>
                <tbody>
                  {announcements.map((a) => (
                    <tr key={a.id}>
                      <td className="text-[11px] font-bold text-ink-800">{a.title}<div className="line-clamp-1 text-[10px] font-normal text-ink-400">{a.body}</div></td>
                      <td className="text-[10px]">
                        {a.audience === 'state' ? `State: ${a.state_name}` : a.audience === 'product_buyers' ? `Buyers of ${a.product_name}` : 'All customers'}
                      </td>
                      <td className="text-[10px]">{a.channels.replace(/,/g, ', ')}</td>
                      <td className="text-[11px]">{a.recipients}</td>
                      <td className="text-[10px]">{a.sent_at ? fmtDateTime(a.sent_at) : a.scheduled_at ? `Scheduled ${fmtDateTime(a.scheduled_at)}` : '—'}</td>
                      <td>
                        <div className="flex gap-1">
                          {!a.sent_at && (
                            <form action={adminSendScheduledAnnouncement}>
                              <input type="hidden" name="id" value={a.id} />
                              <button className="btn-primary btn-sm">Send now</button>
                            </form>
                          )}
                          <form action={adminDeleteAnnouncement}>
                            <input type="hidden" name="id" value={a.id} />
                            <button className="btn-outline btn-sm text-rose-600">Delete</button>
                          </form>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {announcements.length === 0 && <tr><td colSpan={6} className="py-6 text-center text-[11px] text-ink-400">No announcements yet.</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
