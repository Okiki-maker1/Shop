import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { NGN, fmtDate } from '@/lib/format';
import { adminSavePromo, adminDeletePromo } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminPromotions({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const rows = await db.prepare('SELECT * FROM promotions ORDER BY id DESC').all() as any[];
  const editing = searchParams.edit ? (await db.prepare('SELECT * FROM promotions WHERE id = ?').get(Number(searchParams.edit)) as any) : null;

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Discount codes</h1>
        <p className="text-[11px] text-ink-400">Percentage, fixed-amount and free-delivery promotions with usage caps and schedules.</p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <form action={adminSavePromo} className="admin-card grid gap-2 sm:grid-cols-4">
        {editing && <input type="hidden" name="id" value={editing.id} />}
        <div>
          <label className="label">Code *</label>
          <input name="code" defaultValue={editing?.code} required className="input py-1.5 text-xs" />
        </div>
        <div className="sm:col-span-2">
          <label className="label">Description</label>
          <input name="description" defaultValue={editing?.description} className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Type</label>
          <select name="type" defaultValue={editing?.type || 'percent'} className="input py-1.5 text-xs">
            <option value="percent">Percent off</option>
            <option value="fixed">Fixed ₦ off</option>
            <option value="free_delivery">Free delivery</option>
          </select>
        </div>
        <div>
          <label className="label">Value (% or ₦)</label>
          <input name="value" type="number" min="0" defaultValue={editing?.value ?? 10} className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Min order (₦)</label>
          <input name="min_order" type="number" min="0" defaultValue={editing?.min_order ?? 0} className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Max uses</label>
          <input name="max_uses" type="number" min="0" defaultValue={editing?.max_uses ?? ''} className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Ends</label>
          <input name="ends_at" type="date" defaultValue={editing?.ends_at?.slice(0, 10)} className="input py-1.5 text-xs" />
        </div>
        <div className="flex items-end gap-2 sm:col-span-3">
          <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="is_active" defaultChecked={editing ? Boolean(editing.is_active) : true} /> Active</label>
          <button className="btn-primary btn-sm">{editing ? 'Save code' : 'Create code'}</button>
          {editing && <Link href="/admin/promotions" className="btn-outline btn-sm">Cancel</Link>}
        </div>
      </form>

      <div className="admin-card overflow-hidden p-0">
        <table className="table-obah">
          <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min order</th><th>Used</th><th>Expires</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id}>
                <td className="text-[11px] font-bold text-ink-800">{p.code}<div className="text-[10px] font-normal text-ink-400">{p.description}</div></td>
                <td className="text-[11px]">{p.type.replace(/_/g, ' ')}</td>
                <td className="text-[11px] font-bold">{p.type === 'percent' ? `${p.value}%` : p.type === 'fixed' ? NGN(p.value) : 'Free delivery'}</td>
                <td className="text-[11px]">{p.min_order ? NGN(p.min_order) : '—'}</td>
                <td className="text-[11px]">{p.used_count}{p.max_uses ? ` / ${p.max_uses}` : ''}</td>
                <td className="text-[11px]">{fmtDate(p.ends_at)}</td>
                <td><span className={`chip ${p.is_active ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-gray-100 text-gray-600 ring-gray-200'}`}>{p.is_active ? 'Active' : 'Off'}</span></td>
                <td>
                  <div className="flex gap-1">
                    <Link href={`/admin/promotions?edit=${p.id}`} className="btn-outline btn-sm">Edit</Link>
                    <form action={adminDeletePromo}>
                      <input type="hidden" name="id" value={p.id} />
                      <button className="btn-outline btn-sm text-rose-600">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
