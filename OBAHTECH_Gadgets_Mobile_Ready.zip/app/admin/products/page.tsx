import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { NGN } from '@/lib/format';
import { adminSaveProduct, adminDeleteProduct } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminProducts({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const cats = await db.prepare('SELECT id, name FROM categories ORDER BY sort_order').all() as any[];
  const editing = searchParams.edit ? (await db.prepare('SELECT * FROM products WHERE id = ?').get(Number(searchParams.edit)) as any) : null;
  const q = searchParams.q || '';
  const rows = await db
    .prepare(
      `SELECT p.*, c.name AS cat,
              (SELECT COUNT(*) FROM order_items WHERE product_id = p.id) sold_items,
              (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) image
         FROM products p JOIN categories c ON c.id = p.category_id
        WHERE (? = '' OR p.name LIKE '%'||?||'%' OR p.brand LIKE '%'||?||'%')
        ORDER BY p.id DESC LIMIT 100`,
    )
    .all(q, q, q) as any[];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-xl font-extrabold text-ink-800">Product management</h1>
          <p className="text-[11px] text-ink-400">{rows.length} products · create, edit, price, stock and warranty control</p>
        </div>
        <form method="GET" className="flex gap-1.5">
          <input name="q" defaultValue={q} placeholder="Search products…" className="input py-1.5 text-xs" />
          <button className="btn-dark btn-sm">Search</button>
        </form>
      </div>

      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <details className="admin-card" open={Boolean(editing)}>
        <summary className="cursor-pointer text-sm font-bold text-obah-600">
          {editing ? `Editing: ${editing.name}` : '+ Add a new product'}
        </summary>
        <form action={adminSaveProduct} className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3" encType="multipart/form-data">
          {editing && <input type="hidden" name="id" value={editing.id} />}
          {editing && <input type="hidden" name="slug" value={editing.slug} />}
          <div className="sm:col-span-2">
            <label className="label">Product name *</label>
            <input name="name" defaultValue={editing?.name} required className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Brand</label>
            <input name="brand" defaultValue={editing?.brand} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Model</label>
            <input name="model" defaultValue={editing?.model} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Category *</label>
            <select name="category_id" defaultValue={editing?.category_id} required className="input py-1.5 text-xs">
              {cats.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">SKU</label>
            <input name="sku" defaultValue={editing?.sku} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Price (₦) *</label>
            <input name="price" type="number" min="1" defaultValue={editing?.price} required className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Compare-at price (₦)</label>
            <input name="compare_price" type="number" min="0" defaultValue={editing?.compare_price ?? ''} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Stock</label>
            <input name="stock" type="number" min="0" defaultValue={editing?.stock ?? 0} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Low-stock alert at</label>
            <input name="low_stock_at" type="number" min="0" defaultValue={editing?.low_stock_at ?? 5} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">RAM</label>
            <input name="ram" defaultValue={editing?.ram} placeholder="8GB" className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Battery</label>
            <input name="battery" defaultValue={editing?.battery} placeholder="5000mAh" className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Screen</label>
            <input name="screen_size" defaultValue={editing?.screen_size} placeholder='6.7" AMOLED' className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Network</label>
            <input name="network" defaultValue={editing?.network} placeholder="5G" className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Condition</label>
            <select name="condition" defaultValue={editing?.condition || 'New'} className="input py-1.5 text-xs">
              {['New', 'Open box', 'Refurbished', 'Used - Grade A'].map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Warranty (months)</label>
            <input name="warranty_months" type="number" min="0" defaultValue={editing?.warranty_months ?? 12} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Colour options (comma separated)</label>
            <input name="color_options" defaultValue={editing ? JSON.parse(editing.color_options || '[]').join(', ') : 'Black, Blue'} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Storage options (comma separated)</label>
            <input name="storage_options" defaultValue={editing ? JSON.parse(editing.storage_options || '[]').join(', ') : '128GB, 256GB'} className="input py-1.5 text-xs" />
          </div>
          <div className="sm:col-span-2 lg:col-span-3">
            <label className="label">Short description</label>
            <input name="short_description" defaultValue={editing?.short_description} className="input py-1.5 text-xs" />
          </div>
          <div className="sm:col-span-2 lg:col-span-3">
            <label className="label">Full description</label>
            <textarea name="description" rows={2} defaultValue={editing?.description} className="input py-1.5 text-xs" />
          </div>
          <div className="sm:col-span-2 lg:col-span-3">
            <label className="label">Warranty policy text</label>
            <textarea name="warranty_policy" rows={2} defaultValue={editing?.warranty_policy} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Upload product image</label>
            <input type="file" name="image" accept="image/*" className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">…or image URL</label>
            <input name="image_url" placeholder="/products/phone-2.svg" className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Flash sale price (₦)</label>
            <input name="flash_price" type="number" min="0" defaultValue={editing?.flash_price ?? ''} className="input py-1.5 text-xs" />
          </div>
          <div className="flex flex-wrap items-center gap-3 sm:col-span-2 lg:col-span-3">
            <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="is_active" defaultChecked={editing ? Boolean(editing.is_active) : true} /> Active</label>
            <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="is_featured" defaultChecked={Boolean(editing?.is_featured)} /> Featured</label>
            <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="is_flash_sale" defaultChecked={Boolean(editing?.is_flash_sale)} /> Flash sale</label>
            <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="tracks_serial" defaultChecked={Boolean(editing?.tracks_serial)} /> Track IMEI/serial</label>
            <button className="btn-primary btn-sm">{editing ? 'Save changes' : 'Create product'}</button>
            {editing && <Link href="/admin/products" className="btn-outline btn-sm">Cancel edit</Link>}
          </div>
        </form>
      </details>

      <div className="admin-card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="table-obah">
            <thead>
              <tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Sold</th><th>Warranty</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {rows.map((p) => {
                const avail = p.stock - p.reserved;
                return (
                  <tr key={p.id} className="hover:bg-gray-50">
                    <td>
                      <div className="flex items-center gap-2">
                        <img src={p.image} alt="" className="h-9 w-9 rounded bg-[#f7f8fa] object-contain" />
                        <div>
                          <Link href={`/product/${p.slug}`} className="text-[11px] font-bold text-ink-800 hover:text-obah-600">{p.name}</Link>
                          <div className="text-[10px] text-ink-400">{p.brand} · {p.sku}</div>
                        </div>
                      </div>
                    </td>
                    <td className="text-[11px]">{p.cat}</td>
                    <td className="whitespace-nowrap text-[11px] font-bold">{NGN(p.price)}</td>
                    <td className={`text-[11px] font-bold ${avail <= p.low_stock_at ? 'text-rose-600' : 'text-ink-700'}`}>{avail}<span className="text-[9px] text-ink-400"> / {p.stock}</span></td>
                    <td className="text-[11px]">{p.sold_items}</td>
                    <td className="text-[11px]">{p.warranty_months}mo</td>
                    <td>
                      <span className={`chip ${p.is_active ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-gray-100 text-gray-600 ring-gray-200'}`}>
                        {p.is_active ? 'Live' : 'Hidden'}
                      </span>
                    </td>
                    <td>
                      <div className="flex gap-1">
                        <Link href={`/admin/products?edit=${p.id}`} className="btn-outline btn-sm">Edit</Link>
                        <form action={adminDeleteProduct}>
                          <input type="hidden" name="id" value={p.id} />
                          <button className="btn-outline btn-sm text-rose-600">Archive</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
