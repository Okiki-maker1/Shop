import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { fmtDate } from '@/lib/format';
import { adminSaveBanner, adminToggleBanner, adminDeleteBanner } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

const BG: Record<string, string> = {
  orange: 'from-obah-500 to-obah-600',
  dark: 'from-ink-800 to-slate-700',
  teal: 'from-teal-600 to-emerald-700',
  coral: 'from-rose-600 to-orange-600',
  navy: 'from-slate-800 to-indigo-800',
};

export default async function AdminBanners({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const rows = await db.prepare('SELECT * FROM banners ORDER BY placement, sort_order, id').all() as any[];
  const editing = searchParams.edit ? (await db.prepare('SELECT * FROM banners WHERE id = ?').get(Number(searchParams.edit)) as any) : null;

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Banners & promotions</h1>
        <p className="text-[11px] text-ink-400">Changes appear on the storefront immediately — schedule start and expiry dates per banner.</p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <div className="grid gap-3 lg:grid-cols-[1fr_1.1fr]">
        <form action={adminSaveBanner} className="admin-card space-y-2" encType="multipart/form-data">
          <p className="text-sm font-bold text-obah-600">{editing ? `Editing banner #${editing.id}` : 'Create a banner'}</p>
          {editing && <input type="hidden" name="id" value={editing.id} />}
          <div>
            <label className="label">Title *</label>
            <input name="title" defaultValue={editing?.title} required className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">Subtitle / description</label>
            <input name="subtitle" defaultValue={editing?.subtitle} className="input py-1.5 text-xs" />
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <label className="label">Promotional text</label>
              <input name="promo_text" defaultValue={editing?.promo_text} placeholder="Up to 30% OFF" className="input py-1.5 text-xs" />
            </div>
            <div>
              <label className="label">CTA button label</label>
              <input name="cta_label" defaultValue={editing?.cta_label || 'Shop now'} className="input py-1.5 text-xs" />
            </div>
            <div>
              <label className="label">Destination link</label>
              <input name="cta_link" defaultValue={editing?.cta_link || '/category/all'} className="input py-1.5 text-xs" />
            </div>
            <div>
              <label className="label">Colour theme</label>
              <select name="bg_style" defaultValue={editing?.bg_style || 'orange'} className="input py-1.5 text-xs">
                {Object.keys(BG).map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Placement</label>
              <select name="placement" defaultValue={editing?.placement || 'home_hero'} className="input py-1.5 text-xs">
                <option value="home_hero">Homepage hero</option>
                <option value="promo_strip">Promotional strip</option>
                <option value="category_banner">Category banner</option>
                <option value="campaign_banner">Campaign banner</option>
              </select>
            </div>
            <div>
              <label className="label">Sort order</label>
              <input name="sort_order" type="number" defaultValue={editing?.sort_order ?? 0} className="input py-1.5 text-xs" />
            </div>
            <div>
              <label className="label">Start date</label>
              <input name="starts_at" type="date" defaultValue={editing?.starts_at?.slice(0, 10)} className="input py-1.5 text-xs" />
            </div>
            <div>
              <label className="label">Expiry date</label>
              <input name="ends_at" type="date" defaultValue={editing?.ends_at?.slice(0, 10)} className="input py-1.5 text-xs" />
            </div>
          </div>
          <div>
            <label className="label">Banner image (optional — overrides artwork)</label>
            <input type="file" name="image" accept="image/*" className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">…or image URL</label>
            <input name="image_url" defaultValue={editing?.image_url} className="input py-1.5 text-xs" />
          </div>
          <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="is_active" defaultChecked={editing ? Boolean(editing.is_active) : true} /> Active (visible on site)</label>
          <div className="flex gap-2">
            <button className="btn-primary btn-sm">{editing ? 'Save banner' : 'Publish banner'}</button>
            {editing && <Link href="/admin/banners" className="btn-outline btn-sm">Cancel</Link>}
          </div>
        </form>

        <div className="space-y-2">
          <p className="text-sm font-bold text-ink-800">Live preview</p>
          <div className={`rounded-xl bg-gradient-to-br ${BG[editing?.bg_style || 'orange']} p-4 text-white`}>
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/70">{editing?.promo_text || 'Up to 30% OFF'}</p>
            <p className="mt-1 text-lg font-extrabold">{editing?.title || 'Your banner headline'}</p>
            <p className="text-[11px] text-white/85">{editing?.subtitle || 'Supporting description goes here.'}</p>
            <span className="mt-2 inline-block rounded bg-white px-3 py-1 text-[11px] font-bold text-ink-800">{editing?.cta_label || 'Shop now'} →</span>
          </div>
          <div className="admin-card overflow-hidden p-0">
            <table className="table-obah">
              <thead><tr><th>Banner</th><th>Placement</th><th>Schedule</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {rows.map((b) => {
                  const expired = b.ends_at && new Date(b.ends_at) < new Date();
                  return (
                    <tr key={b.id}>
                      <td className="text-[11px] font-bold text-ink-800">{b.title}<div className="text-[10px] font-normal text-ink-400">{b.cta_label} → {b.cta_link}</div></td>
                      <td className="text-[10px]">{b.placement.replace(/_/g, ' ')}</td>
                      <td className="text-[10px]">{fmtDate(b.starts_at)} → {fmtDate(b.ends_at)}</td>
                      <td>
                        <span className={`chip ${b.is_active && !expired ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-gray-100 text-gray-600 ring-gray-200'}`}>
                          {expired ? 'Expired' : b.is_active ? 'Live' : 'Inactive'}
                        </span>
                      </td>
                      <td>
                        <div className="flex flex-wrap gap-1">
                          <Link href={`/admin/banners?edit=${b.id}`} className="btn-outline btn-sm">Edit</Link>
                          <form action={adminToggleBanner}>
                            <input type="hidden" name="id" value={b.id} />
                            <button className="btn-outline btn-sm">{b.is_active ? 'Deactivate' : 'Activate'}</button>
                          </form>
                          <form action={adminDeleteBanner}>
                            <input type="hidden" name="id" value={b.id} />
                            <button className="btn-outline btn-sm text-rose-600">Delete</button>
                          </form>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
