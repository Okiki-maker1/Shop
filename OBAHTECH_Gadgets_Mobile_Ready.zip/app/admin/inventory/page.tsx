import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { fmtDateTime } from '@/lib/format';
import { adminAdjustStock } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminInventory({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const products = await db
    .prepare(
      `SELECT p.id, p.name, p.sku, p.stock, p.reserved, p.sold, p.returned_stock, p.damaged_stock, p.low_stock_at,
              (p.stock - p.reserved) AS available,
              (SELECT COALESCE(SUM(qty),0) FROM order_items WHERE product_id = p.id) AS units_ordered,
              (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
         FROM products p WHERE p.is_active = 1 ORDER BY available ASC LIMIT 100`,
    )
    .all() as any[];
  const logs = await db
    .prepare(
      `SELECT sl.*, p.name, u.full_name AS admin_name FROM stock_logs sl
         JOIN products p ON p.id = sl.product_id LEFT JOIN users u ON u.id = sl.admin_id
        ORDER BY sl.id DESC LIMIT 40`,
    )
    .all() as any[];
  const totals = products.reduce(
    (acc, p) => {
      acc.available += p.available;
      acc.reserved += p.reserved;
      acc.sold += p.sold;
      acc.damaged += p.damaged_stock;
      if (p.available <= p.low_stock_at) acc.low += 1;
      return acc;
    },
    { available: 0, reserved: 0, sold: 0, damaged: 0, low: 0 },
  );

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Inventory management</h1>
        <p className="text-[11px] text-ink-400">Stock, reservations and sold units are reconciled atomically at order creation and payment.</p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}
      {totals.low > 0 && <Alert tone="warn">{totals.low} product(s) at or below their low-stock threshold.</Alert>}

      <div className="grid gap-2 sm:grid-cols-5">
        {[
          ['Available units', totals.available],
          ['Reserved (unpaid)', totals.reserved],
          ['Sold units', totals.sold],
          ['Damaged', totals.damaged],
          ['Low-stock items', totals.low],
        ].map(([l, v]) => (
          <div key={l as string} className="admin-card">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-400">{l}</p>
            <p className="text-xl font-extrabold text-ink-800">{v as number}</p>
          </div>
        ))}
      </div>

      <div className="admin-card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="table-obah">
            <thead><tr><th>Product</th><th>Available</th><th>Reserved</th><th>Sold</th><th>Damaged</th><th>Adjust stock</th></tr></thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className={p.available <= p.low_stock_at ? 'bg-rose-50/40' : ''}>
                  <td>
                    <div className="flex items-center gap-2">
                      <img src={p.image} alt="" className="h-8 w-8 rounded bg-white object-contain" />
                      <div>
                        <p className="text-[11px] font-bold text-ink-800">{p.name}</p>
                        <p className="text-[10px] text-ink-400">{p.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className={`text-[11px] font-bold ${p.available <= p.low_stock_at ? 'text-rose-600' : 'text-emerald-700'}`}>{p.available}</td>
                  <td className="text-[11px]">{p.reserved}</td>
                  <td className="text-[11px]">{p.sold}</td>
                  <td className="text-[11px]">{p.damaged_stock}</td>
                  <td>
                    <form action={adminAdjustStock} className="flex gap-1">
                      <input type="hidden" name="product_id" value={p.id} />
                      <input name="change" type="number" placeholder="+/-" className="input w-16 py-1 text-[11px]" required />
                      <input name="reason" placeholder="reason" className="input w-28 py-1 text-[11px]" />
                      <button className="btn-outline btn-sm">Apply</button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="admin-card">
        <h2 className="mb-2 text-sm font-bold text-ink-800">Stock movement log</h2>
        <div className="max-h-72 overflow-y-auto">
          <table className="table-obah">
            <thead><tr><th>When</th><th>Product</th><th>Change</th><th>Reason</th><th>By</th></tr></thead>
            <tbody>
              {logs.map((l) => (
                <tr key={l.id}>
                  <td className="whitespace-nowrap text-[10px] text-ink-400">{fmtDateTime(l.created_at)}</td>
                  <td className="text-[11px]">{l.name}</td>
                  <td className={`text-[11px] font-bold ${l.change < 0 ? 'text-rose-600' : 'text-emerald-700'}`}>{l.change > 0 ? `+${l.change}` : l.change}</td>
                  <td className="text-[10px]">{l.reason.replace(/_/g, ' ')}</td>
                  <td className="text-[10px]">{l.admin_name || 'system'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
