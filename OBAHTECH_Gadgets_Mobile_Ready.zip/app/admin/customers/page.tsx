import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { NGN, fmtDate } from '@/lib/format';
import { adminMessageCustomer } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminCustomers({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const q = searchParams.q || '';
  const stateFilter = searchParams.state ? Number(searchParams.state) : null;
  const rows = await db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.created_at, s.name AS state_name, l.name AS lga_name,
              (SELECT COUNT(*) FROM orders WHERE user_id = u.id) orders,
              (SELECT COALESCE(SUM(total),0) FROM orders WHERE user_id = u.id AND payment_status='paid') spend
         FROM users u LEFT JOIN states s ON s.id = u.state_id LEFT JOIN lgas l ON l.id = u.lga_id
        WHERE u.role = 'customer'
          AND (? = '' OR u.full_name LIKE '%'||?||'%' OR u.email LIKE '%'||?||'%' OR u.phone LIKE '%'||?||'%')
          ${stateFilter ? `AND u.state_id = ${stateFilter}` : ''}
        ORDER BY spend DESC LIMIT 100`,
    )
    .all(q, q, q, q) as any[];
  const states = await db.prepare('SELECT id, name FROM states ORDER BY name').all() as any[];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-xl font-extrabold text-ink-800">Customers</h1>
          <p className="text-[11px] text-ink-400">{rows.length} customers · message an individual customer directly (private, in-app + email)</p>
        </div>
        <form method="GET" className="flex flex-wrap gap-1.5">
          <input name="q" defaultValue={q} placeholder="Search name, email, phone" className="input py-1.5 text-xs" />
          <select name="state" defaultValue={searchParams.state || ''} className="input w-auto py-1.5 text-xs">
            <option value="">All states</option>
            {states.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
          <button className="btn-dark btn-sm">Filter</button>
        </form>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <div className="admin-card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="table-obah">
            <thead><tr><th>Customer</th><th>Location</th><th>Orders</th><th>Lifetime spend</th><th>Joined</th><th>Message</th></tr></thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id} className="hover:bg-gray-50">
                  <td className="text-[11px]">
                    <p className="font-bold text-ink-800">{c.full_name}</p>
                    <p className="text-ink-400">{c.email}</p>
                    <p className="text-[10px] text-ink-300">{c.phone}</p>
                  </td>
                  <td className="text-[11px]">{c.lga_name ? `${c.lga_name}, ` : ''}{c.state_name || '—'}</td>
                  <td className="text-[11px]">{c.orders}</td>
                  <td className="text-[11px] font-bold">{NGN(c.spend)}</td>
                  <td className="text-[10px] text-ink-400">{fmtDate(c.created_at)}</td>
                  <td>
                    <details>
                      <summary className="cursor-pointer text-[11px] font-bold text-obah-600">Send ▾</summary>
                      <form action={adminMessageCustomer} className="mt-1 flex w-64 gap-1">
                        <input type="hidden" name="user_id" value={c.id} />
                        <input name="body" required placeholder="Message" className="input flex-1 py-1 text-[11px]" />
                        <button className="btn-primary btn-sm">Send</button>
                      </form>
                    </details>
                  </td>
                </tr>
              ))}
              {rows.length === 0 && <tr><td colSpan={6} className="py-6 text-center text-[11px] text-ink-400">No customers match.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
      <p className="text-[10px] text-ink-400">
        Need a bulk send? Use <Link href="/admin/notifications" className="link">Notifications → Send a customer announcement</Link>.
      </p>
    </div>
  );
}
