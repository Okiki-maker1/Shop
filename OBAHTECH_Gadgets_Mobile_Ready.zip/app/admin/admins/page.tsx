import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { NGN, fmtDateTime } from '@/lib/format';
import {
  adminCreateAdministrator,
  adminUpdateAdministrator,
  adminToggleAdministrator,
  adminDeleteAdministrator,
  adminResetAdministratorPassword,
} from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminAdmins({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const states = await db.prepare('SELECT id, name FROM states ORDER BY name').all() as any[];
  const admins = await db
    .prepare(
      `SELECT u.*, s.name AS state_name,
              (SELECT COUNT(*) FROM orders WHERE assigned_admin_id = u.id) orders,
              (SELECT COUNT(*) FROM orders WHERE assigned_admin_id = u.id AND status = 'delivered') delivered,
              (SELECT COALESCE(SUM(total),0) FROM orders WHERE assigned_admin_id = u.id AND payment_status = 'paid') revenue
         FROM users u LEFT JOIN states s ON s.id = u.admin_state_id
        WHERE u.role = 'state_admin' ORDER BY s.name, u.id`,
    )
    .all() as any[];
  const covered = new Set(admins.filter((a) => a.is_active && !a.is_suspended).map((a) => a.admin_state_id));
  const uncovered = states.filter((s) => !covered.has(s.id));
  const logs = await db.prepare('SELECT * FROM admin_logs ORDER BY id DESC LIMIT 25').all() as any[];

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Administrator management</h1>
        <p className="text-[11px] text-ink-400">Only the super administrator can provision, reassign, suspend or delete administrators. Public registration is disabled.</p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}
      {uncovered.length > 0 && (
        <Alert tone="warn">
          {uncovered.length} state(s) have no active administrator: {uncovered.slice(0, 8).map((s) => s.name).join(', ')}
          {uncovered.length > 8 ? '…' : ''}. Orders to these states go to the unassigned queue.
        </Alert>
      )}

      <form action={adminCreateAdministrator} className="admin-card grid gap-2 sm:grid-cols-5">
        <div className="sm:col-span-2">
          <label className="label">Full name *</label>
          <input name="full_name" required className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Email *</label>
          <input name="email" type="email" required className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Phone</label>
          <input name="phone" className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Assigned state *</label>
          <select name="state_id" required className="input py-1.5 text-xs">
            <option value="">Select state…</option>
            {states.map((s) => (
              <option key={s.id} value={s.id}>{s.name}{covered.has(s.id) ? ' (has admin)' : ''}</option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="label">Temporary password (10+ chars) *</label>
          <input name="password" required minLength={10} className="input py-1.5 text-xs" />
        </div>
        <div className="flex items-end sm:col-span-3">
          <button className="btn-primary btn-sm">Provision administrator</button>
        </div>
      </form>

      <div className="admin-card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="table-obah">
            <thead>
              <tr><th>Administrator</th><th>State</th><th>Orders</th><th>Delivered</th><th>Revenue</th><th>Status</th><th>Manage</th></tr>
            </thead>
            <tbody>
              {admins.map((a) => (
                <tr key={a.id} className="hover:bg-gray-50">
                  <td className="text-[11px]">
                    <p className="font-bold text-ink-800">{a.full_name}</p>
                    <p className="text-ink-400">{a.email}</p>
                    <p className="text-[10px] text-ink-300">{a.phone}</p>
                  </td>
                  <td className="text-[11px] font-semibold">{a.state_name}</td>
                  <td className="text-[11px]">{a.orders}</td>
                  <td className="text-[11px]">{a.delivered}</td>
                  <td className="text-[11px] font-bold">{NGN(a.revenue)}</td>
                  <td>
                    <span className={`chip ${!a.is_active ? 'bg-gray-100 text-gray-600 ring-gray-200' : a.is_suspended ? 'bg-rose-50 text-rose-700 ring-rose-200' : 'bg-emerald-50 text-emerald-700 ring-emerald-200'}`}>
                      {!a.is_active ? 'Deleted' : a.is_suspended ? 'Suspended' : 'Active'}
                    </span>
                  </td>
                  <td>
                    <details>
                      <summary className="cursor-pointer text-[11px] font-bold text-obah-600">Manage ▾</summary>
                      <div className="mt-1 w-56 space-y-2 rounded-lg bg-gray-50 p-2">
                        <form action={adminUpdateAdministrator} className="space-y-1">
                          <input type="hidden" name="id" value={a.id} />
                          <input name="full_name" defaultValue={a.full_name} className="input py-1 text-[11px]" />
                          <input name="phone" defaultValue={a.phone || ''} className="input py-1 text-[11px]" />
                          <select name="state_id" defaultValue={a.admin_state_id} className="input py-1 text-[11px]">
                            {states.map((s) => (
                              <option key={s.id} value={s.id}>{s.name}</option>
                            ))}
                          </select>
                          <button className="btn-outline btn-sm w-full">Save changes</button>
                        </form>
                        <form action={adminResetAdministratorPassword} className="space-y-1">
                          <input type="hidden" name="id" value={a.id} />
                          <input name="password" placeholder="New password" minLength={10} required className="input py-1 text-[11px]" />
                          <button className="btn-outline btn-sm w-full">Reset password</button>
                        </form>
                        <div className="flex gap-1">
                          <form action={adminToggleAdministrator}>
                            <input type="hidden" name="id" value={a.id} />
                            <input type="hidden" name="action" value={a.is_suspended ? 'reactivate' : 'suspend'} />
                            <button className="btn-outline btn-sm">{a.is_suspended ? 'Reactivate' : 'Suspend'}</button>
                          </form>
                          {a.is_active ? (
                            <form action={adminDeleteAdministrator}>
                              <input type="hidden" name="id" value={a.id} />
                              <button className="btn-outline btn-sm text-rose-600">Delete</button>
                            </form>
                          ) : null}
                        </div>
                      </div>
                    </details>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="admin-card">
        <h2 className="mb-2 text-sm font-bold text-ink-800">Administrator activity log (audit trail)</h2>
        <div className="max-h-72 overflow-y-auto">
          <table className="table-obah">
            <thead><tr><th>When</th><th>Administrator</th><th>Action</th><th>Entity</th></tr></thead>
            <tbody>
              {logs.map((l) => (
                <tr key={l.id}>
                  <td className="whitespace-nowrap text-[10px] text-ink-400">{fmtDateTime(l.created_at)}</td>
                  <td className="text-[11px] font-semibold">{l.admin_name}</td>
                  <td className="text-[11px]">{l.action}</td>
                  <td className="text-[10px] text-ink-400">{l.entity} {l.entity_id}</td>
                </tr>
              ))}
              {logs.length === 0 && <tr><td colSpan={4} className="py-4 text-center text-[11px] text-ink-400">No activity recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
