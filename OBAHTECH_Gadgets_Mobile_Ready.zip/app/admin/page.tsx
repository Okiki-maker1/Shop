import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { Alert, Stat, StatusBadge, PayBadge, BarChart } from '@/components/ui';
import { NGN, NGNcompact, fmtDateTime, STATUS_LABEL } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function AdminOverview({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const isSuper = user.role === 'super_admin';
  const scope = isSuper ? '' : `AND o.state_id = ${Number(user.admin_state_id ?? 0)}`;
  const from = searchParams.from || '';
  const to = searchParams.to || '';
  const dateSql = `${from ? `AND o.created_at >= '${from} 00:00:00'` : ''}${to ? `AND o.created_at <= '${to} 23:59:59'` : ''}`;

  const k = await db
    .prepare(
      `SELECT
        COUNT(*) AS orders,
        COALESCE(SUM(CASE WHEN o.payment_status = 'paid' THEN o.total ELSE 0 END),0) AS revenue,
        SUM(CASE WHEN o.status = 'delivered' THEN 1 ELSE 0 END) AS delivered,
        SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
        SUM(CASE WHEN o.status = 'pending_payment' THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN o.status IN ('processing','packed','shipped','out_for_delivery','order_confirmed','payment_confirmed') THEN 1 ELSE 0 END) AS inflight,
        SUM(CASE WHEN o.status = 'cancellation_requested' THEN 1 ELSE 0 END) AS canc_req
       FROM orders o WHERE 1=1 ${scope} ${dateSql}`,
    )
    .get() as any;

  const customers = isSuper
    ? ((await db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'customer'").get() as any).c as number)
    : ((await db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'customer' AND state_id = ?").get(user.admin_state_id) as any).c as number);
  const admins = (await db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'state_admin' AND is_active = 1").get() as any).c;
  const products = (await db.prepare('SELECT COUNT(*) c FROM products WHERE is_active = 1').get() as any).c;
  const lowStock = await db.prepare('SELECT id, name, stock, reserved, low_stock_at FROM products WHERE is_active = 1 AND (stock - reserved) <= low_stock_at ORDER BY (stock - reserved) ASC LIMIT 6').all() as any[];
  const returns = (await db.prepare("SELECT COUNT(*) c FROM return_requests WHERE status IN ('requested','approved')").get() as any).c;
  const claims = (await db.prepare("SELECT COUNT(*) c FROM warranty_claims WHERE status IN ('submitted','under_review','info_needed')").get() as any).c;
  const tickets = (await db.prepare("SELECT COUNT(*) c FROM support_tickets WHERE status IN ('open','in_progress')").get() as any).c;
  const payStats = await db
    .prepare(`SELECT SUM(CASE WHEN payment_status='paid' THEN 1 ELSE 0 END) ok, SUM(CASE WHEN payment_status='failed' THEN 1 ELSE 0 END) failed FROM orders o WHERE 1=1 ${scope}`)
    .get() as any;

  // last 7 days revenue
  const daily: { label: string; value: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5);
    const day = d.toISOString().slice(0, 10);
    const row = await db
      .prepare(
        `SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} AND substr(o.created_at,1,10) = ?`,
      )
      .get(day) as any;
    daily.push({ label: d.toLocaleDateString('en-NG', { weekday: 'short' }), value: row.v });
  }

  const byState = isSuper
    ? (await db
        .prepare(
          `SELECT s.name, COUNT(o.id) orders, COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.total ELSE 0 END),0) revenue
             FROM states s LEFT JOIN orders o ON o.state_id = s.id
            GROUP BY s.id HAVING COUNT(o.id) > 0 ORDER BY revenue DESC LIMIT 10`,
        )
        .all() as any[])
    : (await db
        .prepare(
          `SELECT l.name, COUNT(o.id) orders, COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.total ELSE 0 END),0) revenue
             FROM orders o JOIN lgas l ON l.id = o.lga_id WHERE o.state_id = ?
            GROUP BY l.id ORDER BY revenue DESC LIMIT 10`,
        )
        .all(user.admin_state_id) as any[]);

  const recent = await db
    .prepare(
      `SELECT o.*, s.name AS state_name, l.name AS lga_name, u.full_name AS admin_name
         FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id
         LEFT JOIN users u ON u.id=o.assigned_admin_id
        WHERE 1=1 ${scope} ORDER BY o.id DESC LIMIT 8`,
    )
    .all() as any[];

  const unassigned = await db.prepare("SELECT COUNT(*) c FROM orders WHERE assigned_admin_id IS NULL AND status NOT IN ('cancelled','refunded')").get() as any;
  const statesWithoutAdmin = await db
    .prepare(
      `SELECT s.id, s.name FROM states s
        WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.admin_state_id = s.id AND u.role='state_admin' AND u.is_active=1)`,
    )
    .all() as any[];

  const pipelineStatuses = ['pending_payment', 'payment_confirmed', 'order_confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered', 'cancellation_requested', 'cancelled', 'return_requested', 'refunded'];
  const pipeline = await Promise.all(
    pipelineStatuses.map(async (st) => ({
      st,
      c: ((await db.prepare(`SELECT COUNT(*) c FROM orders o WHERE o.status = ? ${scope}`).get(st)) as any).c,
    })),
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-xl font-extrabold text-ink-800">{isSuper ? 'Nationwide overview' : `${user.state_name} overview`}</h1>
          <p className="text-[11px] text-ink-400">
            {isSuper ? 'You have super administrator access to all 36 states and the FCT.' : 'Scoped to your assigned state only.'}
          </p>
        </div>
        <form method="GET" className="flex flex-wrap items-end gap-1.5">
          <div>
            <label className="label">From</label>
            <input type="date" name="from" defaultValue={from} className="input py-1.5 text-xs" />
          </div>
          <div>
            <label className="label">To</label>
            <input type="date" name="to" defaultValue={to} className="input py-1.5 text-xs" />
          </div>
          <button className="btn-dark btn-sm">Apply</button>
          <Link href={`/api/admin/report?type=orders&from=${from}&to=${to}`} className="btn-outline btn-sm">⬇ CSV</Link>
        </form>
      </div>

      {searchParams.welcome && <Alert tone="success">Welcome! This is your {isSuper ? 'super admin' : 'state admin'} console.</Alert>}
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {isSuper && unassigned.c > 0 && (
        <Alert tone="warn">
          <strong>{unassigned.c} unassigned order(s).</strong> No administrator is configured for some delivery states — assign or
          create one from <Link href="/admin/admins" className="link">Administrator management</Link>.
        </Alert>
      )}

      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Revenue (paid)" value={NGN(k.revenue)} tone="text-emerald-600" hint={`${payStats.ok ?? 0} successful payments`} />
        <Stat label="Total orders" value={k.orders} hint={`${k.delivered} delivered · ${k.cancelled} cancelled`} />
        <Stat label="In progress" value={k.inflight} hint={`${k.pending} awaiting payment`} />
        <Stat label="Customers" value={customers} hint={isSuper ? `across all states` : `in ${user.state_name}`} />
        {isSuper && <Stat label="Administrators" value={admins} hint="active state admins" />}
        <Stat label="Active products" value={products} hint={`${lowStock.length} low on stock`} />
        <Stat label="Return requests" value={returns} hint="awaiting decision" />
        <Stat label="Warranty claims" value={claims} hint="open claims" />
        <Stat label="Support tickets" value={tickets} hint="open / in progress" />
        <Stat label="Failed payments" value={payStats.failed ?? 0} hint="orders with failed payment" tone="text-rose-600" />
      </div>

      <div className="grid gap-3 lg:grid-cols-[1.4fr_1fr]">
        <div className="admin-card">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-bold text-ink-800">Revenue — last 7 days</h2>
            <span className="text-[11px] text-ink-400">Paid orders only</span>
          </div>
          <BarChart data={daily} />
        </div>
        <div className="admin-card">
          <h2 className="mb-2 text-sm font-bold text-ink-800">{isSuper ? 'Sales by state' : 'Sales by LGA'}</h2>
          <div className="space-y-1.5">
            {byState.length === 0 && <p className="text-[11px] text-ink-400">No sales yet.</p>}
            {byState.map((r) => {
              const max = Math.max(...byState.map((x) => x.revenue), 1);
              return (
                <div key={r.name}>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-ink-700">{r.name}</span>
                    <span className="text-ink-500">{NGNcompact(r.revenue)} <span className="text-ink-300">· {r.orders}</span></span>
                  </div>
                  <div className="h-1.5 w-full rounded bg-gray-100">
                    <div className="h-1.5 rounded bg-obah-500" style={{ width: `${(r.revenue / max) * 100}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <div className="admin-card overflow-hidden p-0">
          <div className="flex items-center justify-between border-b border-gray-100 px-3 py-2">
            <h2 className="text-sm font-bold text-ink-800">Latest orders</h2>
            <Link href="/admin/orders" className="text-[11px] font-bold text-obah-600">All orders →</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="table-obah">
              <thead><tr><th>Order</th><th>State</th><th>Total</th><th>Status</th></tr></thead>
              <tbody>
                {recent.map((o) => (
                  <tr key={o.id}>
                    <td>
                      <Link href={`/admin/orders/${o.id}`} className="font-bold text-obah-600">{o.order_number}</Link>
                      <div className="text-[10px] text-ink-400">{o.customer_name} · {fmtDateTime(o.created_at)}</div>
                    </td>
                    <td className="text-[11px]">{o.lga_name}, {o.state_name}</td>
                    <td className="whitespace-nowrap text-[11px] font-bold">{NGN(o.total)}</td>
                    <td><StatusBadge status={o.status} /></td>
                  </tr>
                ))}
                {recent.length === 0 && <tr><td colSpan={4} className="py-6 text-center text-[11px] text-ink-400">No orders yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-3">
          <div className="admin-card">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-sm font-bold text-ink-800">Low stock</h2>
              {isSuper && <Link href="/admin/inventory" className="text-[11px] font-bold text-obah-600">Manage →</Link>}
            </div>
            {lowStock.length === 0 && <p className="text-[11px] text-ink-400">All products are healthy.</p>}
            {lowStock.map((p) => (
              <div key={p.id} className="flex items-center justify-between border-b border-gray-50 py-1 text-[11px] last:border-0">
                <span className="truncate pr-2 text-ink-700">{p.name}</span>
                <span className="whitespace-nowrap font-bold text-rose-600">{p.stock - p.reserved} left</span>
              </div>
            ))}
          </div>
          {isSuper && statesWithoutAdmin.length > 0 && (
            <div className="admin-card">
              <h2 className="mb-1 text-sm font-bold text-ink-800">States without an administrator ({statesWithoutAdmin.length})</h2>
              <p className="mb-2 text-[10px] text-ink-400">Orders to these states enter the unassigned queue and notify only the super admin.</p>
              <div className="flex flex-wrap gap-1">
                {statesWithoutAdmin.map((s) => (
                  <Link key={s.id} href="/admin/admins" className="rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-semibold text-amber-700 ring-1 ring-amber-200">
                    {s.name}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="admin-card">
        <h2 className="mb-2 text-sm font-bold text-ink-800">Order pipeline</h2>
        <div className="flex flex-wrap gap-1.5">
          {pipeline.map(({ st, c }) => (
              <Link key={st} href={`/admin/orders?status=${st}`} className="flex min-w-[110px] flex-1 flex-col rounded-lg border border-gray-200 p-2 hover:border-obah-300">
                <span className="text-[10px] uppercase tracking-wide text-ink-400">{STATUS_LABEL[st]}</span>
                <span className="text-lg font-extrabold text-ink-800">{c}</span>
              </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
