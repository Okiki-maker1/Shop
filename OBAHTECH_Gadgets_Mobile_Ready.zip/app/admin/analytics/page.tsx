import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { BarChart, Stat } from '@/components/ui';
import { NGN, NGNcompact } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function AdminAnalytics({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const isSuper = user.role === 'super_admin';
  const scope = isSuper ? '' : `AND o.state_id = ${Number(user.admin_state_id ?? 0)}`;
  const from = searchParams.from || '';
  const to = searchParams.to || '';
  const dateSql = `${from ? `AND o.created_at >= '${from} 00:00:00'` : ''}${to ? `AND o.created_at <= '${to} 23:59:59'` : ''}`;

  const sum = async (sql: string) => (await db.prepare(sql).get() as any)?.v ?? 0;
  const revenue = await sum(`SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} ${dateSql}`);
  const todayRevenue = await sum(`SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} AND date(o.created_at) = date('now')`);
  const weekRevenue = await sum(`SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} AND o.created_at >= datetime('now','-7 days')`);
  const monthRevenue = await sum(`SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} AND o.created_at >= datetime('now','-30 days')`);
  const yearRevenue = await sum(`SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} AND o.created_at >= datetime('now','-365 days')`);
  const ordersCount = await sum(`SELECT COUNT(*) v FROM orders o WHERE 1=1 ${scope} ${dateSql}`);
  const customers = isSuper
    ?await  sum("SELECT COUNT(*) v FROM users WHERE role='customer'")
    :await  sum(`SELECT COUNT(*) v FROM users WHERE role='customer' AND state_id=${Number(user.admin_state_id ?? 0)}`);
  const refunded = await sum(`SELECT COALESCE(SUM(amount),0) v FROM refunds r JOIN orders o ON o.id=r.order_id WHERE r.status='completed' ${scope}`);
  const cancelled = await sum(`SELECT COUNT(*) v FROM orders o WHERE status='cancelled' ${scope}`);
  const returned = await sum(`SELECT COUNT(*) v FROM orders o WHERE status IN ('return_requested','returned','refund_pending','refunded') ${scope}`);
  const failedPay = await sum(`SELECT COUNT(*) v FROM orders o WHERE payment_status='failed' ${scope}`);

  const monthly: { label: string; value: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i, 1);
    const key = d.toISOString().slice(0, 7);
    const v = await sum(`SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} AND substr(o.created_at,1,7) = '${key}'`);
    monthly.push({ label: d.toLocaleDateString('en-NG', { month: 'short' }), value: v });
  }
  const daily: { label: string; value: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5);
    const key = d.toISOString().slice(0, 10);
    const v = await sum(`SELECT COALESCE(SUM(total),0) v FROM orders o WHERE payment_status='paid' ${scope} AND substr(o.created_at,1,10) = '${key}'`);
    daily.push({ label: String(d.getDate()), value: v });
  }

  const bestSellers = await db
    .prepare(
      `SELECT oi.name, SUM(oi.qty) units, SUM(oi.line_total) revenue
         FROM order_items oi JOIN orders o ON o.id = oi.order_id
        WHERE o.payment_status='paid' ${scope} GROUP BY oi.product_id, oi.name ORDER BY revenue DESC LIMIT 8`,
    )
    .all() as any[];
  const categories = await db
    .prepare(
      `SELECT c.name, SUM(oi.qty) units, SUM(oi.line_total) revenue
         FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN products p ON p.id = oi.product_id
         JOIN categories c ON c.id = p.category_id
        WHERE o.payment_status='paid' ${scope} GROUP BY c.id ORDER BY revenue DESC LIMIT 8`,
    )
    .all() as any[];
  const byState = isSuper
    ? (await db
        .prepare(
          `SELECT s.name, COUNT(o.id) orders, COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.total ELSE 0 END),0) revenue
             FROM orders o JOIN states s ON s.id=o.state_id GROUP BY s.id ORDER BY revenue DESC LIMIT 12`,
        )
        .all() as any[])
    : (await db
        .prepare(
          `SELECT l.name, COUNT(o.id) orders, COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.total ELSE 0 END),0) revenue
             FROM orders o JOIN lgas l ON l.id=o.lga_id WHERE o.state_id=? GROUP BY l.id ORDER BY revenue DESC LIMIT 12`,
        )
        .all(user.admin_state_id) as any[]);
  const performers = isSuper
    ? (await db
        .prepare(
          `SELECT u.full_name, s.name AS state_name,
                  COUNT(o.id) orders,
                  SUM(CASE WHEN o.status='delivered' THEN 1 ELSE 0 END) delivered,
                  SUM(CASE WHEN o.status='cancelled' THEN 1 ELSE 0 END) cancelled,
                  COALESCE(SUM(CASE WHEN o.payment_status='paid' THEN o.total ELSE 0 END),0) revenue
             FROM users u LEFT JOIN orders o ON o.assigned_admin_id = u.id LEFT JOIN states s ON s.id = u.admin_state_id
            WHERE u.role='state_admin' GROUP BY u.id, s.name ORDER BY revenue DESC`,
        )
        .all() as any[])
    : [];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-xl font-extrabold text-ink-800">{isSuper ? 'Business analytics — nationwide' : `${user.state_name} analytics`}</h1>
          <p className="text-[11px] text-ink-400">{isSuper ? 'All 36 states and FCT' : 'Restricted to your authorised state and LGAs'}</p>
        </div>
        <form method="GET" className="flex flex-wrap items-end gap-1.5">
          <div><label className="label">From</label><input type="date" name="from" defaultValue={from} className="input py-1.5 text-xs" /></div>
          <div><label className="label">To</label><input type="date" name="to" defaultValue={to} className="input py-1.5 text-xs" /></div>
          <button className="btn-dark btn-sm">Apply</button>
          <Link href={`/api/admin/report?type=sales&from=${from}&to=${to}`} className="btn-outline btn-sm">⬇ Sales CSV</Link>
          <Link href={`/api/admin/report?type=products`} className="btn-outline btn-sm">⬇ Products CSV</Link>
        </form>
      </div>

      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Total revenue (paid)" value={NGN(revenue)} tone="text-emerald-600" />
        <Stat label="Today" value={NGN(todayRevenue)} hint="paid orders" />
        <Stat label="Last 7 days" value={NGN(weekRevenue)} />
        <Stat label="Last 30 days" value={NGN(monthRevenue)} />
        <Stat label="Last 12 months" value={NGN(yearRevenue)} />
        <Stat label="Orders" value={ordersCount} hint={`${cancelled} cancelled`} />
        <Stat label="Customers" value={customers} />
        <Stat label="Refunded" value={NGN(refunded)} tone="text-rose-600" hint={`${returned} return-related orders`} />
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <div className="admin-card">
          <h2 className="mb-2 text-sm font-bold text-ink-800">Daily revenue (14 days)</h2>
          <BarChart data={daily} />
        </div>
        <div className="admin-card">
          <h2 className="mb-2 text-sm font-bold text-ink-800">Monthly revenue (6 months)</h2>
          <BarChart data={monthly} height={160} />
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <div className="admin-card overflow-hidden p-0">
          <div className="border-b border-gray-100 px-3 py-2"><h2 className="text-sm font-bold text-ink-800">Best-selling products</h2></div>
          <table className="table-obah">
            <thead><tr><th>Product</th><th>Units</th><th>Revenue</th></tr></thead>
            <tbody>
              {bestSellers.map((b) => (
                <tr key={b.name}><td className="text-[11px]">{b.name}</td><td className="text-[11px]">{b.units}</td><td className="text-[11px] font-bold">{NGN(b.revenue)}</td></tr>
              ))}
              {bestSellers.length === 0 && <tr><td colSpan={3} className="py-4 text-center text-[11px] text-ink-400">No paid orders yet.</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="admin-card overflow-hidden p-0">
          <div className="border-b border-gray-100 px-3 py-2"><h2 className="text-sm font-bold text-ink-800">Top categories</h2></div>
          <table className="table-obah">
            <thead><tr><th>Category</th><th>Units</th><th>Revenue</th></tr></thead>
            <tbody>
              {categories.map((c) => (
                <tr key={c.name}><td className="text-[11px]">{c.name}</td><td className="text-[11px]">{c.units}</td><td className="text-[11px] font-bold">{NGN(c.revenue)}</td></tr>
              ))}
              {categories.length === 0 && <tr><td colSpan={3} className="py-4 text-center text-[11px] text-ink-400">No data yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <div className="admin-card overflow-hidden p-0">
          <div className="border-b border-gray-100 px-3 py-2"><h2 className="text-sm font-bold text-ink-800">{isSuper ? 'Sales by state' : 'Sales by LGA'}</h2></div>
          <table className="table-obah">
            <thead><tr><th>{isSuper ? 'State' : 'LGA'}</th><th>Orders</th><th>Revenue</th></tr></thead>
            <tbody>
              {byState.map((s) => (
                <tr key={s.name}><td className="text-[11px]">{s.name}</td><td className="text-[11px]">{s.orders}</td><td className="text-[11px] font-bold">{NGN(s.revenue)}</td></tr>
              ))}
              {byState.length === 0 && <tr><td colSpan={3} className="py-4 text-center text-[11px] text-ink-400">No sales yet.</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="admin-card overflow-hidden p-0">
          <div className="border-b border-gray-100 px-3 py-2"><h2 className="text-sm font-bold text-ink-800">Payment & exception stats</h2></div>
          <div className="grid grid-cols-2 gap-2 p-3 text-[11px]">
            <div className="rounded bg-emerald-50 p-2"><p className="font-bold text-emerald-800">{await sum(`SELECT COUNT(*) v FROM orders o WHERE payment_status='paid' ${scope}`)}</p><p>Successful payments</p></div>
            <div className="rounded bg-rose-50 p-2"><p className="font-bold text-rose-800">{failedPay}</p><p>Failed payments</p></div>
            <div className="rounded bg-amber-50 p-2"><p className="font-bold text-amber-800">{cancelled}</p><p>Cancellations</p></div>
            <div className="rounded bg-sky-50 p-2"><p className="font-bold text-sky-800">{returned}</p><p>Returns / refunds</p></div>
            <div className="rounded bg-violet-50 p-2"><p className="font-bold text-violet-800">{await sum(`SELECT COUNT(*) v FROM warranty_claims wc JOIN orders o ON o.id=wc.order_id WHERE 1=1 ${scope}`)}</p><p>Warranty claims</p></div>
            <div className="rounded bg-gray-50 p-2"><p className="font-bold text-ink-800">{NGNcompact(Math.round(revenue / Math.max(1, ordersCount)))}</p><p>Avg. order value</p></div>
          </div>
        </div>
      </div>

      {isSuper && (
        <div className="admin-card overflow-hidden p-0">
          <div className="border-b border-gray-100 px-3 py-2"><h2 className="text-sm font-bold text-ink-800">Administrator performance</h2></div>
          <div className="overflow-x-auto">
            <table className="table-obah">
              <thead><tr><th>Administrator</th><th>State</th><th>Orders</th><th>Delivered</th><th>Cancelled</th><th>Revenue</th><th>Fulfilment rate</th></tr></thead>
              <tbody>
                {performers.map((p) => {
                  const rate = p.orders ? Math.round((p.delivered / p.orders) * 100) : 0;
                  return (
                    <tr key={p.full_name + p.state_name}>
                      <td className="text-[11px] font-semibold">{p.full_name}</td>
                      <td className="text-[11px]">{p.state_name}</td>
                      <td className="text-[11px]">{p.orders}</td>
                      <td className="text-[11px] text-emerald-700">{p.delivered}</td>
                      <td className="text-[11px] text-rose-600">{p.cancelled}</td>
                      <td className="text-[11px] font-bold">{NGN(p.revenue)}</td>
                      <td className="text-[11px]">
                        <div className="flex items-center gap-1">
                          <div className="h-1.5 w-16 rounded bg-gray-100"><div className="h-1.5 rounded bg-obah-500" style={{ width: `${rate}%` }} /></div>
                          {rate}%
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
