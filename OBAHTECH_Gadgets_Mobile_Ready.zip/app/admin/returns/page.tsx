import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { NGN, fmtDateTime } from '@/lib/format';
import { adminDecideReturn, adminCompleteRefund } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminReturns({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const scope = user.role === 'super_admin' ? '' : `AND o.state_id = ${Number(user.admin_state_id ?? 0)}`;
  const returns = await db
    .prepare(
      `SELECT rr.*, o.order_number, o.total, o.state_id, o.customer_name, s.name AS state_name, l.name AS lga_name,
              oi.name AS item_name, oi.image AS item_image
         FROM return_requests rr JOIN orders o ON o.id = rr.order_id
         JOIN states s ON s.id = o.state_id JOIN lgas l ON l.id = o.lga_id
         LEFT JOIN order_items oi ON oi.id = rr.order_item_id
        WHERE 1=1 ${scope} ORDER BY rr.id DESC`,
    )
    .all() as any[];
  const refunds = await db
    .prepare(
      `SELECT r.*, o.order_number, o.state_id, s.name AS state_name
         FROM refunds r JOIN orders o ON o.id = r.order_id JOIN states s ON s.id = o.state_id
        WHERE 1=1 ${scope} ORDER BY r.id DESC`,
    )
    .all() as any[];

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Returns & refunds</h1>
        <p className="text-[11px] text-ink-400">
          {user.role === 'super_admin' ? 'Nationwide' : `${user.state_name} only`} · review within policy. Refunds are never automatic
          — every decision is recorded and both the assigned administrator and super admin are notified.
        </p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <div className="space-y-2">
        {returns.length === 0 && <div className="admin-card text-[11px] text-ink-400">No return requests.</div>}
        {returns.map((r) => (
          <div key={r.id} className="admin-card">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="flex gap-2">
                {r.item_image && <img src={r.item_image} alt="" className="h-14 w-14 rounded bg-[#f7f8fa] object-contain" />}
                <div>
                  <p className="text-[12px] font-bold text-ink-800">Return #{r.id} · {r.reason}</p>
                  <p className="text-[11px] text-ink-500">{r.item_name || 'Order item'} — {r.customer_name}</p>
                  <p className="text-[10px] text-ink-400">
                    <Link href={`/admin/orders/${r.order_id}`} className="font-semibold text-obah-600">{r.order_number}</Link> · {r.lga_name}, {r.state_name} · {fmtDateTime(r.created_at)}
                  </p>
                  {r.explanation && <p className="mt-1 max-w-xl text-[11px] text-ink-600">{r.explanation}</p>}
                  {r.photos && <p className="text-[10px] text-ink-400">Evidence: {r.photos}</p>}
                </div>
              </div>
              <div className="text-right">
                <span className="chip bg-amber-50 text-amber-700 ring-amber-200">{r.status.replace(/_/g, ' ')}</span>
                <p className="mt-1 text-[11px] font-bold text-ink-800">Order total {NGN(r.total)}</p>
              </div>
            </div>
            {['requested'].includes(r.status) && (
              <form action={adminDecideReturn} className="mt-2 flex flex-wrap items-end gap-1.5 border-t border-gray-100 pt-2">
                <input type="hidden" name="return_id" value={r.id} />
                <div>
                  <label className="label">Decision</label>
                  <select name="decision" className="input w-auto py-1.5 text-xs">
                    <option value="approved">Approve return</option>
                    <option value="rejected">Reject return</option>
                  </select>
                </div>
                <div>
                  <label className="label">Refund amount (₦)</label>
                  <input name="refund_amount" type="number" min="0" defaultValue={r.total} className="input w-32 py-1.5 text-xs" />
                </div>
                <input name="admin_note" placeholder="Note to customer" className="input flex-1 py-1.5 text-xs" />
                <button className="btn-primary btn-sm">Save decision</button>
              </form>
            )}
            {r.admin_note && <p className="mt-1 rounded bg-gray-50 p-1.5 text-[10px] text-ink-500">Note: {r.admin_note}</p>}
          </div>
        ))}
      </div>

      <div className="admin-card overflow-hidden p-0">
        <div className="border-b border-gray-100 px-3 py-2">
          <h2 className="text-sm font-bold text-ink-800">Refund records</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="table-obah">
            <thead><tr><th>Refund</th><th>Order</th><th>State</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {refunds.map((r) => (
                <tr key={r.id}>
                  <td className="text-[11px] font-bold">#{r.id}<div className="text-[10px] font-normal text-ink-400">{r.reason}</div></td>
                  <td className="text-[11px]"><Link href={`/admin/orders/${r.order_id}`} className="text-obah-600">{r.order_number}</Link></td>
                  <td className="text-[11px]">{r.state_name}</td>
                  <td className="text-[11px] font-bold">{NGN(r.amount)}</td>
                  <td><span className={`chip ${r.status === 'completed' ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-amber-50 text-amber-700 ring-amber-200'}`}>{r.status}</span></td>
                  <td>
                    {r.status !== 'completed' ? (
                      <form action={adminCompleteRefund} className="flex gap-1">
                        <input type="hidden" name="refund_id" value={r.id} />
                        <input name="gateway_ref" placeholder="Flutterwave refund ref" className="input w-40 py-1 text-[11px]" />
                        <button className="btn-primary btn-sm">Record refund</button>
                      </form>
                    ) : (
                      <span className="text-[10px] text-ink-400">{r.gateway_ref}</span>
                    )}
                  </td>
                </tr>
              ))}
              {refunds.length === 0 && <tr><td colSpan={6} className="py-6 text-center text-[11px] text-ink-400">No refunds recorded.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
