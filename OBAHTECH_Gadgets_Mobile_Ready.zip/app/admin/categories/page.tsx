import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { adminSaveCategory, adminDeleteCategory, adminReorderCategory } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminCategories({ searchParams }: { searchParams: Record<string, string> }) {
  await requireSuperAdminPage();
  const db = getDb();
  const rows = await db
    .prepare(
      `SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) products
         FROM categories c ORDER BY c.sort_order, c.name`,
    )
    .all() as any[];
  const editing = searchParams.edit ? (await db.prepare('SELECT * FROM categories WHERE id = ?').get(Number(searchParams.edit)) as any) : null;

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Categories</h1>
        <p className="text-[11px] text-ink-400">Create, reorder, edit and delete storefront categories.</p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <form action={adminSaveCategory} className="admin-card grid gap-2 sm:grid-cols-5">
        {editing && <input type="hidden" name="id" value={editing.id} />}
        <div className="sm:col-span-2">
          <label className="label">{editing ? 'Edit category name' : 'New category name'}</label>
          <input name="name" defaultValue={editing?.name} required className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Group</label>
          <input name="group_name" defaultValue={editing?.group_name || 'Accessories'} className="input py-1.5 text-xs" />
        </div>
        <div>
          <label className="label">Sort order</label>
          <input name="sort_order" type="number" defaultValue={editing?.sort_order ?? rows.length} className="input py-1.5 text-xs" />
        </div>
        <div className="flex items-end gap-2">
          <label className="flex items-center gap-1 text-[11px] font-semibold"><input type="checkbox" name="is_active" defaultChecked={editing ? Boolean(editing.is_active) : true} /> Active</label>
          <button className="btn-primary btn-sm">{editing ? 'Save' : 'Add'}</button>
        </div>
      </form>

      <div className="admin-card overflow-hidden p-0">
        <table className="table-obah">
          <thead><tr><th>#</th><th>Category</th><th>Group</th><th>Products</th><th>Status</th><th>Reorder</th><th>Actions</th></tr></thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c.id} className="hover:bg-gray-50">
                <td className="text-[11px] text-ink-400">{c.sort_order}</td>
                <td className="text-[11px] font-bold text-ink-800"><Link href={`/category/${c.slug}`} className="hover:text-obah-600">{c.name}</Link></td>
                <td className="text-[11px]">{c.group_name}</td>
                <td className="text-[11px]">{c.products}</td>
                <td>
                  <span className={`chip ${c.is_active ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-gray-100 text-gray-600 ring-gray-200'}`}>{c.is_active ? 'Active' : 'Hidden'}</span>
                </td>
                <td>
                  <div className="flex gap-1">
                    <form action={adminReorderCategory}>
                      <input type="hidden" name="id" value={c.id} />
                      <input type="hidden" name="dir" value="up" />
                      <button className="btn-outline btn-sm">↑</button>
                    </form>
                    <form action={adminReorderCategory}>
                      <input type="hidden" name="id" value={c.id} />
                      <input type="hidden" name="dir" value="down" />
                      <button className="btn-outline btn-sm">↓</button>
                    </form>
                  </div>
                </td>
                <td>
                  <div className="flex gap-1">
                    <Link href={`/admin/categories?edit=${c.id}`} className="btn-outline btn-sm">Edit</Link>
                    <form action={adminDeleteCategory}>
                      <input type="hidden" name="id" value={c.id} />
                      <button className="btn-outline btn-sm text-rose-600">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
