import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { Logo } from '@/components/ui';
import { NotificationBell } from '@/components/NotificationBell';
import { logoutAction } from '@/lib/actions/auth';
import {
  IconGrid, IconBox, IconReturn, IconShield, IconHeadset, IconCart, IconTag, IconChart,
  IconImage, IconBadge, IconTruck, IconBell, IconUsers, IconWallet,
} from '@/components/icons';

export const dynamic = 'force-dynamic';

const NAV: { href: string; label: string; icon: any; superOnly?: boolean }[] = [
  { href: '/admin', label: 'Overview', icon: IconGrid },
  { href: '/admin/orders', label: 'Orders', icon: IconBox },
  { href: '/admin/returns', label: 'Returns & refunds', icon: IconReturn },
  { href: '/admin/warranties', label: 'Warranty claims', icon: IconShield },
  { href: '/admin/tickets', label: 'Support tickets', icon: IconHeadset },
  { href: '/admin/products', label: 'Products', icon: IconCart, superOnly: true },
  { href: '/admin/categories', label: 'Categories', icon: IconTag, superOnly: true },
  { href: '/admin/inventory', label: 'Inventory', icon: IconChart, superOnly: true },
  { href: '/admin/banners', label: 'Banners', icon: IconImage, superOnly: true },
  { href: '/admin/promotions', label: 'Discount codes', icon: IconBadge, superOnly: true },
  { href: '/admin/delivery', label: 'Delivery fees', icon: IconTruck, superOnly: true },
  { href: '/admin/notifications', label: 'Notifications', icon: IconBell },
  { href: '/admin/customers', label: 'Customers', icon: IconUsers, superOnly: true },
  { href: '/admin/admins', label: 'Administrators', icon: IconWallet, superOnly: true },
  { href: '/admin/analytics', label: 'Analytics', icon: IconChart },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/admin');
  if (user.role === 'customer') redirect('/account?error=' + encodeURIComponent('Administrator access required.'));
  if (user.is_suspended) redirect('/login?error=' + encodeURIComponent('Your administrator account is suspended.'));
  const db = getDb();
  const unread = (await db.prepare('SELECT COUNT(*) c FROM notifications WHERE recipient_user_id = ? AND is_read = 0').get(user.id) as any).c;
  const pendingOrders = (
    await db
      .prepare(
        `SELECT COUNT(*) c FROM orders WHERE status IN ('pending_payment','payment_confirmed','order_confirmed','processing','packed','shipped','out_for_delivery')
          ${user.role === 'state_admin' ? 'AND state_id = ' + Number(user.admin_state_id ?? 0) : ''}`,
      )
      .get() as any
  ).c;
  const scopeLabel = user.role === 'super_admin' ? 'Nationwide · 36 states + FCT' : `${user.state_name || 'State'} only`;

  return (
    <div className="min-h-screen bg-[#f4f5f7]">
      <div className="bg-ink-800 text-white">
        <div className="container-obah flex h-11 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded bg-white px-1.5 py-0.5"><Logo size="sm" /></div>
            <span className="hidden rounded bg-white/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-obah-300 sm:inline">
              {user.role === 'super_admin' ? 'Super admin' : 'State admin'} · {scopeLabel}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/" className="hidden text-[11px] font-semibold text-white/70 hover:text-white sm:inline">View store ↗</Link>
            <NotificationBell initialRole={user.role} />
            <span className="hidden text-[11px] font-semibold text-white/80 md:inline">{user.full_name}</span>
            <form action={logoutAction}>
              <button className="rounded bg-white/10 px-2 py-1 text-[11px] font-semibold text-white hover:bg-white/20">Log out</button>
            </form>
          </div>
        </div>
      </div>

      <div className="container-obah grid gap-4 py-4 lg:grid-cols-[210px_1fr]">
        <aside className="lg:sticky lg:top-2 lg:self-start">
          {user.role === 'state_admin' && (
            <div className="mb-2 rounded-lg bg-obah-50 p-2 text-[10px] leading-relaxed text-obah-800 ring-1 ring-obah-200">
              You can only see orders, tickets and claims for <strong>{user.state_name}</strong>. Nationwide reports are restricted.
            </div>
          )}
          <nav className="no-scrollbar flex gap-1 overflow-x-auto rounded-xl bg-white p-1.5 shadow-card lg:flex-col lg:overflow-visible">
            {NAV.filter((item) => !item.superOnly || user.role === 'super_admin').map((item) => {
              const Icon = item.icon;
              return (
              <Link
                key={item.href}
                href={item.href}
                className="flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-[11px] font-semibold text-ink-600 hover:bg-obah-50 hover:text-obah-700 lg:text-xs"
              >
                <Icon size={14} />
                <span className="whitespace-nowrap">{item.label}</span>
                {item.href === '/admin/orders' && pendingOrders > 0 && (
                  <span className="ml-auto rounded-full bg-obah-500 px-1.5 text-[9px] font-bold text-white">{pendingOrders}</span>
                )}
                {item.href === '/admin/notifications' && unread > 0 && (
                  <span className="ml-auto rounded-full bg-rose-600 px-1.5 text-[9px] font-bold text-white">{unread}</span>
                )}
              </Link>
              );
            })}
          </nav>
        </aside>
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
