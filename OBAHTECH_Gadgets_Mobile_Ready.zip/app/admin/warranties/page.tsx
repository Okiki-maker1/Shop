import Link from 'next/link';
import { getDb } from '@/lib/db';
import { requireAdminPage } from '@/lib/auth';
import { Alert } from '@/components/ui';
import { fmtDate, fmtDateTime } from '@/lib/format';
import { adminUpdateClaim } from '@/lib/actions/admin';

export const dynamic = 'force-dynamic';

const STATUSES = ['submitted', 'under_review', 'info_needed', 'approved', 'rejected', 'repaired', 'replaced', 'closed'];

export default async function AdminWarranties({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await requireAdminPage();
  const db = getDb();
  const scope = user.role === 'super_admin' ? '' : `AND o.state_id = ${Number(user.admin_state_id ?? 0)}`;
  const claims = await db
    .prepare(
      `SELECT wc.*, w.product_name, w.serial_no, w.start_date, w.expiry_date, w.duration_months,
              o.order_number, o.customer_name, o.state_id, s.name AS state_name, u.full_name AS customer
         FROM warranty_claims wc JOIN warranties w ON w.id = wc.warranty_id JOIN orders o ON o.id = wc.order_id
         JOIN states s ON s.id = o.state_id LEFT JOIN users u ON u.id = wc.user_id
        WHERE 1=1 ${scope} ORDER BY wc.id DESC`,
    )
    .all() as any[];
  const warranties = await db
    .prepare(
      `SELECT w.*, o.order_number, s.name AS state_name FROM warranties w JOIN orders o ON o.id = w.order_id
        JOIN states s ON s.id = o.state_id WHERE 1=1 ${scope} ORDER BY w.id DESC LIMIT 20`,
    )
    .all() as any[];

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-xl font-extrabold text-ink-800">Warranty claims</h1>
        <p className="text-[11px] text-ink-400">
          {user.role === 'super_admin' ? 'Nationwide claims' : `${user.state_name} claims only`} · approve, reject, request information,
          record repairs or replacements. Every decision notifies the customer, the state administrator and the super admin.
        </p>
      </div>
      {searchParams.error && <Alert>{searchParams.error}</Alert>}
      {searchParams.ok && <Alert tone="success">{searchParams.ok}</Alert>}

      <div className="space-y-2">
        {claims.length === 0 && <div className="admin-card text-[11px] text-ink-400">No warranty claims.</div>}
        {claims.map((c) => (
          <div key={c.id} className="admin-card">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="text-[12px] font-bold text-ink-800">Claim #{c.id} — {c.product_name}</p>
                <p className="text-[11px] text-ink-500">{c.customer || c.customer_name} · <Link href={`/admin/orders/${c.order_id}`} className="text-obah-600">{c.order_number}</Link> · {c.state_name}</p>
                <p className="text-[10px] text-ink-400">
                  Warranty {fmtDate(c.start_date)} → {fmtDate(c.expiry_date)} ({c.duration_months} months){c.serial_no ? ` · IMEI ${c.serial_no}` : ''}
                </p>
                <p className="mt-1 max-w-2xl rounded bg-gray-50 p-1.5 text-[11px] text-ink-600">{c.issue}</p>
                {c.evidence_url && <p className="text-[10px] text-ink-400">Evidence: {c.evidence_url}</p>}
                {c.admin_note && <p className="text-[10px] text-ink-500">Last note: {c.admin_note}</p>}
              </div>
              <div className="text-right">
                <span className="chip bg-sky-50 text-sky-700 ring-sky-200">{c.status.replace(/_/g, ' ')}</span>
                <p className="text-[10px] text-ink-400">{fmtDateTime(c.created_at)}</p>
              </div>
            </div>
            <form action={adminUpdateClaim} className="mt-2 flex flex-wrap items-end gap-1.5 border-t border-gray-100 pt-2">
              <input type="hidden" name="claim_id" value={c.id} />
              <div>
                <label className="label">Update status</label>
                <select name="status" defaultValue={c.status} className="input w-auto py-1.5 text-xs">
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>
                  ))}
                </select>
              </div>
              <input name="admin_note" placeholder="Note to customer / resolution details" className="input flex-1 py-1.5 text-xs" />
              <button className="btn-primary btn-sm">Save & notify</button>
            </form>
          </div>
        ))}
      </div>

      <div className="admin-card overflow-hidden p-0">
        <div className="border-b border-gray-100 px-3 py-2">
          <h2 className="text-sm font-bold text-ink-800">Active warranty records</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="table-obah">
            <thead><tr><th>Product</th><th>Order</th><th>State</th><th>Period</th><th>Serial</th><th>Status</th></tr></thead>
            <tbody>
              {warranties.map((w) => (
                <tr key={w.id}>
                  <td className="text-[11px] font-semibold">{w.product_name}</td>
                  <td className="text-[11px]"><Link href={`/admin/orders/${w.order_id}`} className="text-obah-600">{w.order_number}</Link></td>
                  <td className="text-[11px]">{w.state_name}</td>
                  <td className="text-[10px]">{fmtDate(w.start_date)} → {fmtDate(w.expiry_date)}</td>
                  <td className="text-[10px]">{w.serial_no || '—'}</td>
                  <td><span className={`chip ${w.status === 'active' ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-gray-100 text-gray-600 ring-gray-200'}`}>{w.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
