import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { productBySlug, productImages, productReviews, productVariants, listProducts, wishlistIds } from '@/lib/queries';
import { ProductCard } from '@/components/ProductCard';
import { Stars, Alert, SectionHeader, Price } from '@/components/ui';
import { NGN, fmtDate } from '@/lib/format';
import { addToCartAction } from '@/lib/actions/cart';
import { submitReview } from '@/lib/actions/customer';
import { addToCompare } from '@/lib/actions/compare';
import { deliveryFeeFor } from '@/lib/orders';
import { IconShield, IconTruck, IconReturn, IconLock, IconCart, IconHeart } from '@/components/icons';

export const dynamic = 'force-dynamic';

export default async function ProductPage({ params, searchParams }: { params: { slug: string }; searchParams: Record<string, string> }) {
  const p = await productBySlug(params.slug);
  if (!p) notFound();
  const db = getDb();
  const images = await productImages(p.id);
  const variants = await productVariants(p.id);
  const reviews = await productReviews(p.id);
  const user = await getSessionUser();
  const wished = await wishlistIds(user?.id);
  const imgIdx = Math.min(images.length - 1, Math.max(0, Number(searchParams.img || 0)));
  const main = images[imgIdx]?.url || p.image;
  const colors: string[] = JSON.parse(p.color_options || '[]');
  const storages: string[] = JSON.parse(p.storage_options || '[]');
  const specs = JSON.parse(p.specs || '{}') as Record<string, string>;
  const available = p.stock - p.reserved;
  const eff = p.is_flash_sale && p.flash_price ? p.flash_price : p.price;
  const related = (await listProducts({ category: p.category_slug, perPage: 6, sort: 'popular' })).items.filter((x) => x.id !== p.id).slice(0, 5);
  const fee = user?.state_id ?await  deliveryFeeFor(user.state_id, user.lga_id, 'standard', eff) : { fee: 2500, eta: 2 };
  const purchased = user
    ? await db
        .prepare(
          `SELECT o.id FROM orders o JOIN order_items oi ON oi.order_id = o.id
            WHERE o.user_id = ? AND oi.product_id = ? AND o.status = 'delivered' LIMIT 1`,
        )
        .get(user.id, p.id)
    : null;

  return (
    <div className="container-obah py-4">
      <nav className="mb-3 flex flex-wrap items-center gap-1 text-[11px] text-ink-400">
        <Link href="/" className="hover:text-obah-600">Home</Link>
        <span>/</span>
        <Link href={`/category/${p.category_slug}`} className="hover:text-obah-600">{p.category_name}</Link>
        <span>/</span>
        <span className="truncate font-semibold text-ink-700">{p.name}</span>
      </nav>

      {searchParams.review === '1' && <div className="mb-3"><Alert tone="success">Thank you — your review has been published.</Alert></div>}
      {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}

      <div className="grid gap-4 lg:grid-cols-[420px_1fr]">
        {/* GALLERY */}
        <div className="card p-3">
          <div className="overflow-hidden rounded-lg bg-[#f7f8fa]">
            <img src={main!} alt={p.name} className="mx-auto aspect-square w-full max-w-[380px] object-contain p-4" />
          </div>
          <div className="mt-2 flex gap-2">
            {images.map((im, i) => (
              <Link key={im.id} href={`/product/${p.slug}?img=${i}`} className={`overflow-hidden rounded-lg ring-2 ${i === imgIdx ? 'ring-obah-500' : 'ring-gray-100 hover:ring-obah-200'}`}>
                <img src={im.url} alt={im.alt || p.name} className="h-14 w-14 bg-[#f7f8fa] object-contain p-1" />
              </Link>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
            <div className="rounded-lg bg-emerald-50 p-2">
              <p className="flex items-center gap-1 font-bold text-emerald-800"><IconShield size={13} /> {p.warranty_months}-month warranty</p>
              <p className="text-emerald-700">Manufacturing defects covered</p>
            </div>
            <div className="rounded-lg bg-sky-50 p-2">
              <p className="flex items-center gap-1 font-bold text-sky-800"><IconTruck size={13} /> Delivery {fee.eta} day{fee.eta > 1 ? 's' : ''}</p>
              <p className="text-sky-700">Fee from {NGN(fee.fee)}</p>
            </div>
            <div className="rounded-lg bg-amber-50 p-2">
              <p className="flex items-center gap-1 font-bold text-amber-800"><IconReturn size={13} /> 7-day returns</p>
              <p className="text-amber-700">After delivery, on eligible items</p>
            </div>
            <div className="rounded-lg bg-gray-50 p-2">
              <p className="flex items-center gap-1 font-bold text-ink-800"><IconLock size={13} /> Secure payment</p>
              <p className="text-ink-500">Flutterwave · NGN</p>
            </div>
          </div>
        </div>

        {/* BUY BOX */}
        <div className="card p-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded bg-obah-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-obah-700">{p.brand}</span>
            {p.is_flash_sale && <span className="rounded bg-rose-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">Flash sale</span>}
            <span className="rounded bg-gray-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-ink-600">{p.condition}</span>
          </div>
          <h1 className="mt-1.5 text-xl font-extrabold leading-tight text-ink-800 sm:text-2xl">{p.name}</h1>
          <div className="mt-1 flex flex-wrap items-center gap-3">
            <Stars rating={p.rating_avg} count={p.rating_count} />
            <span className="text-[11px] text-ink-400">SKU {p.sku}</span>
            <span className={`text-[11px] font-bold ${available > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              {available > 0 ? `In stock (${available} available)` : 'Out of stock'}
            </span>
          </div>

          <div className="mt-3 rounded-lg bg-gray-50 p-3">
            <Price price={eff} compare={p.is_flash_sale && p.flash_price ? p.price : p.compare_price} size="lg" />
            {p.is_flash_sale && p.flash_price && (
              <p className="mt-1 text-[11px] font-semibold text-rose-600">Flash price ends {fmtDate(p.flash_ends_at)}</p>
            )}
            <p className="mt-1 text-[11px] text-ink-400">Price includes VAT. Delivery calculated at checkout.</p>
          </div>

          <form action={addToCartAction} className="mt-4 space-y-3">
            <input type="hidden" name="product_id" value={p.id} />
            <input type="hidden" name="slug" value={p.slug} />
            <div className="grid gap-3 sm:grid-cols-2">
              {colors.length > 0 && (
                <div>
                  <label className="label">Colour</label>
                  <select name="color" className="input">
                    {colors.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              )}
              {storages.length > 0 && (
                <div>
                  <label className="label">Storage / variant</label>
                  <select name="storage" className="input">
                    {storages.map((s) => {
                      const v = variants.find((x) => x.storage === s);
                      return (
                        <option key={s} value={s}>
                          {s}{v && v.price !== p.price ? ` — ${NGN(v.price)}` : ''}
                        </option>
                      );
                    })}
                  </select>
                </div>
              )}
              <div>
                <label className="label">Quantity</label>
                <div className="flex items-center gap-2">
                  <input name="qty" type="number" min={1} max={Math.max(1, available)} defaultValue={1} className="input w-24" />
                  <span className="text-[11px] text-ink-400">max {Math.max(1, available)}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <button className="btn-primary flex-1 sm:flex-none" disabled={available <= 0}>
                <IconCart size={16} /> Add to cart
              </button>
              <Link href="/cart" className="btn-dark">Go to cart</Link>
            </div>
          </form>

          <div className="mt-2 flex flex-wrap gap-2">
            <form action={addToCompare}>
              <input type="hidden" name="product_id" value={p.id} />
              <button className="btn-outline btn-sm">⇄ Compare</button>
            </form>
            <Link href={user ? '/wishlist' : '/login?next=/wishlist'} className="btn-outline btn-sm">
              {wished.has(p.id) ? '♥ Saved to wishlist' : '♡ Save to wishlist'}
            </Link>
            <Link href="/support#contact" className="btn-outline btn-sm">Ask a question</Link>
          </div>

          <div className="mt-4 grid gap-2 rounded-lg border border-gray-100 p-3 text-[11px] sm:grid-cols-2">
            <p><span className="font-bold text-ink-700">Model:</span> {p.model}</p>
            <p><span className="font-bold text-ink-700">RAM:</span> {p.ram || '—'}</p>
            <p><span className="font-bold text-ink-700">Battery:</span> {p.battery || '—'}</p>
            <p><span className="font-bold text-ink-700">Screen:</span> {p.screen_size || '—'}</p>
            <p><span className="font-bold text-ink-700">Network:</span> {p.network || '—'}</p>
            <p><span className="font-bold text-ink-700">Serial tracking:</span> {p.tracks_serial ? 'IMEI recorded at dispatch' : 'Not applicable'}</p>
          </div>
        </div>
      </div>

      {/* DESCRIPTION + SPECS */}
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div className="card p-4">
          <h2 className="section-title mb-2">Product description</h2>
          <p className="text-sm leading-relaxed text-ink-500">{p.description}</p>
          <h3 className="mt-4 text-xs font-bold uppercase tracking-wide text-ink-800">Warranty & returns</h3>
          <p className="mt-1 text-xs leading-relaxed text-ink-500">{p.warranty_policy}</p>
          <p className="mt-2 text-xs leading-relaxed text-ink-500">
            Return window: 7 days from delivery for damaged, defective, missing or incorrect items. The return window is separate
            from the {p.warranty_months}-month warranty period.
          </p>
        </div>
        <div className="card p-4">
          <h2 className="section-title mb-2">Specifications</h2>
          <table className="w-full text-xs">
            <tbody>
              {Object.entries(specs).map(([k, v]) => (
                <tr key={k} className="border-b border-gray-100 last:border-0">
                  <td className="w-40 py-2 pr-3 font-semibold text-ink-500">{k}</td>
                  <td className="py-2 text-ink-700">{v}</td>
                </tr>
              ))}
              <tr className="border-b border-gray-100">
                <td className="py-2 pr-3 font-semibold text-ink-500">Colours</td>
                <td className="py-2 text-ink-700">{colors.join(', ')}</td>
              </tr>
              <tr>
                <td className="py-2 pr-3 font-semibold text-ink-500">Variants</td>
                <td className="py-2 text-ink-700">{storages.join(', ')}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* REVIEWS */}
      <div className="mt-4 card p-4" id="reviews">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="section-title">Customer reviews ({reviews.length})</h2>
          <Stars rating={p.rating_avg} count={p.rating_count} />
        </div>
        <div className="mt-3 grid gap-4 lg:grid-cols-[1fr_320px]">
          <div className="space-y-3">
            {reviews.length === 0 && <p className="text-sm text-ink-400">No reviews yet — be the first to review this product.</p>}
            {reviews.map((r) => (
              <div key={r.id} className="rounded-lg border border-gray-100 p-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold text-ink-800">{r.author}</p>
                  <Stars rating={r.rating} />
                </div>
                {r.title && <p className="mt-1 text-xs font-semibold text-obah-600">{r.title}</p>}
                <p className="mt-0.5 text-xs leading-relaxed text-ink-500">{r.body}</p>
                <p className="mt-1 text-[10px] text-ink-300">{fmtDate(r.created_at)}</p>
              </div>
            ))}
          </div>
          <div className="rounded-lg bg-gray-50 p-3">
            <p className="text-xs font-bold uppercase tracking-wide text-ink-800">Write a review</p>
            {purchased && <p className="mt-1 text-[10px] font-semibold text-emerald-600">✓ Verified purchase — you bought this item</p>}
            {user ? (
              <form action={submitReview} className="mt-2 space-y-2">
                <input type="hidden" name="product_id" value={p.id} />
                <input type="hidden" name="slug" value={p.slug} />
                <div>
                  <label className="label">Rating</label>
                  <select name="rating" className="input" defaultValue="5">
                    {[5, 4, 3, 2, 1].map((n) => (
                      <option key={n} value={n}>{'★'.repeat(n)} ({n})</option>
                    ))}
                  </select>
                </div>
                <input name="title" placeholder="Review title" className="input" maxLength={80} />
                <textarea name="body" rows={3} placeholder="Tell other customers about this product…" className="input" maxLength={600} />
                <button className="btn-primary w-full">Submit review</button>
              </form>
            ) : (
              <div className="mt-2 space-y-2">
                <p className="text-[11px] text-ink-500">Sign in to leave a review.</p>
                <Link href={`/login?next=/product/${p.slug}`} className="btn-primary w-full">Sign in</Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-6">
          <SectionHeader title="Similar products" href={`/category/${p.category_slug}`} />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {related.map((r) => (
              <ProductCard key={r.id} p={r as any} wished={wished.has(r.id)} compact />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
