import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { getCartLines, cartTotals, activePromo } from '@/lib/cart';
import { locationOptions } from '@/lib/locations.server';
import { LgaStateSelect } from '@/components/LgaStateSelect';
import { Alert } from '@/components/ui';
import { NGN, fmtDate } from '@/lib/format';
import { placeOrderAction } from '@/lib/actions/checkout';

export const metadata = { title: 'Checkout' };
export const dynamic = 'force-dynamic';

export default async function CheckoutPage({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/checkout');
  const db = getDb();
  const lines = await getCartLines(user.id);
  if (!lines.length) redirect('/cart');
  const addresses = await db.prepare('SELECT a.*, s.name AS state_name, l.name AS lga_name FROM addresses a JOIN states s ON s.id=a.state_id JOIN lgas l ON l.id=a.lga_id WHERE a.user_id = ? ORDER BY a.is_default DESC, a.id').all(user.id) as any[];
  const { states, lgas } = await locationOptions();
  const promo = await activePromo();
  const defaultAddr = addresses[0];
  const totals =await  cartTotals(lines, defaultAddr?.state_id ?? user.state_id, defaultAddr?.lga_id ?? user.lga_id, 'standard', promo);
  const eta = new Date(Date.now() + totals.eta * 864e5);

  return (
    <div className="container-obah py-4">
      <h1 className="mb-3 text-lg font-extrabold text-ink-800">Checkout</h1>
      {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}
      <form action={placeOrderAction}>
        <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
          <div className="space-y-3">
            {/* Contact */}
            <section className="card p-4">
              <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">1. Contact details</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="label">Full name</label>
                  <input name="full_name" defaultValue={user.full_name} required className="input" />
                </div>
                <div>
                  <label className="label">Phone number</label>
                  <input name="phone" defaultValue={user.phone || ''} required className="input" placeholder="08031234567" />
                </div>
                <div className="sm:col-span-2">
                  <label className="label">Email address</label>
                  <input name="email" type="email" defaultValue={user.email} required className="input" />
                </div>
              </div>
            </section>

            {/* Address */}
            <section className="card p-4">
              <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">2. Delivery address</h2>
              {addresses.length > 0 && (
                <div className="mb-3 space-y-2">
                  {addresses.map((a) => (
                    <label key={a.id} className="flex cursor-pointer items-start gap-2 rounded-lg border border-gray-200 p-2.5 has-[:checked]:border-obah-500 has-[:checked]:bg-obah-50">
                      <input type="radio" name="address_id" value={a.id} defaultChecked={a.is_default === 1} className="mt-0.5" />
                      <span className="text-xs">
                        <span className="font-bold text-ink-800">{a.label} — {a.full_name}</span>
                        <span className="block text-ink-500">{a.street}</span>
                        <span className="block text-ink-400">{a.lga_name}, {a.state_name} · {a.phone}</span>
                      </span>
                    </label>
                  ))}
                  <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-gray-300 p-2.5 text-xs font-semibold text-ink-600 has-[:checked]:border-obah-500 has-[:checked]:bg-obah-50">
                    <input type="radio" name="address_id" value="0" defaultChecked={false} />
                    Use a different address (fill below)
                  </label>
                </div>
              )}
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-ink-500">
                  {addresses.length ? 'New address (used when “different address” is selected)' : 'Delivery address'}
                </p>
                <div className="space-y-3">
                  <LgaStateSelect states={states} lgas={lgas} defaultStateId={defaultAddr?.state_id ?? user.state_id} defaultLgaId={defaultAddr?.lga_id ?? user.lga_id} required={addresses.length === 0} />
                  <div>
                    <label className="label">Full street address</label>
                    <input name="street" placeholder="House number, street, landmark" className="input" />
                  </div>
                  <div>
                    <label className="label">Additional delivery instructions (optional)</label>
                    <input name="instructions" placeholder="e.g. Call when you reach the gate" className="input" />
                  </div>
                </div>
                <p className="mt-2 text-[10px] text-ink-400">
                  Deliveries are limited to Nigeria. The state and LGA on this order are stored with the order and never change, even
                  if you later update your profile address.
                </p>
              </div>
            </section>

            {/* Delivery method */}
            <section className="card p-4">
              <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">3. Delivery method</h2>
              <div className="grid gap-2 sm:grid-cols-3">
                {[
                  ['standard', 'Standard', '2–4 working days', NGN(totals.deliveryFee)],
                  ['express', 'Express', '1 working day', 'Fee at confirmation'],
                  ['pickup', 'Pick-up', 'Collect at our hub', 'Free'],
                ].map(([v, label, desc, price]) => (
                  <label key={v} className="cursor-pointer rounded-lg border border-gray-200 p-2.5 text-xs has-[:checked]:border-obah-500 has-[:checked]:bg-obah-50">
                    <input type="radio" name="delivery_method" value={v} defaultChecked={v === 'standard'} className="mr-1" />
                    <span className="font-bold text-ink-800">{label}</span>
                    <span className="block text-ink-400">{desc}</span>
                    <span className="block font-semibold text-obah-600">{price}</span>
                  </label>
                ))}
              </div>
            </section>

            <section className="card p-4">
              <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">4. Payment</h2>
              <div className="flex items-start gap-2 rounded-lg bg-gray-50 p-3 text-xs text-ink-600">
                <span className="text-base">💳</span>
                <div>
                  <p className="font-bold text-ink-800">Pay securely with Flutterwave</p>
                  <p className="mt-0.5">
                    Cards, bank transfer and USSD in Naira (₦). After placing the order you will be redirected to complete payment.
                    Your order is only marked paid after OBAHTECH verifies the transaction on the server.
                  </p>
                </div>
              </div>
            </section>
          </div>

          {/* Summary */}
          <div className="space-y-3">
            <div className="card p-4">
              <p className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Order summary ({totals.itemCount})</p>
              <div className="max-h-64 space-y-2 overflow-y-auto">
                {lines.map((l) => (
                  <div key={l.item_id} className="flex items-center gap-2">
                    <img src={l.image || ''} alt="" className="h-10 w-10 rounded bg-[#f7f8fa] object-contain" />
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-1 text-[11px] font-semibold text-ink-700">{l.name}</p>
                      <p className="text-[10px] text-ink-400">
                        {[l.color, l.storage].filter(Boolean).join(' · ')} × {l.qty}
                      </p>
                    </div>
                    <p className="text-[11px] font-bold">{NGN(l.line_total)}</p>
                  </div>
                ))}
              </div>
              <dl className="mt-3 space-y-1.5 border-t border-gray-100 pt-2 text-xs">
                <div className="flex justify-between"><dt className="text-ink-500">Subtotal</dt><dd className="font-semibold">{NGN(totals.subtotal)}</dd></div>
                {totals.discount > 0 && <div className="flex justify-between text-emerald-600"><dt>Discount {promo?.code}</dt><dd>−{NGN(totals.discount)}</dd></div>}
                <div className="flex justify-between"><dt className="text-ink-500">Delivery</dt><dd className="font-semibold">{totals.deliveryFee === 0 ? 'Free' : NGN(totals.deliveryFee)}</dd></div>
                <div className="flex justify-between border-t border-gray-100 pt-1.5 text-sm"><dt className="font-bold">Total to pay</dt><dd className="font-extrabold text-obah-600">{NGN(totals.total)}</dd></div>
              </dl>
              <p className="mt-2 text-[10px] text-ink-400">Estimated delivery: {fmtDate(eta.toISOString())}</p>
              <button className="btn-primary mt-3 w-full">Place order & pay</button>
              <p className="mt-2 text-center text-[10px] text-ink-400">
                By placing this order you agree to the OBAHTECH returns and warranty policies.
              </p>
            </div>
            <Link href="/cart" className="block text-center text-xs font-semibold text-ink-500 hover:text-obah-600">← Back to cart</Link>
          </div>
        </div>
      </form>
    </div>
  );
}
