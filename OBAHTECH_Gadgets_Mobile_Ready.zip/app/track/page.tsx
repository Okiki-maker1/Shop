import Link from 'next/link';
import { getDb } from '@/lib/db';
import { Alert, StatusBadge, PayBadge } from '@/components/ui';
import { fmtDate, fmtDateTime, STATUS_LABEL, TRACKING_STAGES } from '@/lib/format';

export const metadata = { title: 'Track your order' };
export const dynamic = 'force-dynamic';

export default async function TrackPage({ searchParams }: { searchParams: Record<string, string> }) {
  const number = (searchParams.order || '').trim();
  const email = (searchParams.email || '').trim().toLowerCase();
  const db = getDb();
  let order: any = null;
  let events: any[] = [];
  let delivery: any = null;
  if (number && email) {
    order = await db.prepare('SELECT o.*, s.name AS state_name, l.name AS lga_name FROM orders o JOIN states s ON s.id=o.state_id JOIN lgas l ON l.id=o.lga_id WHERE o.order_number = ? AND lower(o.email) = ?').get(number, email);
    if (order) {
      events = await db.prepare('SELECT * FROM order_events WHERE order_id = ? ORDER BY id').all(order.id) as any[];
      delivery = await db.prepare('SELECT * FROM deliveries WHERE order_id = ?').get(order.id);
    }
  }
  const stageIdx = order ? TRACKING_STAGES.indexOf(order.status) : -1;

  return (
    <div className="container-obah max-w-2xl py-8">
      <div className="card p-5">
        <h1 className="text-lg font-extrabold text-ink-800">Track your order</h1>
        <p className="mb-3 text-xs text-ink-400">Enter your order number and the email address used at checkout.</p>
        <form method="GET" className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
          <input name="order" defaultValue={number} placeholder="OBH-20260101-ABC12" required className="input" />
          <input name="email" type="email" defaultValue={email} placeholder="you@example.com" required className="input" />
          <button className="btn-primary">Track</button>
        </form>

        {number && email && !order && (
          <div className="mt-3"><Alert tone="error">No order found with those details. Check the order number and email address.</Alert></div>
        )}

        {order && (
          <div className="mt-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm font-extrabold text-ink-800">{order.order_number}</p>
                <p className="text-[11px] text-ink-400">{order.lga_name}, {order.state_name} · placed {fmtDate(order.created_at)}</p>
              </div>
              <div className="flex gap-1.5">
                <StatusBadge status={order.status} />
                <PayBadge status={order.payment_status} />
              </div>
            </div>
            <ol className="mt-3 flex flex-wrap gap-1.5">
              {TRACKING_STAGES.map((s, i) => (
                <li key={s} className={`flex-1 rounded-lg px-2 py-1.5 text-center text-[10px] font-bold ${stageIdx >= i && stageIdx >= 0 ? 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200' : 'bg-gray-50 text-ink-400 ring-1 ring-gray-100'}`}>
                  {STATUS_LABEL[s]}
                </li>
              ))}
            </ol>
            <div className="mt-3 grid gap-1 text-[11px] sm:grid-cols-2">
              <p><span className="text-ink-400">Tracking ref:</span> {delivery?.tracking_ref || order.tracking_ref}</p>
              <p><span className="text-ink-400">ETA:</span> {fmtDate(delivery?.eta_date)}</p>
              <p><span className="text-ink-400">Shipped:</span> {fmtDate(delivery?.shipped_at)}</p>
              <p><span className="text-ink-400">Delivered:</span> {fmtDate(delivery?.delivered_at)}</p>
            </div>
            <div className="mt-3 space-y-1.5">
              {events.map((e) => (
                <div key={e.id} className="flex gap-2 text-[11px]">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-obah-500" />
                  <span><span className="font-semibold text-ink-700">{STATUS_LABEL[e.status] || e.status}</span> — {e.note} <span className="text-ink-300">({fmtDateTime(e.created_at)})</span></span>
                </div>
              ))}
            </div>
            <Link href={`/orders/${order.order_number}`} className="btn-primary btn-sm mt-3">Open full order</Link>
          </div>
        )}
      </div>
    </div>
  );
}
