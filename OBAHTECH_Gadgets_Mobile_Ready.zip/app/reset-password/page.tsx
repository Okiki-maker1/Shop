import { Alert } from '@/components/ui';
import { resetPasswordAction } from '@/lib/actions/auth';

export const metadata = { title: 'Choose a new password' };

export default function ResetPasswordPage({ searchParams }: { searchParams: Record<string, string> }) {
  return (
    <div className="container-obah max-w-md py-10">
      <div className="card p-5">
        <h1 className="text-xl font-extrabold text-ink-800">Choose a new password</h1>
        <p className="mb-4 text-xs text-ink-400">Minimum 8 characters. All sessions will be signed out.</p>
        {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}
        <form action={resetPasswordAction} className="space-y-3">
          <input type="hidden" name="token" value={searchParams.token || ''} />
          <div>
            <label className="label" htmlFor="password">New password</label>
            <input id="password" name="password" type="password" required minLength={8} className="input" autoComplete="new-password" />
          </div>
          <div>
            <label className="label" htmlFor="confirm_password">Confirm password</label>
            <input id="confirm_password" name="confirm_password" type="password" required minLength={8} className="input" autoComplete="new-password" />
          </div>
          <button className="btn-primary w-full">Update password</button>
        </form>
      </div>
    </div>
  );
}
