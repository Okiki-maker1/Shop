import { getDb } from '@/lib/db';
import { Alert } from '@/components/ui';
import { setupSuperAdminAction } from '@/lib/actions/auth';

export const metadata = { title: 'Initial setup' };
export const dynamic = 'force-dynamic';

/**
 * One-time super administrator provisioning.
 * Locked automatically as soon as a super admin exists — there is no backdoor.
 */
export default async function SetupPage({ searchParams }: { searchParams: Record<string, string> }) {
  const db = getDb();
  const hasSuper = (await db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'super_admin'").get() as any).c > 0;
  return (
    <div className="container-obah max-w-lg py-10">
      <div className="card p-5">
        <h1 className="text-xl font-extrabold text-ink-800">Create the super administrator</h1>
        <p className="mb-4 text-xs text-ink-400">
          This form is available only while no super administrator exists. Afterwards it locks permanently.
        </p>
        {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}
        {hasSuper ? (
          <Alert tone="warn">
            Setup is locked — a super administrator already exists. Sign in at <a className="link" href="/login">/login</a>, or
            reset the password from the database if you are the owner.
          </Alert>
        ) : (
          <form action={setupSuperAdminAction} className="space-y-3">
            <div>
              <label className="label">Full name</label>
              <input name="full_name" required className="input" />
            </div>
            <div>
              <label className="label">Email</label>
              <input name="email" type="email" required className="input" />
            </div>
            <div>
              <label className="label">Phone</label>
              <input name="phone" required className="input" placeholder="08031234567" />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="label">Password (12+ chars)</label>
                <input name="password" type="password" required minLength={12} className="input" />
              </div>
              <div>
                <label className="label">Confirm password</label>
                <input name="confirm_password" type="password" required minLength={12} className="input" />
              </div>
            </div>
            {process.env.SETUP_KEY && (
              <div>
                <label className="label">Setup key (SETUP_KEY env)</label>
                <input name="setup_key" required className="input" />
              </div>
            )}
            <button className="btn-primary w-full">Create super administrator</button>
          </form>
        )}
      </div>
    </div>
  );
}
