import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Terms of service' };

const SECTIONS: [string, string[]][] = [
  [
    '1. About this marketplace',
    [
      'OBAHTECH Gadgets ("we", "us") sells genuine mobile phones, tablets and accessories to customers resident in the Federal Republic of Nigeria. Every price is quoted in Nigerian Naira (₦) and includes VAT where applicable.',
      'By creating an account, placing an order or using any part of this website you agree to these terms. If you do not agree, please do not use the service.',
    ],
  ],
  [
    '2. Accounts',
    [
      'You must give accurate personal details — full name, a reachable email address, a Nigerian phone number and a delivery address inside Nigeria. Orders with addresses outside Nigeria are rejected at checkout by the system.',
      'You are responsible for keeping your password confidential. Passwords are stored only as bcrypt hashes; we can never read or send you your existing password.',
      'One person, one account. We may suspend accounts used for fraud, repeated failed deliveries or abuse of the returns policy.',
    ],
  ],
  [
    '3. Orders and pricing',
    [
      'An order is a binding offer to buy once payment is confirmed. We verify every payment on our server with Flutterwave before an order is marked paid — a message in a browser claiming payment succeeded is never enough.',
      'If an item is priced in error, or stock is unavailable after your payment, we cancel the order and refund the exact amount paid to your original payment method.',
      'Stock is reserved atomically at checkout, so two customers can never buy the same last unit.',
    ],
  ],
  [
    '4. Delivery',
    [
      'Delivery windows shown at checkout are estimates in working days, computed from our published state and LGA rates. Deliveries are made to Nigerian addresses only, Monday to Saturday.',
      'Someone at the address must accept delivery. If a delivery fails because the address or phone number is wrong, the order is returned to us and any refund may exclude the delivery fee.',
    ],
  ],
  [
    '5. Warranty',
    [
      'New devices carry the manufacturer warranty listed on the product page (7 days, 30 days, 3, 6 or 12 months). Warranty records are created automatically the moment your order is marked delivered, using the serial number or IMEI on the item.',
      'Warranty does not cover physical damage, liquid damage, unauthorised repair or tampering with the IMEI/serial. Claims are reviewed by an administrator — never auto-approved.',
    ],
  ],
  [
    '6. Returns and refunds',
    [
      'You may request a return within 7 days of delivery if the item is defective, damaged in transit or materially different from its description. Attach photos when you submit the request.',
      'Approved refunds are paid back to the original payment channel. Refunds for bank transfers or card payments are processed through Flutterwave and typically settle within 5–10 business days, depending on your bank.',
      'Returns must include all accessories, packaging and the warranty card. Requests are reviewed by an administrator; submitting a request does not guarantee approval.',
    ],
  ],
  [
    '7. Prohibited conduct',
    [
      'Do not attempt to bypass authorisation, scrape the catalogue at volume, submit fraudulent payment references, upload malware in review or support attachments, or impersonate another customer, administrator or member of staff.',
      'We log administrative actions. Accounts that attack the platform are suspended and may be reported to law enforcement.',
    ],
  ],
  [
    '8. Liability',
    [
      'We are responsible for delivering what you paid for. We are not liable for indirect losses such as lost profit or lost opportunity, or for delays caused by events outside our control.',
      'Nothing in these terms removes statutory rights you have under the Federal Competition and Consumer Protection Act and other applicable Nigerian law.',
    ],
  ],
  [
    '9. Changes and governing law',
    [
      'We may update these terms; the version live on this page at the time of your order governs that order.',
      'These terms are governed by the laws of the Federal Republic of Nigeria, and disputes are subject to the jurisdiction of Nigerian courts.',
    ],
  ],
];

export default function TermsPage() {
  return (
    <div className="container-obah py-8">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-2xl font-extrabold text-ink-900">Terms of service</h1>
        <p className="mt-1 text-sm text-ink-500">Last updated 30 October 2026. Written for a Nigerian marketplace.</p>
        <div className="mt-6 space-y-6 rounded-xl border border-gray-200 bg-white p-6 shadow-card">
          {SECTIONS.map(([title, paras]) => (
            <section key={title}>
              <h2 className="text-sm font-extrabold uppercase tracking-wide text-ink-800">{title}</h2>
              {paras.map((p) => (
                <p key={p.slice(0, 24)} className="mt-2 text-sm leading-relaxed text-ink-600">
                  {p}
                </p>
              ))}
            </section>
          ))}
          <div className="rounded-lg bg-obah-50 p-4 text-sm text-ink-700">
            <p className="font-bold">Questions about these terms?</p>
            <p className="mt-1 text-[13px]">
              Email <a href="mailto:support@obahtech.ng" className="font-semibold text-obah-700 underline">support@obahtech.ng</a> or open a
              ticket from the <Link href="/support" className="font-semibold text-obah-700 underline">support centre</Link>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
