import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getSessionUser } from '@/lib/auth';
import { Alert, Logo } from '@/components/ui';
import { loginAction } from '@/lib/actions/auth';

export const metadata = { title: 'Sign in' };
export const dynamic = 'force-dynamic';

export default async function LoginPage({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (user && !searchParams.next) redirect(user.role === 'customer' ? '/account' : '/admin');
  return (
    <div className="container-obah grid max-w-4xl gap-6 py-8 lg:grid-cols-2">
      <div className="hidden flex-col justify-center rounded-2xl bg-gradient-to-br from-ink-800 to-slate-700 p-8 text-white lg:flex">
        <Logo size="lg" light />
        <h1 className="mt-6 text-2xl font-extrabold">Welcome back</h1>
        <p className="mt-2 text-sm text-white/80">Track orders, manage warranties and check out faster with your saved addresses.</p>
        <div className="mt-6 rounded-lg bg-white/10 p-3 text-[11px] leading-relaxed">
          <p className="font-bold uppercase tracking-wide text-obah-300">Demo accounts (dev seed)</p>
          <p className="mt-1">Customer — demo@obahtech.ng / Customer#2026</p>
          <p>Super admin — super@obahtech.ng / SuperAdmin#2026</p>
          <p>Lagos admin — lagos@obahtech.ng / StateAdmin#2026</p>
          <p>Rivers admin — rivers@obahtech.ng / StateAdmin#2026</p>
        </div>
      </div>
      <div className="card p-5">
        <h2 className="text-xl font-extrabold text-ink-800">Sign in</h2>
        <p className="mb-4 text-xs text-ink-400">New here? <Link href="/register" className="link">Create an account</Link></p>
        {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}
        {searchParams.message && <div className="mb-3"><Alert tone="success">{searchParams.message}</Alert></div>}
        {searchParams.registered && <div className="mb-3"><Alert tone="success">Account created. Please sign in.</Alert></div>}
        <form action={loginAction} className="space-y-3">
          <input type="hidden" name="next" value={searchParams.next || ''} />
          <div>
            <label className="label" htmlFor="email">Email address</label>
            <input id="email" name="email" type="email" required defaultValue={searchParams.email} className="input" autoComplete="email" />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" name="password" type="password" required className="input" autoComplete="current-password" />
          </div>
          <div className="flex items-center justify-between">
            <Link href="/forgot-password" className="text-[11px] font-semibold text-obah-600 hover:underline">Forgot password?</Link>
            <Link href="/setup" className="text-[11px] text-ink-400 hover:text-obah-600">First-time setup</Link>
          </div>
          <button className="btn-primary w-full">Sign in</button>
        </form>
      </div>
    </div>
  );
}
