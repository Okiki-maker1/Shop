import type { MetadataRoute } from 'next';

/** Android/iOS home-screen metadata for the OBAHTECH mobile shopping website. */
export default function manifest(): MetadataRoute.Manifest {
  return {
    id: '/',
    name: 'OBAHTECH Gadgets',
    short_name: 'OBAHTECH',
    description: 'Shop smartphones, tablets and accessories in Nigeria.',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    display_override: ['standalone', 'minimal-ui'],
    orientation: 'portrait-primary',
    background_color: '#ffffff',
    theme_color: '#ff7d0f',
    categories: ['shopping', 'electronics'],
    icons: [
      { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icons/icon-512-maskable.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };
}
