import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getSessionUser } from '@/lib/auth';
import { getCartLines, cartTotals, activePromo } from '@/lib/cart';
import { Alert, Empty } from '@/components/ui';
import { NGN } from '@/lib/format';
import { updateQtyAction, removeItemAction, applyPromoAction, clearPromoAction } from '@/lib/actions/cart';

export const metadata = { title: 'Shopping cart' };
export const dynamic = 'force-dynamic';

export default async function CartPage({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/cart');
  const lines = await getCartLines(user.id);
  const promo = await activePromo();
  const totals =await  cartTotals(lines, user.state_id, user.lga_id, 'standard', promo);

  if (!lines.length) {
    return (
      <div className="container-obah py-6">
        <Empty
          title="Your cart is empty"
          hint="Browse our latest phones and accessories and add something you love."
          action={<Link href="/category/all" className="btn-primary mt-2">Start shopping</Link>}
        />
      </div>
    );
  }

  return (
    <div className="container-obah py-4">
      <h1 className="mb-3 text-lg font-extrabold text-ink-800">Shopping cart ({totals.itemCount} item{totals.itemCount > 1 ? 's' : ''})</h1>
      {searchParams.added && <div className="mb-3"><Alert tone="success">Item added to your cart.</Alert></div>}
      {searchParams.promo && <div className="mb-3"><Alert tone="success">Discount code applied.</Alert></div>}
      {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="space-y-2">
          {lines.map((l) => (
            <div key={l.item_id} className="card flex gap-3 p-3">
              <Link href={`/product/${l.slug}`} className="shrink-0">
                <img src={l.image || '/products/phone-1.svg'} alt={l.name} className="h-20 w-20 rounded-lg bg-[#f7f8fa] object-contain p-1" />
              </Link>
              <div className="min-w-0 flex-1">
                <Link href={`/product/${l.slug}`} className="line-clamp-2 text-sm font-semibold text-ink-800 hover:text-obah-600">{l.name}</Link>
                <p className="mt-0.5 text-[11px] text-ink-400">
                  {l.brand}
                  {l.color ? ` · ${l.color}` : ''}
                  {l.storage ? ` · ${l.storage}` : ''}
                </p>
                <p className="mt-1 text-sm font-extrabold text-ink-800">{NGN(l.unit_price)}</p>
                {l.stock_available < l.qty && (
                  <p className="text-[11px] font-semibold text-rose-600">Only {l.stock_available} left — reduce quantity</p>
                )}
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <form action={updateQtyAction} className="flex items-center overflow-hidden rounded-lg border border-gray-300">
                    <input type="hidden" name="item_id" value={l.item_id} />
                    <input name="qty" type="number" min={1} max={l.stock_available} defaultValue={l.qty} className="w-14 px-2 py-1.5 text-center text-xs outline-none" />
                    <button className="bg-gray-100 px-2 py-1.5 text-[11px] font-bold text-ink-600 hover:bg-gray-200">Update</button>
                  </form>
                  <form action={removeItemAction}>
                    <input type="hidden" name="item_id" value={l.item_id} />
                    <button className="text-[11px] font-semibold text-rose-600 hover:underline">Remove</button>
                  </form>
                </div>
              </div>
              <div className="shrink-0 text-right">
                <p className="text-[10px] uppercase tracking-wide text-ink-400">Subtotal</p>
                <p className="text-sm font-extrabold text-ink-800">{NGN(l.line_total)}</p>
              </div>
            </div>
          ))}
          <Link href="/category/all" className="inline-block text-xs font-bold text-obah-600 hover:underline">← Continue shopping</Link>
        </div>

        <div className="space-y-3">
          <div className="card p-4">
            <p className="text-xs font-bold uppercase tracking-wide text-ink-800">Discount code</p>
            {promo ? (
              <div className="mt-2 flex items-center justify-between rounded-lg bg-emerald-50 p-2">
                <div>
                  <p className="text-xs font-bold text-emerald-800">{promo.code}</p>
                  <p className="text-[10px] text-emerald-700">{promo.description}</p>
                </div>
                <form action={clearPromoAction}>
                  <button className="text-[11px] font-bold text-rose-600 hover:underline">Remove</button>
                </form>
              </div>
            ) : (
              <form action={applyPromoAction} className="mt-2 flex gap-2">
                <input name="code" placeholder="e.g. OBAH10" className="input" />
                <button className="btn-dark btn-sm">Apply</button>
              </form>
            )}
            <p className="mt-2 text-[10px] text-ink-400">Try OBAH10, FREESHIP or GADGET5K.</p>
          </div>

          <div className="card p-4">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Order summary</p>
            <dl className="space-y-1.5 text-xs">
              <div className="flex justify-between"><dt className="text-ink-500">Subtotal</dt><dd className="font-semibold">{NGN(totals.subtotal)}</dd></div>
              {totals.discount > 0 && (
                <div className="flex justify-between text-emerald-600"><dt>Discount</dt><dd className="font-semibold">−{NGN(totals.discount)}</dd></div>
              )}
              <div className="flex justify-between"><dt className="text-ink-500">Delivery (est.)</dt><dd className="font-semibold">{totals.deliveryFee === 0 ? 'Free' : NGN(totals.deliveryFee)}</dd></div>
              <div className="flex justify-between border-t border-gray-100 pt-1.5 text-sm"><dt className="font-bold">Total</dt><dd className="font-extrabold text-obah-600">{NGN(totals.total)}</dd></div>
            </dl>
            <p className="mt-2 text-[10px] text-ink-400">
              Delivery to {user.state_name || 'your state'} in about {totals.eta} day{totals.eta > 1 ? 's' : ''}. Final fee is confirmed at checkout.
            </p>
            <Link href="/checkout" className="btn-primary mt-3 w-full">Proceed to checkout</Link>
          </div>

          <div className="card p-3 text-[11px] text-ink-500">
            <p className="font-bold text-ink-800">🔒 Secure checkout</p>
            <p className="mt-1">Payments are processed by Flutterwave in Nigerian Naira. OBAHTECH never stores your card details.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
