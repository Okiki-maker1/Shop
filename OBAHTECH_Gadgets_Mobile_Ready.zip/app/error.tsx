'use client';

import { useEffect } from 'react';

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Surface the digest so support can correlate with server logs.
    console.error('OBAHTECH app error', error.digest, error.message);
  }, [error]);

  return (
    <div className="container-obah py-16">
      <div className="mx-auto max-w-lg rounded-xl border border-gray-200 bg-white p-8 text-center shadow-card">
        <p className="text-xs font-bold uppercase tracking-widest text-rose-600">Something went wrong</p>
        <h1 className="mt-2 text-xl font-extrabold text-ink-900">This page hit an error</h1>
        <p className="mt-2 text-sm text-ink-500">
          Your cart and orders are safe. Try again — if it keeps happening, contact support and quote the reference below.
        </p>
        {error.digest && <p className="mt-3 rounded bg-gray-50 px-2 py-1 font-mono text-[11px] text-ink-500">{error.digest}</p>}
        <div className="mt-5 flex justify-center gap-2 text-xs font-semibold">
          <button onClick={reset} className="rounded-lg bg-obah-500 px-4 py-2 text-white hover:bg-obah-600">Try again</button>
          <a href="/support" className="rounded-lg bg-gray-100 px-4 py-2 text-ink-700 hover:bg-gray-200">Contact support</a>
        </div>
      </div>
    </div>
  );
}
