import Link from 'next/link';
import { Alert } from '@/components/ui';
import { forgotPasswordAction } from '@/lib/actions/auth';

export const metadata = { title: 'Reset password' };

export default function ForgotPasswordPage({ searchParams }: { searchParams: Record<string, string> }) {
  return (
    <div className="container-obah max-w-md py-10">
      <div className="card p-5">
        <h1 className="text-xl font-extrabold text-ink-800">Reset your password</h1>
        <p className="mb-4 text-xs text-ink-400">We will email you a secure link valid for one hour.</p>
        {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}
        {searchParams.sent && (
          <div className="mb-3">
            <Alert tone="success">
              If that email exists in our system, a reset link has been queued. In development the message is written to the
              <code className="mx-1 rounded bg-white px-1">email_outbox</code> table instead of being delivered.
            </Alert>
          </div>
        )}
        <form action={forgotPasswordAction} className="space-y-3">
          <div>
            <label className="label" htmlFor="email">Email address</label>
            <input id="email" name="email" type="email" required className="input" />
          </div>
          <button className="btn-primary w-full">Send reset link</button>
        </form>
        <p className="mt-3 text-center text-[11px] text-ink-400">
          <Link href="/login" className="link">Back to sign in</Link>
        </p>
      </div>
    </div>
  );
}
