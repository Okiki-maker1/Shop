import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { locationOptions } from '@/lib/locations.server';
import { LgaStateSelect } from '@/components/LgaStateSelect';
import { Alert } from '@/components/ui';
import { NGN, fmtDate, fmtDateTime } from '@/lib/format';
import { saveAddress, deleteAddress, setDefaultAddress, updateProfile, submitWarrantyClaim } from '@/lib/actions/customer';
import { resendVerificationAction } from '@/lib/actions/auth';

export const metadata = { title: 'My account' };
export const dynamic = 'force-dynamic';

export default async function AccountPage({ searchParams }: { searchParams: Record<string, string> }) {
  const user = await getSessionUser();
  if (!user) redirect('/login?next=/account');
  const db = getDb();
  const { states, lgas } = await locationOptions();
  const addresses = await db.prepare('SELECT a.*, s.name AS state_name, l.name AS lga_name FROM addresses a JOIN states s ON s.id=a.state_id JOIN lgas l ON l.id=a.lga_id WHERE a.user_id = ? ORDER BY a.is_default DESC, a.id').all(user.id) as any[];
  const warranties = await db
    .prepare(
      `SELECT w.*, (SELECT status FROM warranty_claims WHERE warranty_id = w.id ORDER BY id DESC LIMIT 1) AS claim_status
         FROM warranties w WHERE w.user_id = ? ORDER BY w.id DESC`,
    )
    .all(user.id) as any[];
  const claims = await db.prepare('SELECT * FROM warranty_claims WHERE user_id = ? ORDER BY id DESC').all(user.id) as any[];
  const orders = await db.prepare('SELECT order_number, status, total, created_at FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 4').all(user.id) as any[];
  const unread = (await db.prepare('SELECT COUNT(*) c FROM notifications WHERE recipient_user_id = ? AND is_read = 0').get(user.id) as any).c;
  const verified = !!(await db.prepare('SELECT email_verified FROM users WHERE id = ?').get(user.id) as any)?.email_verified;

  return (
    <div className="container-obah py-4">
      {searchParams.welcome && <div className="mb-3"><Alert tone="success">Welcome to OBAHTECH Gadgets! Your account is ready. Add a delivery address to speed up checkout.</Alert></div>}
      {searchParams.saved && <div className="mb-3"><Alert tone="success">Saved successfully.</Alert></div>}
      {searchParams.claim && <div className="mb-3"><Alert tone="success">Warranty claim submitted — the state administrator and super admin have been notified.</Alert></div>}
      {searchParams.error && <div className="mb-3"><Alert>{searchParams.error}</Alert></div>}
      {searchParams.message && <div className="mb-3"><Alert tone="success">{searchParams.message}</Alert></div>}
      {!verified && (
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-[13px] text-amber-900">
          <span>
            <span className="font-bold">Confirm your email.</span> Receipts and order alerts go to {user.email}. Check your inbox for
            the verification link (it is valid for 48 hours).
          </span>
          <form action={resendVerificationAction}>
            <button className="rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-amber-700">
              Resend link
            </button>
          </form>
        </div>
      )}

      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-lg font-extrabold text-ink-800">Hello, {user.full_name.split(' ')[0]}</h1>
          <p className="text-[11px] text-ink-400">{user.email} · {user.state_name || 'State not set'}</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <Link href="/orders" className="btn-outline btn-sm">My orders</Link>
          <Link href="/notifications" className="btn-outline btn-sm">Notifications {unread > 0 && <span className="ml-1 rounded-full bg-rose-600 px-1.5 text-[10px] text-white">{unread}</span>}</Link>
          <Link href="/support" className="btn-outline btn-sm">Support</Link>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-3">
          {/* Profile */}
          <section className="card p-4">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Profile details</h2>
            <form action={updateProfile} className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="label">Full name</label>
                <input name="full_name" defaultValue={user.full_name} className="input" required />
              </div>
              <div>
                <label className="label">Phone number</label>
                <input name="phone" defaultValue={user.phone || ''} className="input" required />
              </div>
              <div>
                <label className="label">Email address</label>
                <input defaultValue={user.email} readOnly className="input bg-gray-50" />
              </div>
              <div>
                <label className="label">Registered state</label>
                <input defaultValue={user.state_name || '—'} readOnly className="input bg-gray-50" />
              </div>
              <div className="sm:col-span-2">
                <button className="btn-primary btn-sm">Save changes</button>
              </div>
            </form>
            <p className="mt-2 text-[10px] text-ink-400">Changing your phone number here does not affect orders already placed.</p>
          </section>

          {/* Addresses */}
          <section className="card p-4" id="addresses">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Delivery addresses ({addresses.length})</h2>
            <div className="space-y-2">
              {addresses.map((a) => (
                <div key={a.id} className="rounded-lg border border-gray-200 p-2.5">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="text-xs font-bold text-ink-800">
                        {a.label} {a.is_default ? <span className="ml-1 rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-bold text-emerald-700">Default</span> : null}
                      </p>
                      <p className="text-[11px] text-ink-600">{a.full_name} · {a.phone}</p>
                      <p className="text-[11px] text-ink-500">{a.street}</p>
                      <p className="text-[11px] text-ink-400">{a.lga_name}, {a.state_name}</p>
                    </div>
                    <div className="flex gap-1.5">
                      {!a.is_default && (
                        <form action={setDefaultAddress}>
                          <input type="hidden" name="id" value={a.id} />
                          <button className="btn-outline btn-sm">Make default</button>
                        </form>
                      )}
                      <form action={deleteAddress}>
                        <input type="hidden" name="id" value={a.id} />
                        <button className="btn-outline btn-sm text-rose-600">Delete</button>
                      </form>
                    </div>
                  </div>
                  <details className="mt-2">
                    <summary className="cursor-pointer text-[11px] font-bold text-obah-600">Edit this address</summary>
                    <form action={saveAddress} className="mt-2 space-y-2">
                      <input type="hidden" name="id" value={a.id} />
                      <div className="grid gap-2 sm:grid-cols-2">
                        <input name="label" defaultValue={a.label} className="input" placeholder="Label (Home/Office)" />
                        <input name="full_name" defaultValue={a.full_name} className="input" placeholder="Recipient name" />
                        <input name="phone" defaultValue={a.phone} className="input" placeholder="Phone" />
                        <input name="street" defaultValue={a.street} className="input" placeholder="Street address" />
                      </div>
                      <LgaStateSelect states={states} lgas={lgas} defaultStateId={a.state_id} defaultLgaId={a.lga_id} />
                      <input name="instructions" defaultValue={a.instructions || ''} className="input" placeholder="Delivery instructions" />
                      <button className="btn-primary btn-sm">Save address</button>
                    </form>
                  </details>
                </div>
              ))}
            </div>

            <details className="mt-3" open={addresses.length === 0}>
              <summary className="cursor-pointer text-xs font-bold text-obah-600">+ Add a new delivery address</summary>
              <form action={saveAddress} className="mt-2 space-y-2">
                <div className="grid gap-2 sm:grid-cols-2">
                  <input name="label" className="input" placeholder="Label (e.g. Office)" />
                  <input name="full_name" defaultValue={user.full_name} required className="input" placeholder="Recipient name" />
                  <input name="phone" defaultValue={user.phone || ''} required className="input" placeholder="Phone number" />
                  <input name="street" required className="input" placeholder="House number, street, landmark" />
                </div>
                <LgaStateSelect states={states} lgas={lgas} defaultStateId={user.state_id} />
                <input name="instructions" className="input" placeholder="Delivery instructions (optional)" />
                <button className="btn-primary btn-sm">Save address</button>
              </form>
            </details>
            <p className="mt-2 text-[10px] text-ink-400">Only Nigerian addresses are supported. Orders keep the state/LGA saved at checkout.</p>
          </section>

          {/* Warranties */}
          <section className="card p-4" id="warranties">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">My warranties ({warranties.length})</h2>
            {warranties.length === 0 && <p className="text-[11px] text-ink-400">Warranties appear here after an order is delivered.</p>}
            <div className="space-y-2">
              {warranties.map((w) => {
                const expired = new Date(w.expiry_date) < new Date();
                return (
                  <div key={w.id} className="rounded-lg border border-gray-200 p-2.5">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <p className="text-xs font-bold text-ink-800">{w.product_name}</p>
                        <p className="text-[11px] text-ink-500">
                          {w.duration_months}-month warranty · {fmtDate(w.start_date)} → {fmtDate(w.expiry_date)}
                        </p>
                        {w.serial_no && <p className="text-[10px] text-ink-400">Serial/IMEI: {w.serial_no}</p>}
                      </div>
                      <span className={`chip ${expired ? 'bg-gray-100 text-gray-600 ring-gray-200' : 'bg-emerald-50 text-emerald-700 ring-emerald-200'}`}>
                        {expired ? 'Expired' : w.claim_status ? w.claim_status.replace(/_/g, ' ') : w.status}
                      </span>
                    </div>
                    {!expired && (
                      <details className="mt-2">
                        <summary className="cursor-pointer text-[11px] font-bold text-obah-600">Submit a warranty claim</summary>
                        <form action={submitWarrantyClaim} className="mt-2 space-y-2">
                          <input type="hidden" name="warranty_id" value={w.id} />
                          <textarea name="issue" rows={2} required className="input text-xs" placeholder="Describe the fault" />
                          <input name="evidence_url" className="input text-xs" placeholder="Photo/video link (optional)" />
                          <button className="btn-primary btn-sm">Submit claim</button>
                        </form>
                      </details>
                    )}
                  </div>
                );
              })}
            </div>
            {claims.length > 0 && (
              <div className="mt-3">
                <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-ink-500">Claim history</p>
                {claims.map((c) => (
                  <div key={c.id} className="mb-1 rounded bg-sky-50 p-2 text-[11px] text-sky-900">
                    <p className="font-bold">Claim #{c.id} — {c.status.replace(/_/g, ' ')}</p>
                    <p className="line-clamp-2">{c.issue}</p>
                    {c.admin_note && <p className="mt-0.5">OBAHTECH: {c.admin_note}</p>}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <div className="space-y-3">
          <section className="card p-4">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Recent orders</h2>
            {orders.length === 0 && <p className="text-[11px] text-ink-400">No orders yet.</p>}
            {orders.map((o) => (
              <Link key={o.order_number} href={`/orders/${o.order_number}`} className="mb-1.5 block rounded-lg bg-gray-50 p-2 hover:bg-obah-50">
                <p className="text-[11px] font-bold text-ink-800">{o.order_number}</p>
                <p className="text-[10px] text-ink-400">{o.status.replace(/_/g, ' ')} · {NGN(o.total)} · {fmtDate(o.created_at)}</p>
              </Link>
            ))}
            <Link href="/orders" className="text-[11px] font-bold text-obah-600">View all orders →</Link>
          </section>
          <section className="card p-4">
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-800">Account security</h2>
            <ul className="space-y-1 text-[11px] text-ink-500">
              <li>✓ Email: {user.email}</li>
              <li>✓ Role: {user.role.replace(/_/g, ' ')}</li>
              <li>✓ Sessions expire after 14 days</li>
            </ul>
            <Link href="/forgot-password" className="mt-2 inline-block text-[11px] font-bold text-obah-600">Change password →</Link>
          </section>
        </div>
      </div>
    </div>
  );
}
