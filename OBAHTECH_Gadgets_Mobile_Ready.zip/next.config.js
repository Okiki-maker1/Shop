module.exports = {
  reactStrictMode: true,
  images: { unoptimized: true },
  experimental: {
    serverActions: { bodySizeLimit: '8mb' },
  },
  eslint: { ignoreDuringBuilds: true },
};
