import Link from 'next/link';
import { Price, Stars } from './ui';
import { WishlistButton } from './WishlistButton';

export type CardProduct = {
  id: number;
  name: string;
  slug: string;
  brand: string;
  price: number;
  compare_price: number | null;
  is_flash_sale: number;
  flash_price: number | null;
  rating_avg: number;
  rating_count: number;
  stock: number;
  reserved: number;
  image: string | null;
  ram?: string | null;
  storage_options?: string | null;
  warranty_months?: number;
};

export function ProductCard({ p, wished = false, compact = false }: { p: CardProduct; wished?: boolean; compact?: boolean }) {
  const eff = p.is_flash_sale && p.flash_price ? p.flash_price : p.price;
  const available = p.stock - p.reserved;
  const storage = p.storage_options ? (JSON.parse(p.storage_options || '[]') as string[])[0] : null;
  return (
    <div className="group relative flex flex-col overflow-hidden rounded-xl border border-gray-100 bg-white shadow-card transition hover:shadow-pop">
      <Link href={`/product/${p.slug}`} className="relative block overflow-hidden bg-[#f7f8fa]">
        <img
          src={p.image || '/products/phone-1.svg'}
          alt={p.name}
          className="aspect-square w-full object-contain p-2 transition-transform duration-300 group-hover:scale-[1.04]"
          loading="lazy"
        />
        {p.is_flash_sale && p.flash_price ? (
          <span className="absolute left-0 top-2 rounded-r bg-rose-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
            Flash sale
          </span>
        ) : null}
        {available <= 0 && (
          <span className="absolute inset-x-0 bottom-0 bg-ink-800/80 py-1 text-center text-[10px] font-bold uppercase tracking-wide text-white">
            Out of stock
          </span>
        )}
      </Link>
      <div className="absolute right-1.5 top-1.5">
        <WishlistButton productId={p.id} active={wished} />
      </div>
      <div className="flex flex-1 flex-col gap-1 p-2.5">
        <Link href={`/product/${p.slug}`} className="line-clamp-2 text-[13px] font-medium leading-snug text-ink-700 hover:text-obah-600">
          {p.name}
        </Link>
        {!compact && (
          <div className="flex items-center gap-1.5 text-[10px] text-ink-400">
            {p.ram && <span className="rounded bg-gray-100 px-1 py-0.5 font-semibold">{p.ram}</span>}
            {storage && <span className="rounded bg-gray-100 px-1 py-0.5 font-semibold">{storage}</span>}
            {p.warranty_months ? <span className="rounded bg-emerald-50 px-1 py-0.5 font-semibold text-emerald-700">{p.warranty_months}mo warranty</span> : null}
          </div>
        )}
        <Price price={eff} compare={p.is_flash_sale && p.flash_price ? p.price : p.compare_price} size="sm" />
        <Stars rating={p.rating_avg} count={p.rating_count} />
        {available > 0 && available <= 5 && <span className="text-[10px] font-bold text-rose-600">Only {available} left</span>}
      </div>
    </div>
  );
}
