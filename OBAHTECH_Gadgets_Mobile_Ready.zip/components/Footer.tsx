import Link from 'next/link';

export function Footer() {
  return (
    <footer className="mt-10 border-t border-gray-200 bg-white">
      <div className="container-obah grid gap-8 py-10 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <img src="/brand/logo-mark.svg" alt="" width={30} height={30} className="rounded-lg" />
            <div>
              <p className="text-lg font-extrabold leading-none text-ink-800">OBAHTECH</p>
              <p className="text-[9px] font-semibold uppercase tracking-[0.3em] text-obah-600">Gadgets</p>
            </div>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-ink-400">
            Nigeria&apos;s trusted marketplace for genuine smartphones, tablets and accessories. Nationwide delivery,
            verified warranties and real customer support — from Lagos to Maiduguri.
          </p>
          <div className="mt-3 flex gap-2 text-[11px] text-ink-400">
            <span className="rounded bg-gray-100 px-2 py-1 font-semibold">🇳🇬 Nigeria only</span>
            <span className="rounded bg-gray-100 px-2 py-1 font-semibold">₦ NGN</span>
          </div>
        </div>
        <div>
          <p className="mb-3 text-xs font-bold uppercase tracking-wide text-ink-800">Shop</p>
          <ul className="space-y-1.5 text-xs text-ink-500">
            {[
              ['All categories', '/category/all'],
              ['Apple iPhones', '/category/apple-iphones'],
              ['Samsung smartphones', '/category/samsung-smartphones'],
              ['Tecno smartphones', '/category/tecno-smartphones'],
              ['Infinix smartphones', '/category/infinix-smartphones'],
              ['Tablets', '/category/tablets'],
              ['Power banks & chargers', '/category/power-banks'],
            ].map(([l, h]) => (
              <li key={h}><Link href={h} className="hover:text-obah-600">{l}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="mb-3 text-xs font-bold uppercase tracking-wide text-ink-800">Customer care</p>
          <ul className="space-y-1.5 text-xs text-ink-500">
            {[
              ['Help & support', '/support'],
              ['Track my order', '/track'],
              ['Returns & refunds', '/support#returns'],
              ['Warranty policy', '/support#warranty'],
              ['My orders', '/orders'],
              ['Contact us', '/support#contact'],
            ].map(([l, h]) => (
              <li key={h}><Link href={h} className="hover:text-obah-600">{l}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="mb-3 text-xs font-bold uppercase tracking-wide text-ink-800">Stay updated</p>
          <form action="/api/newsletter" method="post" className="flex overflow-hidden rounded-lg border border-gray-300">
            <input name="email" type="email" required placeholder="Your email address" className="w-full px-3 py-2 text-xs outline-none" />
            <button className="bg-obah-500 px-3 text-[11px] font-bold uppercase text-white hover:bg-obah-600">Join</button>
          </form>
          <p className="mt-2 text-[11px] text-ink-400">Deals, new arrivals and price drops. No spam.</p>
          <div className="mt-4 rounded-lg bg-gray-50 p-3">
            <p className="text-[11px] font-bold text-ink-700">Customer support</p>
            <p className="mt-0.5 text-[11px] text-ink-500">Mon–Sat, 8am–8pm WAT</p>
            <a href="tel:+2348000000000" className="text-[11px] font-semibold text-obah-600">0800 OBAH TECH</a>
            <br />
            <a href="mailto:support@obahtech.ng" className="text-[11px] text-ink-500 hover:text-obah-600">support@obahtech.ng</a>
          </div>
        </div>
      </div>
      <div className="border-t border-gray-100 py-4">
        <div className="container-obah flex flex-col items-center justify-between gap-2 text-[11px] text-ink-400 sm:flex-row">
          <p>© {new Date().getFullYear()} OBAHTECH Gadgets. All rights reserved. RC — independent Nigerian business.</p>
          <div className="flex flex-wrap items-center gap-3">
            <Link href="/terms" className="hover:text-obah-600">Terms</Link>
            <Link href="/privacy" className="hover:text-obah-600">Privacy</Link>
            <span>Payments secured by Flutterwave</span>
            <span className="rounded bg-gray-100 px-2 py-0.5 font-bold">VISA</span>
            <span className="rounded bg-gray-100 px-2 py-0.5 font-bold">Mastercard</span>
            <span className="rounded bg-gray-100 px-2 py-0.5 font-bold">Verve</span>
            <span className="rounded bg-gray-100 px-2 py-0.5 font-bold">Transfer</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
