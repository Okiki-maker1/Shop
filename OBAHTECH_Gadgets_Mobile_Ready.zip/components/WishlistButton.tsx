'use client';


import { toggleWishlist } from '@/lib/actions/customer';

export function WishlistButton({ productId, active }: { productId: number; active?: boolean }) {
  return (
    <form action={toggleWishlist} className="contents">
      <input type="hidden" name="product_id" value={productId} />
      <input type="hidden" name="return_to" value={typeof window !== 'undefined' ? window.location.pathname : '/'} />
      <button
        type="submit"
        aria-label={active ? 'Remove from wishlist' : 'Save to wishlist'}
        className={`grid h-7 w-7 place-items-center rounded-full bg-white/95 text-sm shadow ring-1 ring-gray-200 transition hover:scale-105 ${
          active ? 'text-rose-600' : 'text-ink-300'
        }`}
      >
        {active ? '♥' : '♡'}
      </button>
    </form>
  );
}
