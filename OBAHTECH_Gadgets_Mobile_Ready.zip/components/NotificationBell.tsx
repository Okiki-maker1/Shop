'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { IconBell } from './icons';

type N = { id: number; title: string; body: string | null; type: string; created_at: string; is_read: number; order_id: number | null };

/** Realtime-ish bell: polls the notification feed (Supabase Realtime is the production transport). */
export function NotificationBell({ initialRole }: { initialRole: string }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<N[]>([]);
  const [unread, setUnread] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const box = useRef<HTMLDivElement>(null);

  const load = async () => {
    try {
      const r = await fetch('/api/notifications?limit=8', { cache: 'no-store' });
      if (!r.ok) return;
      const j = await r.json();
      setItems(j.items ?? []);
      setUnread(j.unread ?? 0);
      setLoaded(true);
    } catch {
      /* offline */
    }
  };

  useEffect(() => {
    (async () => {
      await load();
    })();
    const t = setInterval(load, 12000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (box.current && !box.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const markAll = async () => {
    await fetch('/api/notifications', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'read_all' }) });
    setItems((prev) => prev.map((i) => ({ ...i, is_read: 1 })));
    setUnread(0);
  };

  return (
    <div className="relative" ref={box}>
      <button
        onClick={async () => { setOpen((o) => !o); if (!open)await  load(); }}
        aria-label="Notifications"
        className="relative flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-white hover:bg-white/15"
      >
        <IconBell size={18} />
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-rose-600 px-1 text-[9px] font-bold text-white ring-2 ring-obah-500">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 top-full z-50 mt-1 w-[min(92vw,360px)] animate-slide-down overflow-hidden rounded-xl bg-white shadow-pop ring-1 ring-gray-200">
          <div className="flex items-center justify-between border-b border-gray-100 px-3 py-2">
            <p className="text-xs font-bold uppercase tracking-wide text-ink-500">
              Notifications {unread > 0 && <span className="text-obah-600">({unread} new)</span>}
            </p>
            {unread > 0 && (
              <button onClick={markAll} className="text-[11px] font-semibold text-obah-600 hover:underline">Mark all read</button>
            )}
          </div>
          <div className="max-h-[60vh] overflow-y-auto">
            {!loaded && <p className="px-3 py-6 text-center text-xs text-ink-400">Loading…</p>}
            {loaded && items.length === 0 && <p className="px-3 py-6 text-center text-xs text-ink-400">No notifications yet.</p>}
            {items.map((n) => (
              <Link
                key={n.id}
                href={n.order_id ? `/admin/orders/${n.order_id}` : '/notifications'}
                onClick={() => setOpen(false)}
                className={`block border-b border-gray-50 px-3 py-2.5 text-left hover:bg-gray-50 ${n.is_read ? '' : 'bg-obah-50/50'}`}
              >
                <p className="text-[12px] font-semibold leading-snug text-ink-800">{n.title}</p>
                {n.body && <p className="line-clamp-2 text-[11px] text-ink-400">{n.body}</p>}
                <p className="mt-0.5 text-[10px] uppercase tracking-wide text-ink-300">{new Date(n.created_at.replace(' ', 'T') + 'Z').toLocaleString('en-NG')}</p>
              </Link>
            ))}
          </div>
          <Link href={initialRole === 'customer' ? '/notifications' : '/admin/notifications'} onClick={() => setOpen(false)} className="block bg-gray-50 px-3 py-2 text-center text-[11px] font-bold uppercase tracking-wide text-obah-600">
            View all notifications
          </Link>
        </div>
      )}
    </div>
  );
}
