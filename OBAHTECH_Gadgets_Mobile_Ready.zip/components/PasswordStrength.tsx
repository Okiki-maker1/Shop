'use client';

import { useMemo, useState } from 'react';

const RULES: { label: string; test: (v: string) => boolean }[] = [
  { label: '8+ characters', test: (v) => v.length >= 8 },
  { label: 'a letter', test: (v) => /[a-z]/i.test(v) },
  { label: 'a number', test: (v) => /\d/.test(v) },
  { label: 'a symbol', test: (v) => /[^A-Za-z0-9]/.test(v) },
];

export function PasswordStrength({ name = 'password' }: { name?: string }) {
  const [value, setValue] = useState('');
  const score = useMemo(() => RULES.filter((r) => r.test(value)).length, [value]);
  const tone = score <= 1 ? 'bg-rose-500' : score === 2 ? 'bg-amber-500' : score === 3 ? 'bg-sky-500' : 'bg-emerald-500';
  const label = score <= 1 ? 'Weak' : score === 2 ? 'Fair' : score === 3 ? 'Good' : 'Strong';

  return (
    <div className="mt-1.5">
      <input
        id={name}
        name={name}
        type="password"
        required
        minLength={8}
        className="input"
        placeholder="At least 8 characters"
        autoComplete="new-password"
        onChange={(e) => setValue(e.target.value)}
        aria-describedby={`${name}-strength`}
      />
      <div id={`${name}-strength`} className="mt-1.5 flex items-center gap-2">
        <div className="flex h-1.5 flex-1 gap-1">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={`h-full flex-1 rounded-full ${i < Math.max(1, score) ? tone : 'bg-gray-200'}`} />
          ))}
        </div>
        <span className="w-14 text-right text-[10px] font-bold text-ink-500">{value ? label : ''}</span>
      </div>
      <p className="mt-1 text-[10px] text-ink-400">
        Use {RULES.map((r) => r.label).join(', ')}. Passwords are stored as bcrypt hashes — we can never read them.
      </p>
    </div>
  );
}
