// Original OBAHTECH icon set — inline SVG so it renders identically everywhere
// (no external icon font/CDN, works inside sandboxed previews).
type P = { className?: string; size?: number };
const base = (size = 18) => ({
  width: size,
  height: size,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.8,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
});

export const IconCart = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6" /><circle cx="10" cy="20" r="1.3" /><circle cx="18" cy="20" r="1.3" /></svg>
);
export const IconUser = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><circle cx="12" cy="8" r="3.5" /><path d="M4.5 20c1.2-3.6 4-5.5 7.5-5.5s6.3 1.9 7.5 5.5" /></svg>
);
export const IconHeart = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M12 20s-7-4.4-7-9.2A4 4 0 0 1 12 8a4 4 0 0 1 7 2.8C19 15.6 12 20 12 20Z" /></svg>
);
export const IconBell = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M6 9a6 6 0 1 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 13 6 9Z" /><path d="M10 18a2 2 0 0 0 4 0" /></svg>
);
export const IconTruck = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M3 6h10v9H3zM13 9h4l3 3v3h-7z" /><circle cx="7" cy="18" r="1.6" /><circle cx="17" cy="18" r="1.6" /></svg>
);
export const IconShield = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M12 3.5 19 6v6c0 4.2-3 7-7 8.5C8 19 5 16.2 5 12V6l7-2.5Z" /><path d="m9 12 2 2 4-4" /></svg>
);
export const IconReturn = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M4 10a8 8 0 1 1 2.4 6" /><path d="M4 5v5h5" /></svg>
);
export const IconBox = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z" /><path d="m4 7.5 8 4.5 8-4.5M12 12v9" /></svg>
);
export const IconGrid = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><rect x="3.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="3.5" y="13.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="13.5" width="7" height="7" rx="1.5" /></svg>
);
export const IconTag = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M4 12.5V5.5A1.5 1.5 0 0 1 5.5 4h7l7.5 7.5-8 8L4 12.5Z" /><circle cx="8.5" cy="8.5" r="1.3" /></svg>
);
export const IconImage = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><rect x="3.5" y="4.5" width="17" height="15" rx="2" /><path d="m5 17 4.5-5 3.5 4 2.5-2.5L19 17" /><circle cx="9" cy="9" r="1.4" /></svg>
);
export const IconChart = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M4 20V4M4 20h16" /><path d="M8 16v-4M12 16V8M16 16v-6" /></svg>
);
export const IconUsers = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><circle cx="9" cy="8.5" r="3" /><path d="M3 19c.9-3 3.2-4.5 6-4.5s5.1 1.5 6 4.5" /><path d="M16 6.2a3 3 0 0 1 0 5.6M17.5 14.2c1.7.6 2.9 2 3.5 4.3" /></svg>
);
export const IconBadge = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><rect x="3.5" y="5" width="17" height="14" rx="2" /><circle cx="9" cy="11" r="2" /><path d="M6 16c.6-1.6 1.7-2.4 3-2.4s2.4.8 3 2.4M15 10h3M15 13.5h3" /></svg>
);
export const IconHeadset = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="M4 13v-1a8 8 0 0 1 16 0v1" /><rect x="2.5" y="13" width="4" height="6" rx="2" /><rect x="17.5" y="13" width="4" height="6" rx="2" /><path d="M20 19v.5a2.5 2.5 0 0 1-2.5 2.5H13" /></svg>
);
export const IconWallet = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><rect x="3" y="6" width="18" height="12" rx="2.5" /><path d="M3 10h18" /><circle cx="16.5" cy="14" r="1.2" /></svg>
);
export const IconMenu = ({ className = '', size = 20 }: P) => (
  <svg {...base(size)} className={className}><path d="M4 7h16M4 12h16M4 17h16" /></svg>
);
export const IconSearch = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4 4" /></svg>
);
export const IconCheck = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><path d="m5 12.5 4.5 4.5L19 7" /></svg>
);
export const IconBolt = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className} fill="currentColor" stroke="none"><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" /></svg>
);
export const IconLock = ({ className = '', size = 18 }: P) => (
  <svg {...base(size)} className={className}><rect x="5" y="10.5" width="14" height="9.5" rx="2" /><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" /></svg>
);
