'use client';

import { useState } from 'react';
import Link from 'next/link';
import { IconMenu } from './icons';

export function MobileMenu({ categories, user }: { categories: { name: string; slug: string; group_name: string }[]; user: { name: string; role: string } | null }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label="Open menu"
        className="grid h-9 w-9 place-items-center rounded-lg bg-white/20 text-white"
      >
        <IconMenu size={20} />
      </button>
      {open && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-[84%] max-w-xs animate-slide-down overflow-y-auto bg-white p-4 shadow-pop">
            <div className="mb-4 flex items-center justify-between">
              <p className="font-extrabold text-ink-800">OBAHTECH Gadgets</p>
              <button onClick={() => setOpen(false)} aria-label="Close menu" className="grid h-8 w-8 place-items-center rounded-full bg-gray-100">✕</button>
            </div>
            {user ? (
              <div className="mb-4 rounded-lg bg-obah-50 p-3">
                <p className="text-sm font-bold text-ink-800">{user.name}</p>
                {user.role !== 'customer' && (
                  <Link href="/admin" onClick={() => setOpen(false)} className="text-xs font-semibold text-obah-600">Go to admin dashboard →</Link>
                )}
              </div>
            ) : (
              <div className="mb-4 flex gap-2">
                <Link href="/login" onClick={() => setOpen(false)} className="btn-primary flex-1">Sign in</Link>
                <Link href="/register" onClick={() => setOpen(false)} className="btn-outline flex-1">Register</Link>
              </div>
            )}
            <nav className="space-y-1 text-sm">
              {['Phones', 'Tablets', 'Accessories'].map((g) => (
                <div key={g} className="pb-2">
                  <p className="mb-1 text-[10px] font-bold uppercase tracking-widest text-ink-300">{g}</p>
                  {categories.filter((c) => (g === 'Phones' ? c.group_name === 'Smartphones' : g === 'Tablets' ? c.slug === 'tablets' : c.group_name === 'Accessories')).map((c) => (
                    <Link key={c.slug} href={`/category/${c.slug}`} onClick={() => setOpen(false)} className="block rounded px-2 py-2 text-ink-700 hover:bg-obah-50">
                      {c.name}
                    </Link>
                  ))}
                </div>
              ))}
              <div className="border-t border-gray-100 pt-2">
                {[
                  ['My orders', '/orders'],
                  ['My account', '/account'],
                  ['Wishlist', '/wishlist'],
                  ['Notifications', '/notifications'],
                  ['Track order', '/track'],
                  ['Help & support', '/support'],
                ].map(([label, href]) => (
                  <Link key={href} href={href} onClick={() => setOpen(false)} className="block rounded px-2 py-2 text-ink-700 hover:bg-obah-50">
                    {label}
                  </Link>
                ))}
              </div>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
