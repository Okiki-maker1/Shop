import Link from 'next/link';
import { NGN, STATUS_LABEL, STATUS_STYLE, disc } from '@/lib/format';
import { IconBox } from './icons';

export function Logo({ size = 'md', light = false }: { size?: 'sm' | 'md' | 'lg'; light?: boolean }) {
  const dims = size === 'lg' ? 40 : size === 'sm' ? 26 : 32;
  const text = size === 'lg' ? 'text-2xl' : size === 'sm' ? 'text-base' : 'text-xl';
  return (
    <Link href="/" className="flex items-center gap-2" aria-label="OBAHTECH Gadgets home">
      <img src="/brand/logo-mark.svg" alt="" width={dims} height={dims} className="rounded-lg" />
      <span className={`${text} font-extrabold leading-none tracking-tight ${light ? 'text-white' : 'text-ink-800'}`}>
        OBAHTECH
        <span className={`block text-[9px] font-semibold uppercase tracking-[0.28em] ${light ? 'text-white/80' : 'text-obah-600'}`}>
          Gadgets
        </span>
      </span>
    </Link>
  );
}

export function Stars({ rating = 0, count }: { rating?: number; count?: number }) {
  const full = Math.round(rating);
  return (
    <span className="inline-flex items-center gap-1 text-[11px] text-ink-400">
      <span className="text-amber-500" aria-hidden>
        {'★'.repeat(Math.max(0, full))}
        <span className="text-gray-300">{'★'.repeat(Math.max(0, 5 - full))}</span>
      </span>
      <span className="font-semibold text-ink-700">{rating ? rating.toFixed(1) : '—'}</span>
      {count != null && <span>({count})</span>}
    </span>
  );
}

export function Price({ price, compare, size = 'md' }: { price: number; compare?: number | null; size?: 'sm' | 'md' | 'lg' }) {
  const off = disc(price, compare);
  const cls = size === 'lg' ? 'text-2xl' : size === 'sm' ? 'text-sm' : 'text-base';
  return (
    <div className="flex flex-wrap items-baseline gap-2">
      <span className={`${cls} font-extrabold text-ink-800`}>{NGN(price)}</span>
      {off > 0 && (
        <>
          <span className="text-xs text-ink-300 line-through">{NGN(compare!)}</span>
          <span className="rounded bg-rose-50 px-1.5 py-0.5 text-[10px] font-bold text-rose-600 ring-1 ring-rose-100">
            -{off}%
          </span>
        </>
      )}
    </div>
  );
}

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  return (
    <span className={`chip ${STATUS_STYLE[status] ?? 'bg-gray-100 text-gray-700 ring-gray-200'}`}>
      {label ?? STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function PayBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    paid: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    unpaid: 'bg-amber-50 text-amber-700 ring-amber-200',
    failed: 'bg-rose-50 text-rose-700 ring-rose-200',
    refunded: 'bg-teal-50 text-teal-700 ring-teal-200',
    partial_refund: 'bg-teal-50 text-teal-700 ring-teal-200',
  };
  return <span className={`chip ${map[status] ?? 'bg-gray-100 text-gray-700 ring-gray-200'}`}>{status.replace(/_/g, ' ')}</span>;
}

export function Empty({ title, hint, action }: { title: string; hint?: string; action?: React.ReactNode }) {
  return (
    <div className="card flex flex-col items-center justify-center gap-2 px-6 py-14 text-center">
      <div className="grid h-12 w-12 place-items-center rounded-full bg-obah-50 text-obah-500"><IconBox size={22} /></div>
      <p className="font-bold text-ink-800">{title}</p>
      {hint && <p className="max-w-md text-sm text-ink-400">{hint}</p>}
      {action}
    </div>
  );
}

export function SectionHeader({ title, href, linkLabel = 'See all', subtitle }: { title: string; href?: string; linkLabel?: string; subtitle?: string }) {
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <div>
        <h2 className="section-title">{title}</h2>
        {subtitle && <p className="text-xs text-ink-400">{subtitle}</p>}
      </div>
      {href && (
        <Link href={href} className="shrink-0 text-xs font-bold uppercase tracking-wide text-obah-600 hover:text-obah-700">
          {linkLabel} →
        </Link>
      )}
    </div>
  );
}

export function Alert({ tone = 'error', children }: { tone?: 'error' | 'success' | 'info' | 'warn'; children: React.ReactNode }) {
  const map = {
    error: 'bg-rose-50 text-rose-700 ring-rose-200',
    success: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    info: 'bg-sky-50 text-sky-800 ring-sky-200',
    warn: 'bg-amber-50 text-amber-800 ring-amber-200',
  }[tone];
  return <div className={`rounded-lg px-3 py-2.5 text-sm ring-1 ${map}`}>{children}</div>;
}

export function Stat({ label, value, hint, tone }: { label: string; value: string | number; hint?: string; tone?: string }) {
  return (
    <div className="admin-card">
      <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">{label}</p>
      <p className={`mt-1 text-2xl font-extrabold ${tone ?? 'text-ink-800'}`}>{value}</p>
      {hint && <p className="mt-0.5 text-[11px] text-ink-400">{hint}</p>}
    </div>
  );
}

/** Lightweight dependency-free bar chart. */
export function BarChart({ data, height = 160, money = true }: { data: { label: string; value: number }[]; height?: number; money?: boolean }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="w-full">
      <div className="flex items-end gap-1.5" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="group relative flex h-full flex-1 flex-col items-center justify-end">
            <div
              className="w-full min-h-[3px] rounded-t bg-gradient-to-t from-obah-600 to-obah-400 transition-all group-hover:from-obah-700"
              style={{ height: `${Math.max(2, (d.value / max) * 100)}%` }}
              title={`${d.label}: ${money ? NGN(d.value) : d.value}`}
            />
            {d.value > 0 && (
              <span className="pointer-events-none absolute -top-1 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded bg-ink-900 px-1.5 py-0.5 text-[9px] font-semibold text-white group-hover:block">
                {money ? NGN(d.value) : d.value}
              </span>
            )}
          </div>
        ))}
      </div>
      <div className="mt-1 flex gap-1.5">
        {data.map((d, i) => (
          <div key={i} className="flex-1 truncate text-center text-[9px] text-ink-400">
            {d.label}
          </div>
        ))}
      </div>
    </div>
  );
}
