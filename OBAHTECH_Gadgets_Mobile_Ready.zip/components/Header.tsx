import Link from 'next/link';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { cartCount } from '@/lib/cart';
import { Logo } from './ui';
import { MobileMenu } from './MobileMenu';
import { NotificationBell } from './NotificationBell';
import { logoutAction } from '@/lib/actions/auth';
import { IconCart, IconUser, IconHeart, IconGrid, IconBolt } from './icons';

export async function Header() {
  const db = getDb();
  const user = await getSessionUser();
  const cats = await db.prepare('SELECT name, slug, group_name FROM categories WHERE is_active = 1 ORDER BY sort_order').all() as any[];
  const count = await cartCount(user?.id);
  const wishCount = user
    ? ((await db.prepare('SELECT COUNT(*) c FROM wishlists WHERE user_id = ?').get(user.id) as any).c as number)
    : 0;
  const brandLinks = cats.filter((c) => c.group_name === 'Smartphones').slice(0, 6);
  const accessoryLinks = cats.filter((c) => c.group_name === 'Accessories').slice(0, 5);

  return (
    <header className="sticky top-0 z-40">
      {/* announcement bar */}
      <div className="bg-ink-800 text-white">
        <div className="container-obah flex h-8 items-center justify-between gap-3 overflow-hidden text-[11px]">
          <p className="truncate">
            <span className="font-bold text-obah-400">Nationwide delivery</span> · Free delivery on orders above ₦300,000 · 7-day returns
          </p>
          <div className="hidden shrink-0 items-center gap-3 sm:flex">
            <Link href="/support" className="hover:text-obah-300">Help</Link>
            <Link href="/track" className="hover:text-obah-300">Track order</Link>
            <span className="text-white/40">|</span>
            <Link href="/admin" className="font-semibold text-obah-300 hover:text-white">Admin</Link>
          </div>
        </div>
      </div>

      {/* main bar */}
      <div className="bg-gradient-to-r from-obah-500 via-obah-500 to-obah-400">
        <div className="container-obah flex items-center gap-3 py-2.5">
          <div className="lg:hidden">
            <MobileMenu categories={cats} user={user ? { name: user.full_name, role: user.role } : null} />
          </div>
          <div className="shrink-0 rounded-lg bg-white px-2 py-1">
            <Logo light={false} />
          </div>
          <form action="/search" className="hidden flex-1 md:block">
            <div className="flex overflow-hidden rounded-lg bg-white shadow-sm">
              <input
                name="q"
                placeholder="Search for phones, tablets, chargers, power banks…"
                className="w-full px-3 py-2.5 text-sm outline-none placeholder:text-ink-300"
                aria-label="Search products"
              />
              <button className="bg-ink-800 px-5 text-sm font-bold uppercase tracking-wide text-white hover:bg-ink-700">
                Search
              </button>
            </div>
          </form>
          <div className="ml-auto flex items-center gap-1 sm:gap-2">
            {user ? (
              <NotificationBell initialRole={user.role} />
            ) : null}
            <Link href={user ? '/wishlist' : '/login?next=/wishlist'} className="hidden items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-white hover:bg-white/15 sm:flex">
              <IconHeart size={17} />
              <span className="hidden lg:inline">Wishlist</span>
              {wishCount > 0 && <span className="rounded-full bg-white px-1.5 text-[10px] font-bold text-obah-600">{wishCount}</span>}
            </Link>
            {user ? (
              <div className="group relative">
                <button className="flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-white hover:bg-white/15">
                  <IconUser size={17} />
                  <span className="hidden max-w-[90px] truncate lg:inline">{user.full_name.split(' ')[0]}</span>
                  <span className="text-[9px]">▾</span>
                </button>
                <div className="invisible absolute right-0 top-full z-50 w-52 rounded-lg bg-white p-1.5 opacity-0 shadow-pop transition group-hover:visible group-hover:opacity-100">
                  <Link href="/account" className="block rounded px-3 py-2 text-sm text-ink-700 hover:bg-gray-50">My account</Link>
                  <Link href="/orders" className="block rounded px-3 py-2 text-sm text-ink-700 hover:bg-gray-50">My orders</Link>
                  <Link href="/account#warranties" className="block rounded px-3 py-2 text-sm text-ink-700 hover:bg-gray-50">Warranties</Link>
                  <Link href="/notifications" className="block rounded px-3 py-2 text-sm text-ink-700 hover:bg-gray-50">Notifications</Link>
                  {user.role !== 'customer' && (
                    <Link href="/admin" className="block rounded px-3 py-2 text-sm font-semibold text-obah-600 hover:bg-obah-50">Admin dashboard</Link>
                  )}
                  <form action={logoutAction}>
                    <button className="w-full rounded px-3 py-2 text-left text-sm text-rose-600 hover:bg-rose-50">Log out</button>
                  </form>
                </div>
              </div>
            ) : (
              <Link href="/login" className="flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-white hover:bg-white/15">
                <IconUser size={17} />
                <span className="hidden lg:inline">Sign in</span>
              </Link>
            )}
            <Link href="/cart" className="relative flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-white hover:bg-white/15">
              <IconCart size={18} />
              <span className="hidden lg:inline">Cart</span>
              <span className="grid h-5 min-w-5 place-items-center rounded-full bg-ink-800 px-1 text-[10px] font-bold text-white">{count}</span>
            </Link>
          </div>
        </div>
        <form action="/search" className="container-obah pb-2.5 md:hidden">
          <div className="flex overflow-hidden rounded-lg bg-white">
            <input name="q" placeholder="Search phones and accessories…" className="w-full px-3 py-2 text-sm outline-none" aria-label="Search products" />
            <button className="bg-ink-800 px-4 text-xs font-bold uppercase text-white">Go</button>
          </div>
        </form>
      </div>

      {/* category nav */}
      <div className="hidden border-b border-gray-200 bg-white shadow-sm lg:block">
        <div className="container-obah flex items-center gap-1 py-1.5 text-[13px]">
          <Link href="/category/all" className="flex items-center gap-1.5 rounded px-2.5 py-1.5 font-bold text-ink-800 hover:bg-obah-50 hover:text-obah-600">
            <IconGrid size={15} /> All categories
          </Link>
          <span className="mx-1 h-4 w-px bg-gray-200" />
          {brandLinks.map((c) => (
            <Link key={c.slug} href={`/category/${c.slug}`} className="rounded px-2 py-1.5 text-ink-500 hover:bg-obah-50 hover:text-obah-600">
              {c.name.replace(' Smartphones', '').replace(' & Xiaomi', '')}
            </Link>
          ))}
          <Link href="/category/tablets" className="rounded px-2 py-1.5 text-ink-500 hover:bg-obah-50 hover:text-obah-600">Tablets</Link>
          <Link href="/category/earphones-headphones" className="rounded px-2 py-1.5 text-ink-500 hover:bg-obah-50 hover:text-obah-600">Audio</Link>
          <Link href="/?flash=1" className="ml-auto rounded bg-rose-50 px-2.5 py-1.5 font-bold text-rose-600 hover:bg-rose-100">
            <span className="flex items-center gap-1"><IconBolt size={12} /> Flash sales</span>
          </Link>
        </div>
      </div>
    </header>
  );
}
