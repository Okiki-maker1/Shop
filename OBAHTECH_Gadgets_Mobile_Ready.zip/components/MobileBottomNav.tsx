'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { IconGrid, IconHeart, IconCart, IconUser, IconSearch } from './icons';

/** Mobile-first sticky bottom navigation (hidden on large screens). */
export function MobileBottomNav({ cartCount, signedIn }: { cartCount: number; signedIn: boolean }) {
  const pathname = usePathname() || '/';
  const items = [
    { href: '/', label: 'Home', Icon: IconGrid },
    { href: '/category/all', label: 'Browse', Icon: IconSearch },
    { href: signedIn ? '/wishlist' : '/login?next=/wishlist', label: 'Wishlist', Icon: IconHeart },
    { href: '/cart', label: 'Cart', Icon: IconCart, badge: cartCount },
    { href: signedIn ? '/account' : '/login', label: 'Account', Icon: IconUser },
  ];

  return (
    <nav
      aria-label="Mobile navigation"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-gray-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
    >
      <div className="flex items-stretch">
        {items.map(({ href, label, Icon, badge }) => {
          const active = href === '/' ? pathname === '/' : pathname.startsWith(href.split('?')[0]);
          return (
            <Link
              key={label}
              href={href}
              className={`relative flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-semibold ${
                active ? 'text-obah-600' : 'text-ink-400'
              }`}
            >
              <Icon size={19} />
              {label}
              {!!badge && badge > 0 && (
                <span className="absolute right-1/4 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-rose-600 px-1 text-[9px] font-bold text-white">
                  {badge}
                </span>
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
