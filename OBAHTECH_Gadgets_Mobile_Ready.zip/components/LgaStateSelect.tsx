'use client';

import { useMemo, useState } from 'react';

export type StateOpt = { id: number; name: string };
export type LgaOpt = { id: number; state_id: number; name: string };

/**
 * Dependent Nigerian State → LGA dropdowns.
 * Changing the state resets the LGA (and the backend re-validates the pair).
 */
export function LgaStateSelect({
  states,
  lgas,
  defaultStateId,
  defaultLgaId,
  required = true,
}: {
  states: StateOpt[];
  lgas: LgaOpt[];
  defaultStateId?: number | null;
  defaultLgaId?: number | null;
  required?: boolean;
}) {
  const [stateId, setStateId] = useState<string>(defaultStateId ? String(defaultStateId) : '');
  const [lgaId, setLgaId] = useState<string>(defaultLgaId ? String(defaultLgaId) : '');

  const options = useMemo(
    () => (stateId ? lgas.filter((l) => l.state_id === Number(stateId)) : []),
    [stateId, lgas],
  );

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div>
        <label className="label" htmlFor="state_id">State</label>
        <select
          id="state_id"
          name="state_id"
          required={required}
          value={stateId}
          onChange={(e) => {
            setStateId(e.target.value);
            setLgaId(''); // reset LGA whenever the state changes
          }}
          className="input"
        >
          <option value="">Select state…</option>
          {states.map((s) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </select>
      </div>
      <div>
        <label className="label" htmlFor="lga_id">Local Government Area</label>
        <select
          id="lga_id"
          name="lga_id"
          required={required}
          value={lgaId}
          disabled={!stateId}
          onChange={(e) => setLgaId(e.target.value)}
          className="input disabled:bg-gray-100"
        >
          <option value="">{stateId ? 'Select LGA…' : 'Choose a state first'}</option>
          {options.map((l) => (
            <option key={l.id} value={l.id}>{l.name}</option>
          ))}
        </select>
        {stateId && <p className="mt-1 text-[11px] text-ink-400">{options.length} LGAs in this state</p>}
      </div>
    </div>
  );
}
