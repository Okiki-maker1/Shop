// OBAHTECH Gadgets — database seeder (PostgreSQL).
// Applies to the database configured by DATABASE_URL (Supabase in production,
// local Postgres in development). The schema itself comes from
// supabase/migrations/0001_core_schema.sql — this script only loads data.
//
//   npm run seed           # seed if empty
//   npm run seed:reset     # truncate every table first, then seed
import fs from 'node:fs';
import path from 'node:path';
import { ensureSeeded } from '../lib/seed';
import { getDb, raw, closePool } from '../lib/db';

// Load .env.local the way Next.js does (tsx does not do this for us).
const envFile = path.join(process.cwd(), '.env.local');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split('\n')) {
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/.exec(line);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2];
  }
}

async function main() {
  const reset = process.argv.includes('--reset');

  if (reset) {
    const tables = (await raw(
      `SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename NOT LIKE 'pg_%' ORDER BY tablename`,
    )) as { tablename: string }[];
    if (tables.length) {
      const list = tables.map((t) => `"${t.tablename}"`).join(', ');
      await raw(`TRUNCATE ${list} RESTART IDENTITY CASCADE`);
      console.log(`reset: truncated ${tables.length} tables`);
    }
  }

  await ensureSeeded(getDb());

  const counts = [
    'states', 'lgas', 'users', 'categories', 'products', 'product_images',
    'orders', 'order_items', 'payments', 'notifications', 'warranties',
    'banners', 'promotions', 'delivery_fees', 'reviews', 'support_tickets',
  ];
  for (const t of counts) {
    const row = (await raw(`SELECT COUNT(*)::int AS c FROM ${t}`))[0] as any;
    console.log(t.padEnd(18), row.c);
  }

  await closePool();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
