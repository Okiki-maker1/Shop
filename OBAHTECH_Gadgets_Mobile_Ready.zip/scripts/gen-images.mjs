// Generates original OBAHTECH vector product artwork + brand marks.
// Pure SVG so it renders in any environment without external requests.
import fs from 'node:fs';
import path from 'node:path';

const OUT = path.join(process.cwd(), 'public');
fs.mkdirSync(path.join(OUT, 'products'), { recursive: true });
fs.mkdirSync(path.join(OUT, 'brand'), { recursive: true });

const TINTS = [
  { name: 'graphite', body: ['#4b5563', '#1f2937'], accent: '#9ca3af' },
  { name: 'midnight', body: ['#334155', '#0f172a'], accent: '#7dd3fc' },
  { name: 'violet', body: ['#6d28d9', '#312e81'], accent: '#c4b5fd' },
  { name: 'teal', body: ['#0f766e', '#134e4a'], accent: '#5eead4' },
  { name: 'coral', body: ['#be123c', '#7f1d1d'], accent: '#fda4af' },
  { name: 'sand', body: ['#d6c8a8', '#a8916b'], accent: '#fef3c7' },
];

const shadow = `<ellipse cx="200" cy="352" rx="118" ry="16" fill="#0f172a" opacity="0.10"/>`;
const bg = `<rect width="400" height="400" fill="url(#bg)"/>`;

function defs(t) {
  return `<defs>
    <radialGradient id="bg" cx="50%" cy="35%" r="75%">
      <stop offset="0%" stop-color="#ffffff"/><stop offset="100%" stop-color="#eef1f5"/>
    </radialGradient>
    <linearGradient id="body" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${t.body[0]}"/><stop offset="100%" stop-color="${t.body[1]}"/>
    </linearGradient>
    <linearGradient id="screen" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0b1220"/><stop offset="55%" stop-color="#182538"/><stop offset="100%" stop-color="#0b1220"/>
    </linearGradient>
    <linearGradient id="glow" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${t.accent}" stop-opacity="0.55"/><stop offset="100%" stop-color="${t.accent}" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="metal" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="45%" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="100%" stop-color="#ffffff" stop-opacity="0.35"/>
    </linearGradient>
    <filter id="soft"><feGaussianBlur stdDeviation="6"/></filter>
  </defs>`;
}

function phone(t) {
  return `<g>
    <rect x="128" y="52" width="144" height="288" rx="26" fill="url(#body)" stroke="#0f172a" stroke-opacity=".18"/>
    <rect x="134" y="58" width="132" height="276" rx="22" fill="url(#screen)"/>
    <rect x="134" y="58" width="132" height="276" rx="22" fill="url(#glow)" opacity=".5"/>
    <rect x="188" y="66" width="24" height="7" rx="3.5" fill="#0b1220"/>
    <rect x="238" y="104" width="34" height="46" rx="10" fill="#0b1220" opacity=".85"/>
    <circle cx="255" cy="118" r="7" fill="${t.accent}" opacity=".85"/>
    <circle cx="255" cy="137" r="7" fill="#94a3b8" opacity=".7"/>
    <rect x="134" y="58" width="132" height="276" rx="22" fill="url(#metal)" opacity=".25"/>
    <rect x="270" y="120" width="4" height="34" rx="2" fill="#cbd5e1"/>
    <rect x="126" y="96" width="4" height="26" rx="2" fill="#cbd5e1"/>
  </g>`;
}

function tablet(t) {
  return `<g>
    <rect x="92" y="76" width="216" height="252" rx="20" fill="url(#body)" stroke="#0f172a" stroke-opacity=".18"/>
    <rect x="98" y="82" width="204" height="240" rx="14" fill="url(#screen)"/>
    <rect x="98" y="82" width="204" height="240" rx="14" fill="url(#glow)" opacity=".45"/>
    <rect x="188" y="90" width="24" height="6" rx="3" fill="#0b1220"/>
    <rect x="98" y="82" width="204" height="240" rx="14" fill="url(#metal)" opacity=".2"/>
  </g>`;
}

function watch(t) {
  return `<g>
    <rect x="160" y="40" width="80" height="90" rx="22" fill="${t.body[1]}" opacity=".9"/>
    <rect x="160" y="266" width="80" height="90" rx="22" fill="${t.body[1]}" opacity=".9"/>
    <rect x="128" y="112" width="144" height="176" rx="42" fill="url(#body)" stroke="#0f172a" stroke-opacity=".2"/>
    <rect x="138" y="122" width="124" height="156" rx="34" fill="url(#screen)"/>
    <rect x="138" y="122" width="124" height="156" rx="34" fill="url(#glow)" opacity=".55"/>
    <circle cx="200" cy="200" r="40" fill="none" stroke="${t.accent}" stroke-width="6" opacity=".8" stroke-dasharray="180 70"/>
    <rect x="272" y="160" width="8" height="26" rx="4" fill="#cbd5e1"/>
  </g>`;
}

function earbuds(t) {
  return `<g>
    <rect x="150" y="212" width="124" height="96" rx="26" fill="url(#body)" stroke="#0f172a" stroke-opacity=".15"/>
    <rect x="168" y="236" width="88" height="48" rx="22" fill="#0b1220" opacity=".55"/>
    <g transform="translate(-6,-14)">
      <ellipse cx="160" cy="140" rx="26" ry="30" fill="url(#body)"/>
      <rect x="150" y="158" width="20" height="62" rx="10" fill="url(#body)"/>
      <ellipse cx="160" cy="140" rx="12" ry="14" fill="${t.accent}" opacity=".55"/>
    </g>
    <g transform="translate(94,-14)">
      <ellipse cx="160" cy="140" rx="26" ry="30" fill="url(#body)"/>
      <rect x="150" y="158" width="20" height="62" rx="10" fill="url(#body)"/>
      <ellipse cx="160" cy="140" rx="12" ry="14" fill="${t.accent}" opacity=".55"/>
    </g>
  </g>`;
}

function speaker(t) {
  return `<g>
    <rect x="118" y="122" width="164" height="196" rx="40" fill="url(#body)" stroke="#0f172a" stroke-opacity=".18"/>
    <rect x="136" y="142" width="128" height="120" rx="26" fill="url(#screen)"/>
    <circle cx="200" cy="202" r="42" fill="none" stroke="${t.accent}" stroke-width="5" opacity=".7"/>
    <circle cx="200" cy="202" r="20" fill="${t.accent}" opacity=".35"/>
    <rect x="176" y="286" width="48" height="8" rx="4" fill="#0b1220" opacity=".5"/>
  </g>`;
}

function charger(t) {
  return `<g>
    <rect x="140" y="120" width="120" height="140" rx="24" fill="url(#body)" stroke="#0f172a" stroke-opacity=".18"/>
    <rect x="176" y="96" width="14" height="30" rx="4" fill="#cbd5e1"/>
    <rect x="210" y="96" width="14" height="30" rx="4" fill="#cbd5e1"/>
    <rect x="166" y="170" width="68" height="18" rx="9" fill="#0b1220" opacity=".55"/>
    <circle cx="200" cy="224" r="10" fill="${t.accent}" opacity=".8"/>
  </g>`;
}

function powerbank(t) {
  return `<g>
    <rect x="128" y="108" width="144" height="196" rx="26" fill="url(#body)" stroke="#0f172a" stroke-opacity=".18"/>
    <rect x="146" y="130" width="108" height="120" rx="14" fill="url(#screen)"/>
    <circle cx="170" cy="268" r="6" fill="${t.accent}"/><circle cx="190" cy="268" r="6" fill="${t.accent}" opacity=".8"/>
    <circle cx="210" cy="268" r="6" fill="${t.accent}" opacity=".55"/><circle cx="230" cy="268" r="6" fill="#64748b"/>
    <rect x="126" y="150" width="4" height="46" rx="2" fill="#cbd5e1"/>
  </g>`;
}

function phonecase(t) {
  return `<g>
    <rect x="132" y="52" width="136" height="288" rx="30" fill="url(#body)" stroke="#0f172a" stroke-opacity=".2"/>
    <rect x="150" y="70" width="100" height="252" rx="22" fill="#ffffff" opacity=".08"/>
    <rect x="232" y="92" width="34" height="52" rx="12" fill="#0b1220" opacity=".55"/>
    <circle cx="249" cy="106" r="9" fill="${t.accent}" opacity=".7"/>
    <circle cx="249" cy="130" r="9" fill="#0b1220" opacity=".6"/>
  </g>`;
}

function glass(t) {
  return `<g>
    <rect x="132" y="52" width="136" height="288" rx="24" fill="#dbeafe" opacity=".55" stroke="#94a3b8" stroke-dasharray="8 6"/>
    <rect x="132" y="52" width="136" height="288" rx="24" fill="url(#metal)" opacity=".5"/>
    <path d="M150 300 L250 100" stroke="#ffffff" stroke-width="14" opacity=".55"/>
    <path d="M170 306 L266 130" stroke="${t.accent}" stroke-width="6" opacity=".35"/>
  </g>`;
}

function electronics(t) {
  return `<g>
    <rect x="84" y="112" width="232" height="168" rx="18" fill="url(#body)" stroke="#0f172a" stroke-opacity=".18"/>
    <rect x="96" y="124" width="208" height="128" rx="10" fill="url(#screen)"/>
    <rect x="96" y="124" width="208" height="128" rx="10" fill="url(#glow)" opacity=".4"/>
    <rect x="170" y="286" width="60" height="10" rx="5" fill="#94a3b8"/>
    <rect x="196" y="264" width="8" height="24" fill="#cbd5e1"/>
  </g>`;
}

const RENDER = {
  phone, tablet, watch, earbuds, speaker, charger, powerbank, phonecase, glass, electronics,
};

const kinds = Object.keys(RENDER);
let written = 0;
for (const kind of kinds) {
  TINTS.forEach((t, i) => {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400" role="img" aria-label="OBAHTECH ${kind} product illustration">
${defs(t)}
${bg}
${shadow}
${RENDER[kind](t)}
</svg>`;
    fs.writeFileSync(path.join(OUT, 'products', `${kind}-${i + 1}.svg`), svg);
    written++;
  });
}

// Brand marks -------------------------------------------------------------
const logoMark = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
  <rect width="64" height="64" rx="16" fill="#ff7d0f"/>
  <path d="M18 44c0-8 6-13 14-13s14 5 14 13" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round"/>
  <circle cx="32" cy="21" r="7" fill="#fff"/>
  <rect x="40" y="34" width="8" height="13" rx="4" fill="#1a1a1a"/>
</svg>`;
fs.writeFileSync(path.join(OUT, 'brand', 'logo-mark.svg'), logoMark);

const favicon = logoMark.replace('width="64" height="64"', 'width="32" height="32"');
fs.writeFileSync(path.join(OUT, 'favicon.svg'), favicon);

// Hero / promo abstract art used behind banner copy
const heroArt = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360">
  <defs>
    <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff9c38"/><stop offset="1" stop-color="#f26400"/></linearGradient>
    <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1f2937"/><stop offset="1" stop-color="#0b1220"/></linearGradient>
  </defs>
  <circle cx="470" cy="80" r="130" fill="#ffffff" opacity=".14"/>
  <circle cx="140" cy="300" r="90" fill="#ffffff" opacity=".10"/>
  <g transform="rotate(-12 400 200)">
    <rect x="330" y="60" width="150" height="290" rx="26" fill="url(#g2)" stroke="#ffffff" stroke-opacity=".35"/>
    <rect x="340" y="70" width="130" height="270" rx="20" fill="url(#g1)" opacity=".35"/>
    <rect x="392" y="80" width="26" height="7" rx="3.5" fill="#0b1220"/>
  </g>
  <g transform="rotate(10 180 210)">
    <rect x="120" y="130" width="110" height="180" rx="20" fill="#fff" opacity=".9"/>
    <rect x="130" y="140" width="90" height="160" rx="14" fill="url(#g2)" opacity=".85"/>
  </g>
</svg>`;
fs.writeFileSync(path.join(OUT, 'brand', 'hero-art.svg'), heroArt);

console.log(`Generated ${written} product illustrations + brand marks.`);
