// OBAHTECH Gadgets — end-to-end acceptance tests (the 10 required tests).
// Drives the running app over real HTTP (forms + server actions) and asserts
// against the database. Usage:  node scripts/e2e-tests.mjs   [BASE_URL]
import pg from 'pg';

const BASE = process.argv[2] || 'http://127.0.0.1:3000';
// The suite reads the same Postgres database the app writes to
// (DATABASE_URL: Supabase in production, local Postgres in development).
const { types } = pg;
types.setTypeParser(20, (v) => Number(v)); // int8 -> number
types.setTypeParser(1700, (v) => Number(v)); // numeric -> number
const pool = new pg.Pool({
  connectionString:
    process.env.DATABASE_URL || 'postgres://obahtech:obah_dev_pw@127.0.0.1:5432/obahtech',
  max: 4,
});

let pass = 0;
let fail = 0;
const results = [];
function check(name, condition, detail = '') {
  if (condition) {
    pass++;
    results.push(`  ✅ ${name}${detail ? ` — ${detail}` : ''}`);
  } else {
    fail++;
    results.push(`  ❌ ${name}${detail ? ` — ${detail}` : ''}`);
  }
}
const section = (t) => results.push(`\n${t}`);

// ── tiny HTTP session with cookie jar ──────────────────────────────────────
class Session {
  constructor(label = 'session') {
    this.jar = new Map();
    this.label = label;
  }
  cookieHeader() {
    return [...this.jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }
  store(res) {
    const raw = res.headers.getSetCookie?.() ?? [];
    for (const c of raw) {
      const [pair] = c.split(';');
      const idx = pair.indexOf('=');
      const k = pair.slice(0, idx).trim();
      const v = pair.slice(idx + 1).trim();
      if (v === '' || v === 'deleted') this.jar.delete(k);
      else this.jar.set(k, v);
    }
  }
  async get(path) {
    this.lastPath = path;
    const res = await fetch(BASE + path, { redirect: 'manual', headers: { cookie: this.cookieHeader() } });
    this.store(res);
    const text = await res.text();
    return { status: res.status, location: res.headers.get('location'), text };
  }
  async follow(path) {
    let r = await this.get(path);
    let hops = 0;
    while (r.status >= 300 && r.status < 400 && r.location && hops++ < 5) {
      const loc = r.location.startsWith('http') ? new URL(r.location) : new URL(r.location, BASE);
      r = await this.get(loc.pathname + loc.search);
    }
    return r;
  }
  async submit(page, predicate, fields = {}) {
    const html = typeof page === 'string' ? page : page.text;
    const form = parseForms(html).find(predicate);
    if (!form) throw new Error(`[${this.label}] form not found on ${html.length}B page (forms: ${parseForms(html).map((p) => Object.keys(p.fields).join('|')).join(' ; ')})`);
    const body = new FormData();
    for (const [k, v] of Object.entries({ ...form.fields, ...fields })) {
      if (k.startsWith('$ACTION')) continue;
      body.append(k, String(v));
    }
    body.append(form.actionField, '');
    const res = await fetch(BASE + (form.postTo || this.lastPath || '/'), {
      method: 'POST',
      body,
      redirect: 'manual',
      headers: { cookie: this.cookieHeader() },
    });
    this.store(res);
    const text = await res.text();
    let location = res.headers.get('location');
    // progressive-enhancement posts answer 303; some return 200 with RSC payload
    return { status: res.status, location, text, form };
  }
}

function parseForms(html) {
  const forms = [];
  const re = /<form([^>]*)>([\s\S]*?)<\/form>/g;
  let m;
  while ((m = re.exec(html))) {
    const attrs = m[1];
    const inner = m[2];
    const fields = {};
    const inputRe = /<(input|select|textarea)([^>]*)>/g;
    let i;
    let actionField = null;
    while ((i = inputRe.exec(inner))) {
      const tag = i[1];
      const a = i[2];
      const nameM = /name="([^"]*)"/.exec(a);
      if (!nameM) continue;
      const name = nameM[1];
      if (name.startsWith('$ACTION_ID_')) {
        actionField = name;
        continue;
      }
      if (tag === 'select') {
        const rest = inner.slice(i.index);
        const block = rest.slice(0, rest.indexOf('</select>') + 9);
        const sel = /<option[^>]*selected[^>]*value="([^"]*)"/.exec(block) || /<option[^>]*value="([^"]*)"/.exec(block);
        fields[name] = sel ? htmlDecode(sel[1]) : '';
        continue;
      }
      if (tag === 'textarea') {
        fields[name] = '';
        continue;
      }
      const valueM = /value="([^"]*)"/.exec(a);
      const typeM = /type="([^"]*)"/.exec(a);
      if (typeM && typeM[1] === 'file') continue;
      if (typeM && (typeM[1] === 'checkbox' || typeM[1] === 'radio')) continue;
      fields[name] = valueM ? htmlDecode(valueM[1]) : '';
    }
    const actionM = /action="([^"]*)"/.exec(attrs);
    forms.push({
      action: actionM ? htmlDecode(actionM[1]) : '',
      actionField,
      fields,
      inner,
      postTo: actionM && actionM[1].startsWith('/') ? actionM[1] : '',
    });
  }
  return forms;
}
const htmlDecode = (s) =>
  s.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'");

const hasFields = (...names) => (f) => names.every((n) => n in f.fields);
const hasFieldsAndText = (names, text) => (f) => names.every((n) => n in f.fields) && f.inner.includes(text);

// ── reference data ─────────────────────────────────────────────────────────
const toPg = (sql) => {
  let i = 0;
  return sql.replace(/\?/g, () => `$${++i}`);
};
const coerce = (v) => (typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v);
const q = async (sql, ...p) => (await pool.query(toPg(sql), p.map(coerce))).rows[0];
const all = async (sql, ...p) => (await pool.query(toPg(sql), p.map(coerce))).rows;
const users = Object.fromEntries((await all('SELECT * FROM users')).map((u) => [u.email, u]));
const states = Object.fromEntries((await all('SELECT * FROM states')).map((s) => [s.name, s]));
const lgaOf = async (state, name) => q('SELECT * FROM lgas WHERE state_id = ? AND name = ?', states[state].id, name);
const notifRecipients = async (orderId, type) =>
  (await all(
    `SELECT n.recipient_user_id, u.email FROM notifications n JOIN users u ON u.id = n.recipient_user_id
      WHERE n.order_id = ? AND n.type = ? ORDER BY n.id`,
    orderId,
    type,
  )).map((r) => r.email)
    .filter((v, i, a) => a.indexOf(v) === i);
const orderIdOf = async (orderNumber) => (await q('SELECT id FROM orders WHERE order_number = ?', orderNumber))?.id;

const stamp = Date.now().toString(36).toLowerCase();
const newLagosEmail = `test.lagos.${stamp}@example.com`;
const newRiversEmail = `test.rivers.${stamp}@example.com`;

async function registerCustomer(email, stateName, lgaName) {
  const s = new Session(email);
  const page = await s.get('/register');
  const lga = await lgaOf(stateName, lgaName);
  const res = await s.submit(page, hasFields('full_name', 'confirm_password', 'state_id', 'lga_id'), {
    full_name: `Test ${stateName} Buyer`,
    email,
    phone: '08031234567',
    password: 'BuyerPass#2026',
    confirm_password: 'BuyerPass#2026',
    state_id: states[stateName].id,
    lga_id: lga.id,
  });
  return { session: s, res };
}

async function placeOrder(session, slug, loc) {
  const product = await session.get(`/product/${slug}`);
  if (process.env.DEBUG) console.log('  debug product page', slug, product.status, product.location, product.text.length, (product.text.match(/<form/g) || []).length);
  const pid = parseForms(product.text).find(hasFields('product_id', 'qty', 'slug')).fields.product_id;
  const addRes = await session.submit(product, hasFields('product_id', 'qty', 'slug'), { product_id: pid, qty: 1 });
  const checkout = await session.get('/checkout');
  if (process.env.DEBUG) console.log('  debug add→', addRes.status, addRes.location, '| checkout', checkout.status, checkout.location, checkout.text.length, (checkout.text.match(/<form/g)||[]).length);
  const orderRes = await session.submit(checkout, hasFieldsAndText(['street', 'full_name', 'instructions'], 'Place order'), {
    full_name: 'Test Buyer',
    phone: '08031234567',
    email: '',
    address_id: 0,
    delivery_method: 'standard',
    street: '1 Test Street, Off Allen Avenue',
    instructions: 'Call on arrival',
    state_id: loc.stateId,
    lga_id: loc.lgaId,
  });
  const location = orderRes.location || '';
  const match = /\/payments\/(OBH-[A-Z0-9-]+)/.exec(location) || /OBH-[A-Z0-9-]+/.exec(orderRes.text);
  if (!match) throw new Error(`order not created — ${location} ${orderRes.text.slice(0, 200)}`);
  const orderNumber = match[1] && match[1].startsWith('OBH-') ? match[1] : match[0];
  return { orderNumber, pid };
}

async function paySandbox(session, orderNumber) {
  const order = await q('SELECT * FROM orders WHERE order_number = ?', orderNumber);
  const payment = await q('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1', order.id);
  const body = new FormData();
  body.append('tx_ref', payment.tx_ref);
  body.append('outcome', 'successful');
  const res = await fetch(`${BASE}/api/payment/sandbox`, {
    method: 'POST',
    body,
    redirect: 'manual',
    headers: { cookie: session.cookieHeader() },
  });
  return { status: res.status, location: res.headers.get('location'), txRef: payment.tx_ref };
}

async function run() {
  console.log(`\nOBAHTECH Gadgets — acceptance tests against ${BASE}\n${'='.repeat(64)}`);

  // ── TEST 1: customer registration with Lagos / Ikeja ────────────────────
  section('TEST 1 — Customer registration (Lagos State / Ikeja LGA)');
  const lagos = await registerCustomer(newLagosEmail, 'Lagos', 'Ikeja');
  if (process.env.DEBUG) console.log('  debug register →', lagos.res.status, lagos.res.location);
  const newUser = await q('SELECT * FROM users WHERE email = ?', newLagosEmail);
  check('Registration succeeds and creates the account', Boolean(newUser), newUser ? `user #${newUser.id}` : 'no user row');
  check(
    'Correct state is stored',
    newUser && newUser.state_id === states.Lagos.id,
    newUser ? `state_id=${newUser.state_id}` : '',
  );
  check(
    'Correct LGA is stored',
    newUser && newUser.lga_id === (await lgaOf('Lagos', 'Ikeja')).id,
    newUser ? `lga_id=${newUser.lga_id} (Ikeja)` : '',
  );
  check('Session is created after registration', lagos.session.jar.has('obah_session'));

  const rivers = await registerCustomer(newRiversEmail, 'Rivers', 'Port Harcourt');
  const riversUser = await q('SELECT * FROM users WHERE email = ?', newRiversEmail);
  check(
    'A Rivers customer can register with a Rivers LGA',
    riversUser && riversUser.state_id === states.Rivers.id && riversUser.lga_id === (await lgaOf('Rivers', 'Port Harcourt')).id,
  );
  // invalid state/LGA combination is rejected server-side
  const anonSession = new Session('anon-invalid');
  const badPage = await anonSession.get('/register');
  const bad = await anonSession.submit(badPage, hasFields('full_name', 'confirm_password', 'state_id', 'lga_id'), {
    full_name: 'Bad Pair',
    email: `bad.${stamp}@example.com`,
    phone: '08031234567',
    password: 'BuyerPass#2026',
    confirm_password: 'BuyerPass#2026',
    state_id: states.Kano.id,
    lga_id: (await lgaOf('Lagos', 'Ikeja')).id, // Lagos LGA submitted with Kano state
  });
  check(
    'Backend rejects a state/LGA mismatch',
    !(await q('SELECT id FROM users WHERE email = ?', `bad.${stamp}@example.com`)),
    `status ${bad.status}`,
  );

  // ── TEST 2: Lagos order → Lagos admin + super admin only ────────────────
  section('TEST 2 — New Lagos order routing');
  const lagosOrder = await placeOrder(lagos.session, 'samsung-galaxy-a55-5g-256gb', { stateId: newUser.state_id, lgaId: newUser.lga_id });
  const lagosOrderId = await orderIdOf(lagosOrder.orderNumber);
  const lagosNotifs = await notifRecipients(lagosOrderId, 'new_order');
  check('Order is created', Boolean(lagosOrderId), lagosOrder.orderNumber);
  check(
    'Lagos administrator is notified',
    lagosNotifs.includes('lagos@obahtech.ng'),
    lagosNotifs.join(', ') || 'none',
  );
  check('Super administrator is notified', lagosNotifs.includes('super@obahtech.ng'));
  check('No other state administrator is notified', lagosNotifs.length === 2 && !lagosNotifs.includes('rivers@obahtech.ng'), `${lagosNotifs.length} recipient(s)`);
  const assigned = await q('SELECT u.email, o.state_id FROM orders o LEFT JOIN users u ON u.id = o.assigned_admin_id WHERE o.id = ?', lagosOrderId);
  check('Order is auto-assigned to the Lagos administrator', assigned?.email === 'lagos@obahtech.ng');

  // ── TEST 3: Rivers order → Rivers admin + super admin only ──────────────
  section('TEST 3 — New Rivers order routing');
  const riversOrder = await placeOrder(rivers.session, 'infinix-note-40-pro-256gb', { stateId: riversUser.state_id, lgaId: riversUser.lga_id });
  const riversOrderId = await orderIdOf(riversOrder.orderNumber);
  const riversNotifs = await notifRecipients(riversOrderId, 'new_order');
  check('Rivers administrator is notified', riversNotifs.includes('rivers@obahtech.ng'), riversNotifs.join(', '));
  check('Super administrator is notified', riversNotifs.includes('super@obahtech.ng'));
  check('Lagos administrator receives nothing for the Rivers order', !riversNotifs.includes('lagos@obahtech.ng'));
  check('Rivers order is assigned to the Rivers administrator', (await q('SELECT assigned_admin_id FROM orders WHERE id = ?', riversOrderId)).assigned_admin_id === users['rivers@obahtech.ng'].id);

  // ── TEST 9 (run early so cancellation has a paid order): payment ────────
  section('TEST 9 — Flutterwave payment verification');
  const unverified = await lagos.session.get(`/payments/callback?tx_ref=FAKE-REF&transaction_id=999&status=successful`);
  check(
    'A forged callback cannot mark an order paid',
    (await q('SELECT payment_status FROM orders WHERE id = ?', lagosOrderId)).payment_status === 'unpaid',
    `callback answered ${unverified.status} → ${unverified.location || ''}`,
  );
  const paid = await paySandbox(lagos.session, lagosOrder.orderNumber);
  const paidOrder = await q('SELECT * FROM orders WHERE id = ?', lagosOrderId);
  const paidPayment = await q('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1', lagosOrderId);
  check('Payment settlement marks the order paid', paidOrder.payment_status === 'paid', `${paid.location}`);
  check('Order moves to payment_confirmed', paidOrder.status === 'payment_confirmed');
  check('Payment record is successful with a reference', paidPayment.status === 'successful' && Boolean(paidPayment.tx_ref));
  check('Sandbox payment is flagged as sandbox', paidPayment.sandbox === 1);
  // idempotency: replaying the same reference does not duplicate settlement
  const before = (await all('SELECT COUNT(*) c FROM transactions WHERE order_id = ?', lagosOrderId))[0].c;
  await paySandbox(lagos.session, lagosOrder.orderNumber);
  const after = (await all('SELECT COUNT(*) c FROM transactions WHERE order_id = ?', lagosOrderId))[0].c;
  check('Duplicate payment callbacks are idempotent', before === after, `${before} → ${after} transactions`);

  // ── TEST 4: cancellation request routing ───────────────────────────────
  section('TEST 4 — Order cancellation request routing');
  const orderPage = await lagos.session.get(`/orders/${lagosOrder.orderNumber}`);
  await lagos.session.submit(orderPage, hasFieldsAndText(['order_id', 'reason'], 'cancellation'), { reason: 'Ordered by mistake' });
  const lagosOrderAfter = await q('SELECT status FROM orders WHERE id = ?', lagosOrderId);
  const cancelNotifs = await notifRecipients(lagosOrderId, 'cancellation_requested');
  check('Order enters cancellation_requested', lagosOrderAfter.status === 'cancellation_requested', lagosOrderAfter.status);
  check('Lagos administrator gets the cancellation alert', cancelNotifs.includes('lagos@obahtech.ng'), cancelNotifs.join(', '));
  check('Super administrator gets the cancellation alert', cancelNotifs.includes('super@obahtech.ng'));
  check('No other state administrator gets the cancellation alert', cancelNotifs.length === 2);

  // ── TEST 5: warranty claim routing ─────────────────────────────────────
  section('TEST 5 — Warranty claim routing');
  const demoSession = new Session('demo-customer');
  const loginPage = await demoSession.get('/login');
  await demoSession.submit(loginPage, hasFields('email', 'password'), { email: 'demo@obahtech.ng', password: 'Customer#2026' });
  const account = await demoSession.get('/account');
  const claimForm = parseForms(account.text).find(hasFieldsAndText(['warranty_id', 'issue'], 'warranty'));
  check('Customer sees a warranty record with a claim form', Boolean(claimForm));
  let claimOrderId = null;
  if (claimForm) {
    const warranty = await q('SELECT * FROM warranties WHERE id = ?', claimForm.fields.warranty_id);
    claimOrderId = warranty.order_id;
    await demoSession.submit(account, hasFieldsAndText(['warranty_id', 'issue'], 'warranty'), { issue: 'Screen flickers intermittently' });
  }
  const claim = claimOrderId ? await q("SELECT * FROM warranty_claims WHERE order_id = ? ORDER BY id DESC LIMIT 1", claimOrderId) : null;
  const claimNotifs = claimOrderId ? await notifRecipients(claimOrderId, 'warranty_claim') : [];
  const claimOrderState = claimOrderId ? (await q('SELECT state_id FROM orders WHERE id = ?', claimOrderId)).state_id : null;
  const stateAdminEmail = claimOrderState ? (await q("SELECT email FROM users WHERE role='state_admin' AND admin_state_id = ?", claimOrderState))?.email : null;
  check('Warranty claim is recorded', Boolean(claim), claim ? `claim #${claim.id}` : 'no claim');
  check('The assigned state administrator is notified', Boolean(stateAdminEmail) && claimNotifs.includes(stateAdminEmail), `expected ${stateAdminEmail}, got ${claimNotifs.join(', ')}`);
  check('The super administrator is notified', claimNotifs.includes('super@obahtech.ng'));
  check('No unrelated state administrator is notified', claimNotifs.length === 2);

  // ── TEST 6: administrator deletion ─────────────────────────────────────
  section('TEST 6 — Administrator deletion');
  const superSession = new Session('super-admin');
  const superLogin = await superSession.get('/login');
  await superSession.submit(superLogin, hasFields('email', 'password'), { email: 'super@obahtech.ng', password: 'SuperAdmin#2026' });
  // provision a throwaway Ogun administrator, then delete it
  const adminsPage = await superSession.get('/admin/admins');
  const ogunEmail = `ogun.test.${stamp}@obahtech.ng`;
  await superSession.submit(adminsPage, hasFields('full_name', 'email', 'state_id', 'password'), {
    full_name: 'Throwaway Ogun Admin',
    email: ogunEmail,
    phone: '08030009999',
    state_id: states.Ogun.id,
    password: 'TempPass#2026',
  });
  const throwaway = await q('SELECT * FROM users WHERE email = ?', ogunEmail);
  check('Super admin can provision a state administrator', Boolean(throwaway) && throwaway.role === 'state_admin');
  const adminSession = new Session('throwaway-admin');
  const aLogin = await adminSession.get('/login');
  await adminSession.submit(aLogin, hasFields('email', 'password'), { email: ogunEmail, password: 'TempPass#2026' });
  const adminHome = await adminSession.get('/admin');
  check('Provisioned administrator can sign in to the console', adminHome.status === 200);
  const ordersBefore = (await all('SELECT COUNT(*) c FROM orders'))[0].c;
  const refreshed = await superSession.get('/admin/admins');
  const deletePredicate = (f) =>
    f.fields.id === String(throwaway.id) &&
    Object.keys(f.fields).length === 1 &&
    f.inner.toLowerCase().includes('delete');
  const deleteForm = parseForms(refreshed.text).find(deletePredicate);
  check('Delete control is present for the administrator', Boolean(deleteForm));
  if (deleteForm) await superSession.submit(refreshed, deletePredicate, {});
  const deleted = await q('SELECT * FROM users WHERE id = ?', throwaway.id);
  const ordersAfter = (await all('SELECT COUNT(*) c FROM orders'))[0].c;
  check('Administrator access is revoked', deleted.is_active === 0 && deleted.is_suspended === 1);
  const revoked = await adminSession.get('/admin');
  check('Deleted administrator can no longer open the console', revoked.status >= 300 && revoked.status < 400, `status ${revoked.status}`);
  check('Historical orders are preserved', ordersBefore === ordersAfter, `${ordersBefore} → ${ordersAfter}`);
  check(
    'Super admin is notified of the change',
    Boolean(await q("SELECT id FROM notifications WHERE type = 'admin_change' ORDER BY id DESC LIMIT 1")),
  );

  // ── TEST 7: banner lifecycle ───────────────────────────────────────────
  section('TEST 7 — Banner management reflected on the storefront');
  const bannerTitle = `Smoke Banner ${stamp}`;
  const bannersPage = await superSession.get('/admin/banners');
  await superSession.submit(bannersPage, hasFields('title', 'cta_link', 'placement'), {
    title: bannerTitle,
    subtitle: 'Created by the automated acceptance test',
    promo_text: 'TEST',
    cta_label: 'Shop now',
    cta_link: '/category/all',
    bg_style: 'teal',
    placement: 'promo_strip',
    sort_order: '0',
    is_active: '1',
  });
  const bannerRow = await q('SELECT * FROM banners WHERE title = ?', bannerTitle);
  check('Banner is created in the database', Boolean(bannerRow));
  const homeWithBanner = await new Session('anon').get('/');
  check('Banner appears on the customer homepage', homeWithBanner.text.includes(bannerTitle));
  const bannersPage2 = await superSession.get('/admin/banners');
  const bannerDeletePredicate = (f) =>
    f.fields.id === String(bannerRow.id) && Object.keys(f.fields).length === 1 && f.inner.toLowerCase().includes('delete');
  const bannerDelete = parseForms(bannersPage2.text).find(bannerDeletePredicate);
  check('Delete control is present for the banner', Boolean(bannerDelete));
  if (bannerDelete) await superSession.submit(bannersPage2, bannerDeletePredicate, {});
  const homeAfterDelete = await new Session('anon').get('/');
  check('Deleted banner disappears from the homepage', !homeAfterDelete.text.includes(bannerTitle));

  // ── TEST 8: customer announcement ──────────────────────────────────────
  section('TEST 8 — Customer announcement');
  const announcementTitle = `Weekend deals ${stamp}`;
  const notifAdminPage = await superSession.get('/admin/notifications');
  await superSession.submit(notifAdminPage, hasFields('title', 'body', 'audience'), {
    title: announcementTitle,
    body: 'Fresh Tecno and Infinix stock has arrived. Free delivery above ₦300,000.',
    audience: 'all',
    email: 'on',
  });
  const ann = await q('SELECT * FROM announcements WHERE title = ?', announcementTitle);
  check('Announcement is stored and delivered', Boolean(ann) && ann.recipients > 0, ann ? `${ann.recipients} recipients` : 'none');
  const delivered = (await q("SELECT COUNT(*) c FROM notifications WHERE type = 'announcement' AND title = ?", announcementTitle)).c;
  check('Selected customers receive the in-app notification', delivered > 0, `${delivered} notification rows`);
  const customerFeed = await lagos.session.get('/notifications');
  check('The new customer sees it in their notification feed', customerFeed.text.includes(announcementTitle));

  // ── TEST 10: state isolation enforced ──────────────────────────────────
  section('TEST 10 — State-based access control');
  const lagosAdmin = new Session('lagos-admin');
  const laLogin = await lagosAdmin.get('/login');
  await lagosAdmin.submit(laLogin, hasFields('email', 'password'), { email: 'lagos@obahtech.ng', password: 'StateAdmin#2026' });
  const ownOrder = await lagosAdmin.get(`/admin/orders/${lagosOrderId}`);
  check('Lagos administrator can open a Lagos order', ownOrder.status === 200, `status ${ownOrder.status}`);
  const crossState = await lagosAdmin.get(`/admin/orders/${riversOrderId}`);
  check(
    'Lagos administrator is blocked from a Rivers order',
    crossState.status >= 300 && crossState.status < 400 && /error|denied/i.test(crossState.location || ''),
    `status ${crossState.status} → ${crossState.location || ''}`,
  );
  const crossList = await lagosAdmin.get('/admin/orders');
  check('Lagos order list contains no Rivers order numbers', !crossList.text.includes(riversOrder.orderNumber));
  const crossReports = await lagosAdmin.get('/api/admin/report?type=orders');
  check('CSV export is also state-scoped', !crossReports.text.includes(riversOrder.orderNumber));
  check('Lagos admin cannot reach super-admin admin management', (await lagosAdmin.get('/admin/admins')).status >= 300);
  check('Lagos admin sees their own state sales only', (await lagosAdmin.get('/admin/analytics')).status === 200);

  // ── Extra: unassigned queue for states without an administrator ─────────
  section('EXTRA — Unassigned queue and delivery pricing');
  const bauchiBuyer = await registerCustomer(`test.bauchi.${stamp}@example.com`, 'Bauchi', 'Bauchi');
  const bauchiUser = await q('SELECT * FROM users WHERE email = ?', `test.bauchi.${stamp}@example.com`);
  const bauchiOrder = await placeOrder(bauchiBuyer.session, 'itel-a70-128gb', { stateId: bauchiUser.state_id, lgaId: bauchiUser.lga_id });
  const bId = await orderIdOf(bauchiOrder.orderNumber);
  const bNotifs = await notifRecipients(bId, 'new_order');
  check('Order to a state without an administrator is left unassigned', (await q('SELECT assigned_admin_id FROM orders WHERE id = ?', bId)).assigned_admin_id === null);
  check('Only the super admin is notified for the unassigned order', bNotifs.length === 1 && bNotifs[0] === 'super@obahtech.ng', bNotifs.join(', '));
  const bauchiFee = (await q('SELECT delivery_fee FROM orders WHERE id = ?', bId)).delivery_fee;
  check('Delivery fee is applied from state rules', bauchiFee > 0, `₦${bauchiFee}`);

  console.log(results.join('\n'));
  console.log(`\n${'='.repeat(64)}\nRESULT: ${pass} passed, ${fail} failed, ${pass + fail} assertions\n`);
  process.exit(fail ? 1 : 0);
}

run().catch((e) => {
  console.log(results.join('\n'));
  console.error('\nSUITE ERROR:', e.message);
  process.exit(2);
});
