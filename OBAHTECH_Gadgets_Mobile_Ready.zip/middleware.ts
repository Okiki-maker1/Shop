import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * Exposes the request path to server components (used to render the storefront
 * header/footer only outside the admin console) and adds baseline security
 * headers to every response.
 */
export function middleware(req: NextRequest) {
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set('x-pathname', req.nextUrl.pathname);

  const res = NextResponse.next({ request: { headers: requestHeaders } });
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('X-Frame-Options', 'SAMEORIGIN');
  res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  return res;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|products|brand|uploads).*)'],
};
