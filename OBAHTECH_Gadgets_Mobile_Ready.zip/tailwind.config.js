/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        obah: {
          50: '#fff8ed',
          100: '#ffefd4',
          200: '#ffdba8',
          300: '#ffc071',
          400: '#ff9c38',
          500: '#ff7d0f', // primary OBAHTECH orange
          600: '#f26400',
          700: '#c94c02',
          800: '#a03c0a',
          900: '#81330c',
        },
        ink: {
          800: '#1a1a1a',
          700: '#2b2b2b',
          500: '#555555',
          400: '#767676',
          300: '#9a9a9a',
        },
      },
      boxShadow: {
        card: '0 1px 2px rgba(0,0,0,.06), 0 2px 8px rgba(0,0,0,.05)',
        pop: '0 10px 30px rgba(0,0,0,.12)',
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', 'system-ui', '-apple-system', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
      },
      keyframes: {
        'slide-down': { '0%': { opacity: 0, transform: 'translateY(-6px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } },
        'fade-in': { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
        marquee: { '0%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(-50%)' } },
      },
      animation: {
        'slide-down': 'slide-down .18s ease-out',
        'fade-in': 'fade-in .25s ease-out',
        marquee: 'marquee 26s linear infinite',
      },
    },
  },
  plugins: [],
};
