-- ══════════════════════════════════════════════════════════════════════════════
-- OBAHTECH Gadgets — helper functions & Supabase Realtime publication
-- Carried over from the project's existing Supabase schema (supabase/schema.sql)
-- so those objects are preserved 1:1. Safe to re-run.
-- ══════════════════════════════════════════════════════════════════════════════

-- Atomic stock reservation (prevents overselling under concurrency).
create or replace function reserve_stock(p_product_id bigint, p_qty int)
returns void language plpgsql security definer as $$
begin
  update products
     set stock = stock - p_qty,
         reserved = reserved + p_qty
   where id = p_product_id
     and (stock - reserved) >= p_qty;
  if not found then
    raise exception 'INSUFFICIENT_STOCK:%', p_product_id;
  end if;
end;
$$;

-- Return reserved stock (cancellations, failed payments, returns).
create or replace function release_stock(p_product_id bigint, p_qty int)
returns void language plpgsql security definer as $$
begin
  update products
     set stock = stock + p_qty,
         reserved = greatest(reserved - p_qty, 0)
   where id = p_product_id;
end;
$$;

-- Realtime publication — exists on Supabase only; on plain PostgreSQL the
-- block is a no-op. Each table is added only once (idempotent).
do $$
begin
  if not exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    return;
  end if;
  if not exists (
    select 1 from pg_publication_rel pr
      join pg_publication p on p.oid = pr.prpubid
     where p.pubname = 'supabase_realtime' and pr.prrelid = 'notifications'::regclass
  ) then
    alter publication supabase_realtime add table notifications;
  end if;
  if not exists (
    select 1 from pg_publication_rel pr
      join pg_publication p on p.oid = pr.prpubid
     where p.pubname = 'supabase_realtime' and pr.prrelid = 'orders'::regclass
  ) then
    alter publication supabase_realtime add table orders;
  end if;
  if not exists (
    select 1 from pg_publication_rel pr
      join pg_publication p on p.oid = pr.prpubid
     where p.pubname = 'supabase_realtime' and pr.prrelid = 'order_events'::regclass
  ) then
    alter publication supabase_realtime add table order_events;
  end if;
end $$;
