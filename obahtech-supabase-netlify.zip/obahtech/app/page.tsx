import Link from 'next/link';
import { getDb } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';
import { activeBanners, categories, listProducts, reviewsShowcase, wishlistIds } from '@/lib/queries';
import { ProductCard } from '@/components/ProductCard';
import { SectionHeader, Stars, Alert } from '@/components/ui';
import { NGN, disc } from '@/lib/format';
import { IconTruck, IconShield, IconReturn } from '@/components/icons';

export const dynamic = 'force-dynamic';

function categoryArt(slug: string, idx: number) {
  const t = (idx % 6) + 1;
  if (slug === 'tablets') return `tablet-${t}`;
  if (slug === 'smartwatches') return `watch-${t}`;
  if (slug === 'bluetooth-speakers') return `speaker-${t}`;
  if (slug === 'earphones-headphones') return `earbuds-${t}`;
  if (slug === 'phone-chargers') return `charger-${t}`;
  if (slug === 'power-banks') return `powerbank-${t}`;
  if (slug === 'phone-cases') return `phonecase-${t}`;
  if (slug === 'screen-protectors') return `glass-${t}`;
  if (slug === 'other-electronics') return `electronics-${t}`;
  return `phone-${t}`;
}

const HERO_BG: Record<string, string> = {
  orange: 'from-obah-500 via-obah-500 to-obah-600',
  dark: 'from-ink-800 via-ink-700 to-slate-700',
  teal: 'from-teal-600 via-teal-600 to-emerald-700',
  coral: 'from-rose-600 via-rose-600 to-orange-600',
  navy: 'from-slate-800 via-slate-700 to-indigo-800',
};

export default async function HomePage({ searchParams }: { searchParams: { flash?: string; newsletter?: string } }) {
  const db = getDb();
  const user = await getSessionUser();
  const wished = await wishlistIds(user?.id);
  const heroBanners = await activeBanners('home_hero');
  const promos = await activeBanners('promo_strip');
  const cats = await categories();

  const flash = await listProducts({ flash: true, perPage: 6, sort: 'discount' });
  const bestSellers = await db
    .prepare(
      `SELECT p.id, p.name, p.slug, p.brand, p.price, p.compare_price, p.is_flash_sale, p.flash_price,
              p.rating_avg, p.rating_count, p.stock, p.reserved, p.ram, p.storage_options, p.warranty_months,
              (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
         FROM products p JOIN categories c ON c.id = p.category_id
        WHERE p.is_active = 1 AND c.group_name = 'Smartphones'
        ORDER BY p.sold DESC, p.rating_count DESC LIMIT 6`,
    )
    .all() as any[];
  const featured = await listProducts({ featured: true, perPage: 8 });
  const latest = await listProducts({ sort: 'newest', perPage: 6 });
  const offers = await listProducts({ sort: 'discount', perPage: 6 });
  const recommended = await listProducts({ sort: 'rating', perPage: 6 });
  const reviews = await reviewsShowcase();
  const stats = await db
    .prepare(
      `SELECT (SELECT COUNT(*) FROM products WHERE is_active = 1) products,
              (SELECT COUNT(*) FROM orders) orders,
              (SELECT COUNT(DISTINCT state_id) FROM orders) states,
              (SELECT COUNT(*) FROM users WHERE role = 'customer') customers`,
    )
    .get() as any;

  return (
    <div className="pb-4">
      {searchParams.newsletter === 'ok' && (
        <div className="container-obah pt-3"><Alert tone="success">You are subscribed. Watch your inbox for deals.</Alert></div>
      )}

      {/* HERO */}
      <section className="container-obah pt-3">
        <div className="grid gap-3 lg:grid-cols-[1.6fr_1fr]">
          <div className="relative overflow-hidden rounded-xl">
            {heroBanners[0] ? (
              <Link href={heroBanners[0].cta_link || '/category/all'} className={`block bg-gradient-to-br ${HERO_BG[heroBanners[0].bg_style] ?? HERO_BG.orange} p-5 sm:p-7`}>
                <img src="/brand/hero-art.svg" alt="" className="pointer-events-none absolute -right-6 -top-4 w-52 opacity-40 sm:w-72 sm:opacity-60" />
                <div className="relative max-w-md">
                  <span className="inline-block rounded-full bg-white/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-white">
                    {heroBanners[0].promo_text || 'OBAHTECH Gadgets'}
                  </span>
                  <h1 className="mt-2 text-2xl font-extrabold leading-tight text-white sm:text-4xl">{heroBanners[0].title}</h1>
                  <p className="mt-2 max-w-sm text-xs leading-relaxed text-white/90 sm:text-sm">{heroBanners[0].subtitle}</p>
                  <span className="mt-4 inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-xs font-bold uppercase tracking-wide text-ink-800 shadow-sm">
                    {heroBanners[0].cta_label || 'Shop now'} →
                  </span>
                </div>
              </Link>
            ) : (
              <div className="bg-gradient-to-br from-obah-500 to-obah-600 p-7">
                <h1 className="text-3xl font-extrabold text-white">Genuine gadgets, delivered nationwide</h1>
              </div>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-1">
            {heroBanners.slice(1, 3).map((b) => (
              <Link key={b.id} href={b.cta_link || '/category/all'} className={`flex flex-col justify-between rounded-xl bg-gradient-to-br ${HERO_BG[b.bg_style] ?? HERO_BG.dark} p-4`}>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/70">{b.promo_text}</p>
                  <p className="mt-1 text-sm font-extrabold leading-snug text-white sm:text-base">{b.title}</p>
                </div>
                <span className="mt-2 text-[11px] font-bold text-white/90">{b.cta_label} →</span>
              </Link>
            ))}
            <div className="col-span-2 grid grid-cols-3 gap-2 rounded-xl bg-white p-3 shadow-card lg:col-span-1">
              {[
                [IconTruck, 'Nationwide', '36 states + FCT'],
                [IconShield, 'Warranty', 'Up to 12 months'],
                [IconReturn, '7-day', 'Easy returns'],
              ].map(([Icon, t, s2]: any) => (
                <div key={t} className="text-center">
                  <Icon size={18} className="mx-auto text-obah-500" />
                  <p className="text-[11px] font-bold text-ink-800">{t}</p>
                  <p className="text-[10px] text-ink-400">{s2}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PROMO STRIP */}
      {promos.length > 0 && (
        <section className="container-obah space-y-2 pt-3">
          {promos.map((promo) => (
            <Link
              key={promo.id}
              href={promo.cta_link || '/category/all'}
              className={`flex flex-wrap items-center justify-between gap-2 rounded-xl bg-gradient-to-r ${
                promo.bg_style === 'dark' ? 'from-ink-800 to-slate-700' : promo.bg_style === 'teal' ? 'from-teal-600 to-emerald-700' : 'from-rose-600 to-orange-500'
              } px-4 py-2.5 text-white`}
            >
              <p className="text-sm font-bold">
                {promo.title} <span className="hidden font-normal text-white/80 sm:inline">— {promo.subtitle}</span>
              </p>
              <span className="rounded bg-white/20 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide">{promo.cta_label} →</span>
            </Link>
          ))}
        </section>
      )}

      {/* CATEGORIES */}
      <section className="container-obah pt-4">
        <div className="card p-3">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wide text-ink-800">Shop by category</h2>
            <Link href="/category/all" className="text-[11px] font-bold uppercase text-obah-600">View all →</Link>
          </div>
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-6 lg:grid-cols-9">
            {cats.map((c, idx) => (
              <Link key={c.slug} href={`/category/${c.slug}`} className="group flex flex-col items-center gap-1 rounded-lg p-1.5 text-center hover:bg-obah-50">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-gray-50 ring-1 ring-gray-100 transition group-hover:ring-obah-300">
                  <img src={`/products/${categoryArt(c.slug, idx)}.svg`} alt="" className="h-8 w-8 object-contain" />
                </span>
                <span className="text-[10px] font-semibold leading-tight text-ink-500 group-hover:text-obah-600">{c.name.replace(' Smartphones', '')}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FLASH SALES */}
      {flash.items.length > 0 && (
        <section className="container-obah pt-5">
          <div className="rounded-xl bg-white p-3 shadow-card">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <h2 className="section-title text-rose-600">⚡ Flash sales</h2>
                <span className="rounded bg-rose-50 px-2 py-0.5 text-[10px] font-bold uppercase text-rose-600 ring-1 ring-rose-200">
                  Limited stock
                </span>
              </div>
              <Link href="/?flash=1" className="text-[11px] font-bold uppercase tracking-wide text-obah-600">See all deals →</Link>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {flash.items.map((p) => (
                <ProductCard key={p.id} p={p as any} wished={wished.has(p.id)} compact />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* BEST SELLING */}
      <section className="container-obah pt-5">
        <SectionHeader title="Best-selling smartphones" subtitle="What Nigeria is buying this week" href="/category/all?sort=popular" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {bestSellers.map((p) => (
            <ProductCard key={p.id} p={p} wished={wished.has(p.id)} />
          ))}
        </div>
      </section>

      {/* FEATURED */}
      <section className="container-obah pt-6">
        <SectionHeader title="Featured products" subtitle="Handpicked by the OBAHTECH team" href="/category/all?featured=1" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {featured.items.map((p) => (
            <ProductCard key={p.id} p={p as any} wished={wished.has(p.id)} />
          ))}
        </div>
      </section>

      {/* SPECIAL OFFERS */}
      <section className="container-obah pt-6">
        <div className="rounded-xl bg-gradient-to-br from-obah-50 to-white p-3 ring-1 ring-obah-100">
          <SectionHeader title="Special offers" subtitle="Biggest savings right now" href="/category/all?sort=discount" />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {offers.items.map((p) => (
              <ProductCard key={p.id} p={p as any} wished={wished.has(p.id)} compact />
            ))}
          </div>
        </div>
      </section>

      {/* LATEST + RECOMMENDED */}
      <section className="container-obah grid gap-5 pt-6 lg:grid-cols-2">
        <div>
          <SectionHeader title="Latest arrivals" href="/category/all?sort=newest" />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {latest.items.slice(0, 6).map((p) => (
              <ProductCard key={p.id} p={p as any} wished={wished.has(p.id)} compact />
            ))}
          </div>
        </div>
        <div>
          <SectionHeader title="Recommended for you" href="/category/all?sort=rating" />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {recommended.items.slice(0, 6).map((p) => (
              <ProductCard key={p.id} p={p as any} wished={wished.has(p.id)} compact />
            ))}
          </div>
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section className="container-obah pt-7">
        <div className="card p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="section-title">What customers say</h2>
            <div className="flex items-center gap-3 text-[11px] text-ink-400">
              <span className="font-bold text-ink-800">{stats.customers}</span> customers ·
              <span className="font-bold text-ink-800">{stats.orders}</span> orders ·
              <span className="font-bold text-ink-800">{stats.states}</span> states served
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {reviews.slice(0, 6).map((r) => (
              <div key={r.id} className="rounded-lg border border-gray-100 p-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold text-ink-800">{r.author}</p>
                  <Stars rating={r.rating} />
                </div>
                <p className="mt-1 text-[11px] font-semibold text-obah-600">{r.title}</p>
                <p className="mt-0.5 line-clamp-3 text-[11px] leading-relaxed text-ink-500">{r.body}</p>
                <Link href={`/product/${r.product_slug}`} className="mt-2 flex items-center gap-2 rounded bg-gray-50 p-1.5">
                  <img src={r.image} alt="" className="h-7 w-7 object-contain" />
                  <span className="truncate text-[10px] font-semibold text-ink-600">{r.product_name}</span>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SUPPORT */}
      <section className="container-obah pt-6">
        <div className="grid gap-3 sm:grid-cols-3">
          {[
            ['Need help choosing?', 'Talk to a gadget advisor on WhatsApp or call 0800 OBAH TECH.', '/support', 'Contact support'],
            ['Delivery to all 36 states', 'Automatic assignment to the OBAHTECH administrator for your state.', '/track', 'Track an order'],
            ['Genuine products only', 'Every phone ships with an IMEI record and a configurable warranty.', '/support#warranty', 'Warranty policy'],
          ].map(([t, d, href, cta]) => (
            <div key={t} className="card p-4">
              <p className="text-sm font-bold text-ink-800">{t}</p>
              <p className="mt-1 text-[11px] leading-relaxed text-ink-500">{d}</p>
              <Link href={href} className="mt-2 inline-block text-[11px] font-bold uppercase tracking-wide text-obah-600">{cta} →</Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
