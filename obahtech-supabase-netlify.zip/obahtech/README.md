# OBAHTECH GADGETS — Nigerian e-commerce marketplace

A complete, working marketplace for phones, tablets and accessories in Nigeria: real database, real auth,
real Flutterwave payment verification, real admin workflows — not a clickable mock-up.

**Stack**: Next.js 14 (App Router, server actions) · React 18 · TypeScript · Tailwind CSS · **Supabase PostgreSQL**
(via `pg`, works on any Postgres) · Flutterwave v3 (NGN) · **Netlify-ready** (`netlify.toml` + Next plugin included)

**Brand**: OBAHTECH GADGETS · orange `#ff7d0f` on white with dark ink text · mobile-first · Naira (₦) only · Nigeria only.
All artwork (logo, 60 product illustrations, icons) is original SVG made for this project.

---

## 1. Run it

```bash
cd obahtech
npm install

# 1. point the app at a Postgres database (Supabase or local Postgres)
#    .env.local → DATABASE_URL=postgres://user:pass@host:5432/dbname
#    (a working .env.local for the local dev database is already present)

# 2. create the schema — run once, in the Supabase SQL editor or psql:
psql "$DATABASE_URL" -f supabase/schema.sql
#    (identical to supabase/migrations/0001_core_schema.sql + 0002_functions.sql;
#     every statement is idempotent, so re-running is safe)

# 3. seed the demo catalogue
npm run seed                # or: npm run seed:reset  (truncate + reseed)

# 4. run it
npm run dev                 # http://localhost:3000
```

`npm run build && npm start` also works (verified — see §11).

### Demo accounts

| Role | Email | Password | Scope |
|---|---|---|---|
| Super administrator | `super@obahtech.ng` | `SuperAdmin#2026` | Nationwide, all modules |
| Lagos state admin | `lagos@obahtech.ng` | `StateAdmin#2026` | Lagos orders only |
| Rivers state admin | `rivers@obahtech.ng` | `StateAdmin#2026` | Rivers orders only |
| Oyo / Ogun / Kano / FCT / Anambra / Delta admins | `<state>@obahtech.ng` | `StateAdmin#2026` | Their state only |
| Customer | `demo@obahtech.ng` | `Customer#2026` | Shopper with orders + warranty |

Promo codes seeded: `OBAH10` (10% off), `FREESHIP` (delivery on us), `GADGET5K` (₦5,000 off).

> These are **demo** accounts created by the seed script. In production the super admin is created only through
> the one-time `/setup` wizard, which self-locks the moment a super admin exists (optionally guarded by `SETUP_KEY`).
> No credentials are hardcoded in the frontend or in the payment flow.

### Screens (captured from the running app)

| File | Screen |
|---|---|
| `qa-home.png` | Storefront home — announcement bar, hero, promo strips, category rail, flash sales |
| `qa-product.png` | Product detail — gallery, specs, warranty/delivery panels, add to cart |
| `qa-cart.png` / `qa-checkout.png` | Cart and the 4-step checkout with live delivery fee |
| `qa-orders.png` | Customer order history with status pills |
| `qa-notifications.png` | Notification feed |
| `qa-admin.png` | Super-admin nationwide dashboard (revenue chart, sales by state, low stock) |
| `qa-admin-orders.png` | Nationwide order queue with assignment column |
| `qa-mobile.png` / `qa-mobile-signedin.png` | Mobile-first storefront (390 px) with sticky bottom nav |
| `qa-register.png` | Registration with password-strength meter and state → LGA cascade |

---

## 2. What is actually implemented

**Storefront** — announcement bar, search, category mega-nav, hero/promo strips (all active banners render), flash sales
with live countdown, best-selling phones, featured, latest arrivals, special offers, recommended, reviews, newsletter,
support, footer. 17 categories with admin CRUD + drag-order, 64 products across 9 brands/types. Filters (brand, price,
RAM, storage, colour, condition, network, rating, availability), sorting, side-by-side compare (up to 4), wishlist,
persistent cart, sticky mobile bottom navigation.

**Accounts** — register with a live password-strength meter + **state → LGA cascade** (LGA list reloads on state change, and the
server rejects any state/LGA pair that does not exist), login, logout, forgot/reset password, **email verification links that actually validate** (48-hour hashed
tokens, resend from the account page),
profile + address book (Nigerian states only), order history, warranty list, notifications, wishlist.

**Checkout** — saved address or new address, delivery method (standard/express/pickup), server-side delivery fee from
state/LGA rules with ETAs and free-delivery thresholds, promo codes with usage caps, review step, unique order number
(`OBH-YYYYMMDD-XXXXX`), **atomic stock reservation in a SQL transaction** (overselling is impossible; out-of-stock lines
are rejected), redirect to Flutterwave, server-side verification on callback + webhook, idempotent settlement.

**Orders** — 14 statuses (`pending_payment` → `payment_confirmed` → `order_confirmed` → `processing` → `packed` →
`shipped` → `out_for_delivery` → `delivered`, plus `cancellation_requested`, `cancelled`, `return_requested`,
`returned`, `refund_pending`, `refunded`), customer-facing timeline, tracking by order number, cancellation requests,
returns with photo evidence, warranty claims, support tickets.

**Admin console** (separate chrome, own branding strip) — nationwide overview with date filtering, revenue/orders/best-sellers/
top-categories/by-state/payment-mix charts, CSV exports, products, categories, inventory (stock/reserved/sold/returned/
damaged + low-stock alerts + change log), orders, single-order workspace with every action button, banners, discount codes,
delivery fees, notifications + announcements, customers, administrator management, audit logs, returns, warranties, tickets.

**Notifications** — in-app bell with unread count that updates without a refresh (polling of `/api/notifications`, which is
scoped to the signed-in user), persisted in the database so they survive logout, mark-as-read on open, full audit history,
plus email + SMS queueing.

---

## 3. The two rules that matter most

### 3.1 Notification routing (MANDATORY — implemented exactly)

`lib/notify.ts → notifyOrder()` resolves recipients **from the order row**, never from the acting user's profile:

```
recipients = all super admins
          ∪ (the state admin assigned to the order's stored state, if one is configured)
```

Consequences that are enforced in code and covered by the test suite:

* A Lagos order notifies **only** the Lagos admin + super admins — never the Rivers admin.
* A Rivers order notifies **only** the Rivers admin + super admins.
* A state with no administrator produces **super-admin-only** alerts and lands in the "unassigned" queue.
* Reassigning an order (super admin → assign/reassign) writes an `order_assignments` row, updates `orders.assigned_admin_id`
  and **re-routes every subsequent notification** to the new admin, while the previous admin stops receiving them.
* Order events (status change, cancellation, return, warranty claim, ticket) reuse the same resolver, so routing can never drift.
* Marketing/announcements are a separate type and audience (`announcements` table) — they never mix with private order alerts.

### 3.2 State isolation (server-side, not just hidden UI)

Every `/admin/*` page and every admin server action calls `requireAdminPage()` / `assertOrderAccess()` and re-reads the
order from the database. A state admin:

* can only open orders whose **stored** `state_id` equals their `admin_state_id`;
* sees only their state in dashboards, order lists, CSV exports, analytics and tickets;
* cannot reach `/admin/admins`, `/admin/products`, `/admin/analytics` nationwide totals, or browser-hack their own state/role
  (there is no such action available to them);
* gets `307 → /admin/orders?error=Access denied…` on any attempt, and the same block applies to POSTed form actions,
  not just page loads.

The same rules are enforced **in the database layer** as well: every query goes through `lib/db.ts`, and the state-scoping
conditions (`state_id = …`) are applied server-side in `lib/queries.ts` / `lib/actions/*` before any row reaches a page.
The full state-isolation matrix (page, list, CSV export, admin-management block) is asserted by test 10 in
`scripts/e2e-tests.mjs` on every run.

---

## 4. Payments (Flutterwave, NGN)

Flow: order created (`pending_payment`) → `POST /payments/:orderNumber` initialises a transaction on the server with the
**secret key** → customer is redirected to Flutterwave's hosted checkout → Flutterwave returns to
`/api/payment/callback?tx_ref=…&status=…` **and** posts `/api/payment/webhook` (signed with `verif-hash`).

Both handlers do the same thing before anything is marked paid:

1. Look the payment up by `tx_ref` (unknown refs are rejected — no order is created from a forged callback).
2. Verify server-to-server against Flutterwave (`GET /v3/transactions/verify_by_reference`).
3. Check `status === 'successful'`, `currency === 'NGN'` and `amount >= expected` (in naira, not kobo).
4. Only then call `settlePayment()`, which is **idempotent** — a replay of the same reference cannot double-credit.

The frontend message "your payment was successful" is never trusted; there is no code path that marks an order paid from a
browser-only signal. The secret key never leaves the server (`FLW_SECRET_KEY` is read only in `lib/payments.ts` and the
API routes; nothing prefixed `NEXT_PUBLIC_`).

### Enabling live/test Flutterwave
1. Dashboard → Settings → API keys: copy the **public** and **secret** keys into `FLW_PUBLIC_KEY` / `FLW_SECRET_KEY`.
2. Settings → Webhooks: set the URL to `https://<your-domain>/api/payment/webhook`, set a **secret hash** and copy it to
   `FLW_SECRET_HASH` (the handler rejects any webhook whose `verif-hash` differs).
3. Set `NEXT_PUBLIC_APP_URL` to your public HTTPS URL so the redirect URL is valid.
4. Test card: `5531 8866 5214 2950`, CVV `564`, PIN `3310`, OTP `12345`.

### Sandbox mode (what runs today)
With no keys configured the app switches to a clearly-labelled sandbox: `/payments/:orderNumber` explains the situation and
offers a "settle test payment" button that calls `/api/payment/sandbox`. That route is only active when
`FLW_SECRET_KEY` is absent, posts a fake gateway response, and then runs the **same** `settlePayment()` path — including the
`payments` row, order status transition, stock finalisation and admin notification. Every such payment is flagged
`sandbox = 1` and shows a SANDBOX badge in the admin UI, so a simulated payment can never be mistaken for real money.

---

## 5. Delivery, warranty, returns

* **Fees** — `delivery_fees(state, lga, method, fee, eta_days, min_order)`: a specific LGA rate wins over the state default,
  `express` and `pickup` are separate methods, and orders above a threshold ship free. 117 rules seeded; editable in
  `/admin/delivery`. The fee is computed on the server at order time and stored on the order.
* **Warranty** — policies of 7 / 30 days, 3 / 6 / 12 months. On `delivered`, warranty records are auto-created per item with
  IMEI/serial, purchase date, start/expiry dates and the policy text. Claims capture the issue + evidence photo and route to
  the responsible admins; admins can review → approve / reject / mark repaired. Nothing auto-approves.
* **Returns/refunds** — reason + explanation + photo upload, configurable window, reviewed by an admin, and the refund
  amount recorded before settlement. A state admin only ever sees their own state's requests.

---

## 6. Project layout

```
app/
  page.tsx                 home (hero, banners, categories, flash sales, best sellers, offers…)
  category/[slug]  search  product/[slug]  compare  wishlist  cart  checkout
  payments/[orderNumber] (+ /sandbox)      order pay + sandbox settle
  orders  orders/[number]  account  notifications  support  track
  login  register  forgot-password  reset-password  setup (one-time super admin)
  verify  terms  privacy  not-found  error
  admin/    layout (own chrome) + dashboard, orders, orders/[id], products, categories, inventory,
            banners, promotions, delivery, notifications, customers, admins, analytics, returns,
            warranties, tickets
  api/      notifications · newsletter · payment/{callback,webhook,sandbox} · admin/report (CSV)
lib/
  schema.sql (41 tables, SQLite reference)  db.ts (pg pool, async statements, transactions)  seed.ts
  auth.ts (bcrypt, sessions, guards)  verification.ts (email tokens)  notify.ts (routing, email+SMS outbox)  orders.ts (status machine,
  assignment, delivery fees)  payments.ts (Flutterwave + settle)  cart.ts  queries.ts  locations.ts  uploads.ts
  actions/ auth · cart · customer · checkout · compare · admin  (all server actions, all authorised)
components/  ui.tsx (cards, badges, charts, tables) · Header · MobileMenu · MobileBottomNav · Footer ·
             NotificationBell · ProductCard · WishlistButton · LgaStateSelect · PasswordStrength · icons.tsx
middleware.ts   pathname header for chrome selection + security headers
supabase/schema.sql                 the complete production schema (41 tables + stock functions)
supabase/migrations/0001_*.sql      the same schema for `supabase db push` (0002 = functions)
netlify.toml                        Netlify build + @netlify/plugin-nextjs
scripts/e2e-tests.mjs               the acceptance suite (see §11)
public/products/*.svg  64 original illustrations · public/brand/*  logo + mark
```

40 page routes, 6 API routes, ~10,200 lines of TypeScript.

---

## 7. Data model (41 tables)

`users, sessions, email_verifications, states, lgas, categories, products, product_images, product_variants, stock_logs, carts, cart_items,
wishlists, addresses, orders, order_items, order_assignments, order_events, deliveries, payments, transactions, refunds,
banners, promotions, notifications, notification_recipients, announcements, warranties, warranty_claims, return_requests,
support_tickets, ticket_messages, reviews, delivery_fees, admin_logs, roles, permissions, role_permissions, email_outbox,
sms_outbox, newsletter_subscribers`

Key invariants: `orders.state_id` is written at checkout and **never rewritten when the customer later edits their profile**
(routing depends on where the order ships). `products.stock`/`reserved` are guarded by a transaction and a
`CHECK (stock >= 0)` in Postgres. Every admin mutation writes `admin_logs` and order mutations write `order_events`.

---

## 8. Roles

| Capability | Customer | State admin | Super admin |
|---|---|---|---|
| Shop, pay, track, claim warranty/return | ✅ | — | — |
| See own orders only | ✅ | — | — |
| See orders in own state | — | ✅ | ✅ (all) |
| Confirm / process / ship / deliver own-state orders | — | ✅ | ✅ |
| Force any status backwards | — | ❌ | ✅ |
| Nationwide reports, CSV export | — | ❌ | ✅ |
| Products, categories, inventory, banners, promos, delivery fees | — | ❌ | ✅ |
| Create / edit / suspend / delete administrators | — | ❌ | ✅ |
| Announcements | — | ❌ | ✅ |
| Audit logs | — | ❌ | ✅ |

Deleting an administrator **soft-deletes** (deactivate + suspend), reassigns or unassigns their open orders, notifies the
super admins with a per-order summary, and preserves every historical order, log, ticket and claim with the admin's name
intact — history is never destroyed.

---

## 9. Security controls (all implemented)

bcrypt password hashing (cost 10) · server-only session cookies (`httpOnly`, `sameSite=lax`, `secure` in production,
SHA-256 hashed tokens in `sessions`) · RBAC in every page + action · parameterised SQL everywhere (no string concatenation of
user input) · React auto-escaping + no `dangerouslySetInnerHTML` · **all mutations are Next server actions**, which reject
cross-origin POSTs, plus `sameSite` cookies and per-IP rate limiting on login/register/forgot/track · validation on the server
for every field (state↔LGA pairs, phone, price, stock, quantities, uploaded image type/size) · webhook `verif-hash`
verification · secrets only in env vars · audit logging of admin actions · no backdoor routes, no hardcoded admin, `/setup`
self-locks · security headers from `middleware.ts` (nosniff, frame-options, referrer-policy, permissions-policy).

---

## 10. Configuration

| Variable | Needed for | Notes |
|---|---|---|
| `DATABASE_URL` | **the database** | Supabase: Project Settings → Database → Connection string (URI). On Netlify use the **Session pooler** (port 6543). Local dev: any Postgres. |
| `DATABASE_SSL` | TLS policy | `require` by default for non-local hosts; `false` for local Postgres without TLS |
| `NEXT_PUBLIC_APP_URL` | links, Flutterwave `redirect_url` | use the public HTTPS URL in production |
| `SESSION_SECRET` | session signing | 32+ random chars |
| `FLW_PUBLIC_KEY` / `FLW_SECRET_KEY` | real payments | blank ⇒ sandbox mode |
| `FLW_SECRET_HASH` | webhook verification | must match the dashboard exactly |
| `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_ANON_KEY` / `SUPABASE_SERVICE_ROLE_KEY` | Supabase deployment | see §12 |
| `EMAIL_PROVIDER=resend`, `EMAIL_API_KEY`, `EMAIL_FROM` | transactional email | without a key, mail is written to `email_outbox` with status `logged` and shown in the admin console — nothing is silently dropped |
| `SMS_API_KEY`, `SMS_API_URL`, `SMS_SENDER` | SMS copy | Termii-compatible JSON POST; without a key, rows land in `sms_outbox` as `logged` |
| `SETUP_KEY` | optional guard on `/setup` | |

---

## 11. Tests

```bash
node scripts/e2e-tests.mjs        # server must be running on :3000
```

The suite drives the real app over HTTP with a cookie jar (register → browse → cart → checkout → pay → admin actions) and
asserts against the database directly. **Latest run: 53 assertions, 53 passed, 0 failed** — verified three ways against
Supabase PostgreSQL: the dev server, the production `next build` + `next start` output, and a brand-new database created
solely from the shipped `supabase/schema.sql`.

| # | Required test | Result |
|---|---|---|
| 1 | Register from Lagos / Ikeja (cascade + server validation) | ✅ LGA rejected for a mismatched state |
| 2 | Lagos order notifies **only** Lagos admin + super admin | ✅ Rivers admin receives nothing |
| 3 | Rivers order notifies **only** Rivers admin + super admin | ✅ |
| 4 | Cancellation request routes to the responsible admins | ✅ |
| 5 | Warranty claim routes to the responsible admins | ✅ Kano customer → Kano admin |
| 6 | Admin deletion preserves history, reassigns/unassigns orders, notifies | ✅ 15 → 15 historical orders |
| 7 | Banner goes live then disappears when deactivated/deleted | ✅ |
| 8 | Customer announcement (audience fan-out, per-customer feed) | ✅ |
| 9 | Flutterwave payment verified server-side before "paid" | ✅ forged callback 404, order stays unpaid; verified callback → paid, replay idempotent |
| 10 | Lagos admin blocked from a Rivers order (page, list, CSV, admins) | ✅ 307 + scoped exports |
| E1 | State with no admin ⇒ unassigned + super-admin-only alerts | ✅ |
| E2 | LGA-level delivery fee applied (Bauchi ₦4,500) | ✅ |

`npx tsc --noEmit` is clean and `npm run build` completes with no type or lint errors (38/38 pages).

**Deliberate design note:** there is no route-level `loading.tsx` under `app/admin`. A Suspense/loading boundary above the
guarded pages forces Next to commit a streamed `200` before `redirect()` runs, which weakens the observable server-side
block. Keeping guards ahead of any streaming boundary preserves true `307` responses — verified by tests 10 and 6.

---

## 12. Supabase PostgreSQL — the production database

The application talks to **one** database interface: `lib/db.ts`. It opens a `pg` connection pool from `DATABASE_URL`
and exposes the same statement surface the codebase always used (`prepare().get()/all()/run()`, `?` placeholders,
`lastInsertRowid`, `tx()` transactions), translating the few SQLite idioms the queries contained (`datetime('now')`,
`IFNULL`, `INSERT OR IGNORE`, scalar `MAX(a,b)` → `greatest`, `substr` on timestamps, named `@params`) to their
Postgres equivalents. Pages, server actions and API routes are unchanged — **every feature works over Postgres**.

```bash
# 1. create the schema (SQL editor, psql, or Supabase CLI — all equivalent)
psql "$DATABASE_URL" -f supabase/schema.sql
#    supabase/migrations/0001_core_schema.sql + 0002_functions.sql are the
#    same files for `supabase db push`. All statements are idempotent.

# 2. seed demo data (optional)
npm run seed

# 3. set DATABASE_URL (+ DATABASE_SSL if required) and run
```

What is in the shipped SQL:

* **The same 41 tables** the app always used — same names, columns, keys and relationships (`users`, `sessions`,
  `orders`, `products`, …). Nothing is duplicated; no `profiles`/parallel auth tables are created, because the app's
  registration/login is built on `users` + `sessions` + bcrypt (see `lib/auth.ts`).
* Identity primary keys keep plain integer ids; timestamps are real `timestamptz` (the data layer formats them back
  to the `YYYY-MM-DD HH:MM:SS` strings the UI already expects); 0/1 flags stay integers so `WHERE is_active = 1`
  keeps working.
* `reserve_stock()` / `release_stock()` functions carried over from the previous Supabase schema, plus the
  `supabase_realtime` publication for `notifications`, `orders`, `order_events` (no-op on plain Postgres).
* **Row Level Security is intentionally not enabled**: the app authenticates with its own server-side sessions over a
  service-role connection, not Supabase Auth — the old `auth.uid()` policy draft cannot apply to it. Access control is
  enforced in application code and covered by the state-isolation tests (§11).

**Honest status:** this migration was tested end-to-end against PostgreSQL 17 — local dev server, production build, and a
fresh database created only from the shipped SQL all pass the full 53-assertion suite. What has *not* been run here is a
connection to your actual Supabase project (no credentials in this sandbox): point `DATABASE_URL` at it, apply
`supabase/schema.sql`, and the same code path is used.

## 13. Deploying to Netlify

The repo ships with `netlify.toml` (build `npm run build`, publish `.next`, Node 20) and `@netlify/plugin-nextjs`, so
App Router pages, middleware, server actions and API routes all run on Netlify's Next runtime.

1. Push the repo → Netlify → *Add new site → Import an existing project*.
2. Set the environment variables (Site settings → Environment variables):
   * `DATABASE_URL` — Supabase **Session pooler** URI (port 6543, transaction mode) — serverless functions cannot hold
     direct connections open.
   * `SESSION_SECRET`, `NEXT_PUBLIC_APP_URL` (your `https://…netlify.app` URL), Flutterwave keys (§4), and optionally
     the email/SMS provider keys. Secrets stay server-side: nothing secret may use a `NEXT_PUBLIC_` prefix.
3. Apply `supabase/schema.sql` to the Supabase project first, then deploy. Visit `/setup` once to create the super
   admin and confirm the wizard reports itself locked.
4. File uploads: on Netlify (`NETLIFY=true`) `lib/uploads.ts` stores images as data URIs in the database instead of
   writing to `public/uploads` (the serverless filesystem is read-only/ephemeral) — uploads keep working with no
   bucket to configure.

---

## 14. Known limitations (stated plainly)

* **Live Flutterwave transactions have not been executed** — there are no keys and no network here. The integration,
  verification and idempotency logic are implemented and exercised through the sandbox path, and the exact endpoints used
  are Flutterwave v3 (`/payments`, `/transactions/verify_by_reference`, `verif-hash`); re-check against their docs before
  going live.
* **Email/SMS delivery** requires provider credentials; without them messages are queued and inspectable (`email_outbox`,
  `sms_outbox`) rather than sent.
* **Supabase project connection not exercised live** — the migration is proven against PostgreSQL 17 (including a
  fresh database built only from the shipped SQL), but not against your specific Supabase instance, which needs your
  credentials (see §12).
* **Product imagery** is original SVG artwork, not photography — swap in real photos via `/admin/products` when available.
* **Charts** are lightweight CSS/SVG components, not a charting library (keeps the bundle small; no external CDN needed).
* **Rate limiting** is in-memory per instance; use Upstash/Redis for multi-instance production.
* The seeded catalogue (64 products, 8 demo orders) is demo data — `npm run seed:reset` regenerates it.

---

## 15. What to do first as the owner

1. `/setup` → create your own super admin, then delete/suspend the demo accounts (`/admin/admins`).
2. `/admin/delivery` → review the 117 delivery rules and ETAs for your courier reality.
3. `/admin/products` + `/admin/categories` → replace demo products with your stock and real photos.
4. `/admin/admins` → provision one administrator per state you actually ship to (states without one fall to the
   super-admin queue — visible on the dashboard).
5. Add Flutterwave keys + `FLW_SECRET_HASH`, then run one small live transaction and confirm it appears in
   `/admin/orders` as `paid` with a real `flw_ref`.
